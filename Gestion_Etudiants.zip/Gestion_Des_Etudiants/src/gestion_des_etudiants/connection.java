/*
Cette classe est crée afin de connecter l'application avec la base de données MySQL
*/

package gestion_des_etudiants;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class connection {
    //Declaration des variables globales*********************************************************************************
    static java.sql.Connection conn;
    static Statement st;
    static ResultSet rs;
   
    //Fonction Connection qui permet de connecter cette application avec une base de données***************************************
     public static java.sql.Connection ConnecteDb(){
               try{
                   //Driver Class
                   Class.forName("com.mysql.cj.jdbc.Driver");
                   String url="192.168.1.127";
                   String db="glv";
                   //L'URL de la base de données
    conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Gestion_Etudiants?useUnicode=true&useJDBCCompliantTimeZoneShift"
                  + "=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
                  
                   // conn=DriverManager.getConnection("jdbc:mysql://192.168.1.127:3306/Gestion_Etudiants?useUnicode=true&useJDBCCompliantTimeZoneShift"
                   //+ "=true&useLegacyDatetimeCode=false&serverTimezone=UTC","Directeur","1990");
                     // conn=DriverManager.getConnection("jdbc:mysql://" + url+ ":3306/" + db,"root","");
                     //JOptionPane.showMessageDialog(null,"connection succes");
                   return conn;
                   
               }catch(ClassNotFoundException | SQLException e){
                   JOptionPane.showMessageDialog(null,e);
                   System.out.println("erreur");
                    JOptionPane.showMessageDialog(null,"erreur");
                   return null;
               }
            }
  
}
