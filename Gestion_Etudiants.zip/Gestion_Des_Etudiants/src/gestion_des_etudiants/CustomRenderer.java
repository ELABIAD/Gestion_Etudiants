/*
 
 */
package gestion_des_etudiants;

import java.awt.Color;
import java.awt.Component;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

class CustomRenderer extends DefaultTableCellRenderer 
{
   
 public CustomRenderer() 
    {
        super();
        setOpaque(true);
      
    } 
    public Component getTableCellRendererComponent(JTable table, Object value, 
            boolean isSelected, boolean hasFocus, int row, int column) 
    { 
        
            
                     String t=table.getValueAt(row, 4).toString();
                   
        if(Integer.parseInt(t) >=6){
        
           setForeground(Color.black);        
            setBackground(Color.red);            
        
        }else{
                       setForeground(Color.black);   
                      setBackground(Color.green);                 
                      }
                  
        return this;
    }
  
    
}