/*
Cette classe est crée afin de connecter l'application avec la base de données MySQL
*/

package gestion_des_etudiants;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class connectiontoaccess {
    //Declaration des variables globales*********************************************************************************
    static java.sql.Connection conn;
    static Statement st;
    static ResultSet rs;
   
    //Fonction Connection qui permet de connecter cette application avec une base de données***************************************
     public static java.sql.Connection ConnecteDb() throws ClassNotFoundException{
               try{
                   //Driver Class
                  // Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                   //L'URL de la base de données
                  conn=DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\Savage\\Documents\\Gestion_biblio2.mdb","","");
                    System.out.println("ok");
                   return conn;  
                   
                   }catch(SQLException e){
                   JOptionPane.showMessageDialog(null,e);
                   System.out.println("erreur");
                    JOptionPane.showMessageDialog(null,"erreur");
                   return null;
                  }
           }
     public static void Ajouter_Et(String cne,String cin,String nom,String prenom,String sexe,String filiere,String option,String niveau, String tel, String img){
             String k="insert into  Etudiant1(CNE,CIN,Nom,Prenom,Sexe,Filiere,Option,Niveau,Telephone,Image) "
                     + "values('"+cne+"','"+cin+"','"+nom+"','"+prenom+"','"+sexe+"','"+filiere+"','"+option+"','"+niveau+"','"+tel+"','"+img+"')";
              try{
               Statement ps=ConnecteDb().createStatement();
                ps.executeUpdate(k);
                 JOptionPane.showMessageDialog(null,"ok ok");
     }catch(Exception e){
         JOptionPane.showMessageDialog(null,e.getMessage());
     }
     }
       public static void Ajouter(String cne){
             String k="insert into  et  values('"+cne+"')";
              try{
               
       PreparedStatement ps=ConnecteDb().prepareStatement(k);
        ps.executeUpdate(k);
        
        JOptionPane.showMessageDialog(null,"ok ok");
     }catch(Exception e){
         JOptionPane.showMessageDialog(null,e.getMessage());
     }
     }
      public static void Modifier_Et(String cne,String cin,String nom,String prenom,String sexe,String filiere,String option,String niveau, String tel, String img){
             String k="UPDATE  Etudiant1  SET CIN='"+cin+"',Nom='"+nom+"',Prenom='"+prenom+"',Sexe='"+sexe+"',Filiere='"+filiere+"',Option='"+option+"',Niveau'"+niveau+"',"
                     + "Telephone='"+tel+"',Image=?  where CNE='"+cne+"' ";
              try{
             PreparedStatement ps=ConnecteDb().prepareStatement(k);
             ps.setString(1, img);
             ps.executeUpdate();
     }catch(Exception e){
         JOptionPane.showMessageDialog(null,e.getMessage());
     }
     }
      
       public static void Modifier_Niveau(String cne,String niveau){
             String k="UPDATE  Etudiant1   SET Niveau='"+niveau+"' where CNE='"+cne+"' ";
              try{
              Statement ps=ConnecteDb().createStatement();
                ps.executeUpdate(k);
     }catch(Exception e){
         JOptionPane.showMessageDialog(null,e.getMessage());
     }
       }
              public static void Afficher(){
                    String k="insert into et values ('naima123') ";
              try{
             Statement ps=ConnecteDb().createStatement();
                ps.executeUpdate(k);
               JOptionPane.showMessageDialog(null,"ok");
     }catch(Exception e){
         JOptionPane.showMessageDialog(null,e.getMessage());
     }
              
     }
//       public static void main(String[] args) throws ClassNotFoundException {
//          
//        Ajouter_Et("25122","lala","gs","gj","hj","h","hh","j","hh","g");
//        //Ajouter("1425hgg");
//        //Afficher();
//    }
      
}
