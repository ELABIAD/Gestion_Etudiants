/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestion_des_etudiants;

//static DefaultTableModel p2=new DefaultTableModel();

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import static java.awt.print.Printable.NO_SUCH_PAGE;
import static java.awt.print.Printable.PAGE_EXISTS;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class Imprimer extends JPanel implements Printable,ActionListener{
          JPanel frameToPrint;

   
 
    
    @Override
    public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
      

        if(pageIndex>0){
             JOptionPane.showMessageDialog(null,"L'impression est faite avec succès");
             return NO_SUCH_PAGE;
        }
      
        Graphics2D g2d=( Graphics2D)graphics;
        g2d.translate(pageFormat.getImageableX(),pageFormat.getImageableY());
      frameToPrint.printAll(graphics);
     
      return PAGE_EXISTS;
      
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        PrinterJob job=PrinterJob.getPrinterJob();   
        job.setPrintable((Printable) this);
        boolean ok=job.printDialog();
        if(ok){
           
            try {
                job.print();
            } catch (PrinterException ex) {
              
            }
           
        }
    }
   
     public Imprimer(JPanel f) {
        frameToPrint=f;
        
    }
    
    
   
}
