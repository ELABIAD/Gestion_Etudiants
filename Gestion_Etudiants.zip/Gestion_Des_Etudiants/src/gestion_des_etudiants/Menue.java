
package gestion_des_etudiants;

import java.awt.Color;
import static java.awt.Color.green;
import static java.awt.Color.red;
import static java.awt.Color.white;
import java.awt.Component;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.print.PrinterException;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;


public class Menue extends javax.swing.JFrame {

      static DefaultTableModel model=new DefaultTableModel();
      static DefaultTableModel dt=new DefaultTableModel();
      static DefaultTableModel md=new DefaultTableModel();
      static DefaultTableModel nv=new DefaultTableModel();
      static DefaultTableModel mdl=new DefaultTableModel();
      static DefaultTableModel elem=new DefaultTableModel();
      static DefaultTableModel note=new DefaultTableModel();
      static DefaultTableModel inter=new DefaultTableModel();
      static DefaultTableModel abc=new DefaultTableModel();
      static DefaultTableModel ret=new DefaultTableModel();
      static DefaultTableModel p1=new DefaultTableModel();
      static DefaultTableModel p2=new DefaultTableModel();
      static DefaultTableModel sc=new DefaultTableModel();
      static DefaultTableModel co=new DefaultTableModel();
      static DefaultTableModel sco=new DefaultTableModel();
      static DefaultTableModel se=new DefaultTableModel();
      static DefaultTableModel ab=new DefaultTableModel();
      static DefaultTableModel t=new DefaultTableModel();
       static DefaultTableModel et=new DefaultTableModel();
       static DefaultTableModel lv=new DefaultTableModel();
        static DefaultTableModel v=new DefaultTableModel();
     
     static Connection conn;
    static Statement st,st1;
    static ResultSet rs,rs1;
    static int i;
    static int j;
    private String sexe;
   // private String Langues;
     private String enfant;
    private String boursiere;
    static Boolean ma=false,c=false,s=false;
  
    public Menue() {
           initComponents();
          
           ImageIcon myimg = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Image1.png")));
           
           Image img1=myimg.getImage();
           Image img2=img1.getScaledInstance(jLabel33.getWidth(),jLabel33.getHeight(),Image.SCALE_SMOOTH);
           ImageIcon im=new ImageIcon(img2);
           jLabel33.setIcon(im);
          
            ImageIcon myimg1 = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("setting.png")));
           
           Image img11=myimg1.getImage();
           Image img21=img11.getScaledInstance(jButton9.getWidth(),jButton9.getHeight(),Image.SCALE_SMOOTH);
           ImageIcon im1=new ImageIcon(img21);
           jButton9.setIcon(im1);
        
           
            ImageIcon myimg2 = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("photos-infirmier.png")));
           
           Image img12=myimg2.getImage();
           Image img22=img12.getScaledInstance(jLabel11.getWidth(),jLabel11.getHeight(),Image.SCALE_SMOOTH);
           ImageIcon im2=new ImageIcon(img22);
           jLabel11.setIcon(im2);
           

               ImageIcon myimg23 = new ImageIcon(Toolkit.getDefaultToolkit().getImage(getClass().getResource("icons8-menu-filled-50.png")));
           
           Image img123=myimg23.getImage();
           Image img223=img123.getScaledInstance(jLabel2.getWidth(),jLabel2.getHeight(),Image.SCALE_SMOOTH);
           ImageIcon im23=new ImageIcon(img223);
           jLabel2.setIcon(im23);
          
           num_insc.setVisible(false);
           insc.setVisible(false);
           label_number.setVisible(false);
           url.setVisible(false);
           text_num.setVisible(false);
         
        //*************************************************************************
     
        
/* ------------------------------------- Table filiere ----------------------------------------------------------- */        
         //Les noms des colonnes de la table 
        model.addColumn("Id Filière");
        model.addColumn("Nom Filière");
       
     
       String his="Select * From Filiere_E";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(his);
                   while(rs.next()){
                   model.addRow(new Object[]{rs.getString("Id_Filiere"),rs.getString("Nom_Filiere")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
    
       
       Table_Filiere.setModel(model);
       //*****************
       t.addColumn("N_Inscription");
       t.addColumn("Nom");
       Table_Abc1.setModel(t);
       
       /* et.addColumn("N_Inscription");
        et.addColumn("Nom");
         et.addColumn("Note du contrôle continus");
         et.addColumn("Note du contrôle final");*:
         Table_Et1.setModel(et);
       
  /* ----------------------- Table Option ---------------------------------------------------------------- */     
      //Les noms des colonnes de la table 
        dt.addColumn("Id Option");
        dt.addColumn("Nom Option");
        dt.addColumn("Nom Filière");
     
       String h="Select * From Option_E";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données ******************************************
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(h);
                   while(rs.next()){
                   dt.addRow(new Object[]{rs.getString("Id_Option"),rs.getString("Nom_Option"),rs.getString("Nom_Filiere")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
     
       Table_Option.setModel(dt);
   //************** Table corsEnsignant ******************************************      
         //Les noms des colonnes de la table **********
        md.addColumn("CIN");
        md.addColumn("Nom");
        md.addColumn("Prénom");
        md.addColumn("Grade");
        md.addColumn("Télephone1");
         md.addColumn("Télephone2");
        md.addColumn("Email");
        md.addColumn("Numéro Compte");
         md.addColumn("Type");
        md.addColumn("Fonction");
        md.addColumn("Module");
         md.addColumn("Filière");
        md.addColumn("Option");
       String q = "Select * From Cors_Enseignant";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données ******************************************
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(q);
                   while(rs.next()){
                   md.addRow(new Object[]{rs.getString("CIN"),rs.getString("Nom"),rs.getString("Prenom"),rs.getString("Grade"),rs.getString("Telephone1"),
                       rs.getString("Telephone2"),rs.getString("Email"),rs.getString("Numero_Compte"),rs.getString("Type"),
                   rs.getString("Fonction"),rs.getString("Module_C"),rs.getString("Filiere_C"),rs.getString("Option_C")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
    
       
       table_coor.setModel(md);
       
      
       
      
       
        /* ------------------------------------- Table Module ----------------------------------------------------------- */        
         //Les noms des colonnes de la table *******************************************************************************
        mdl.addColumn("Code Module");
        mdl.addColumn("Intitulé Module");
        mdl.addColumn("Nombre éléments ");
         mdl.addColumn("Volume Horaire");
         mdl.addColumn("Type");
        mdl.addColumn("Filiere");
        mdl.addColumn("Option");
        mdl.addColumn("Niveau");
        
       Table_Module1.setModel(mdl);
       
        /* ------------------------------------- Table Module ----------------------------------------------------------- */        
         //Les noms des colonnes de la table *******************************************************************************
        elem.addColumn("Id élément");
        elem.addColumn("Intitulé élément");
        elem.addColumn("Volume Horaire");
        elem.addColumn("Intervenant");
        elem.addColumn("Nom module");
       
        
      String el="Select * From Element_Module";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données ******************************************
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(el);
                   while(rs.next()){
                   elem.addRow(new Object[]{rs.getString("Id_Element"),rs.getString("Nom_Element"),rs.getString("Volume_Horaire_E"),
                   rs.getString("Intervenant_Element"),rs.getString("Nom_Module")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
       Table_Element.setModel(elem);
        /* ------------------------------------- Table Note ----------------------------------------------------------- */        
         //Les noms des colonnes de la table *******************************************************************************
        note.addColumn("Id");
         note.addColumn("N Inscription");
        note.addColumn("Nom");
        note.addColumn("Note Ds");
        note.addColumn("Note Examen");
        note.addColumn("Note Session Normale");
        note.addColumn("Note Session Rattrapage");
        note.addColumn("Etat");
      
//       Table_Note1.setModel(note);
       
     
       
       /* ------------------------------------- Table Abcense ----------------------------------------------------------- */        
         //Les noms des colonnes de la table 
          abc.addColumn("Etat d'absence");
         abc.addColumn("N_Inscription");
        abc.addColumn("Nom");
        abc.addColumn("Date d'absence");
          abc.addColumn("Nombre d'absences");
      /*  String t="Absence";
                
       String a="Select * From Abcense Where Filiere_A='"+filiere_ret.getSelectedItem().toString()+"' "
               + "AND Option_A='"+option_ret.getSelectedItem().toString()+"' "
               + "AND Niveau_A='"+niveau_ret.getSelectedItem().toString()+"'AND"
               + " Nom_Module_A='"+module_ret.getSelectedItem().toString()+"' AND Type='"+t+"'";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
        String j="Abcense non justifiée";
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(a);
                   while(rs.next()){
                   abc.addRow(new Object[]{rs.getString("N_Inscription"),rs.getString("Nom_Etud"),rs.getString("Duree_Abcense"),rs.getString("Date_Abcense")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
    */
       
     Table_Abcense1.setModel(abc);
       
       //*********************************
         //------------------------------------- Table Retard ----------------------------------------------------------- */        
         //Les noms des colonnes de la table 
        ret.addColumn("N inscription");
        ret.addColumn("Nom d'étudiant");
        ret.addColumn("Date_Retard");
        
                String opt=op1.getSelectedItem().toString();
                String Fil=fi1.getSelectedItem().toString();
                String niv=ni1.getSelectedItem().toString();
                String mo=mo1.getSelectedItem().toString();
                String ju="Retard non justifié";
                String ty="Retard";
                String r="SELECT * FROM Abcense WHERE Filiere_A='"+Fil+"' AND Option_A='"+opt+"' AND Niveau_A='"+niv+"' AND Justification='"+ju+"' AND Nom_Module_A='"+mo+"' AND Type='"+t+"'";
      
    
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(r);
                   while(rs.next()){
                   ret.addRow(new Object[]{rs.getString("N_Inscription"),rs.getString("Nom_Etudiant"),rs.getString("Date_Retard")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       Table_Retard1.setModel(ret);
       
       //*****************Table Etudiants
         //Les noms des colonnes de la table 
        p1.addColumn("CNE");
       p1.addColumn("CIN");
        p1.addColumn("Nom");
        p1.addColumn("Prénom");
        p1.addColumn("Sexe");
        p1.addColumn("Date de naissance");
        p1.addColumn("Lieux de naissance");
        p1.addColumn("Adress1");
        p1.addColumn("Adresse2");
        
       
                String op=option_info.getSelectedItem().toString();
                String Fi=filiere_info.getSelectedItem().toString();
                String ni=niveau_info.getSelectedItem().toString();
                
                String af="SELECT * FROM Etudiant WHERE Filiere_E='"+Fi+"' AND Option_E='"+op+"' AND Niveau_E='"+ni+"' ";
      
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(af);
                   while(rs.next()){
                   p1.addRow(new Object[]{rs.getString("CNE"), rs.getString("CIN"),rs.getString("Nom"),rs.getString("Prenom"),
                   rs.getString("Sexe"),rs.getString("Date_Naissance"),rs.getString("Lieux_Naissance"),rs.getString("Adresse1"),
                   rs.getString("Adresse2")} );
                   
                    
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
    
       
       table_per1.setModel(p1);
       //****************************************
         //*****************Table Etudiants
        p2.addColumn("Nom");
        p2.addColumn("Télephone1");
        p2.addColumn("Télephone2");
        p2.addColumn("Nationalité");
        p2.addColumn("Adresse actuel");
        p2.addColumn("Situation de famille");
        p2.addColumn("Numéro WhatsApp");
        p2.addColumn("Lieux de naissance");
        p2.addColumn("Email1");
        p2.addColumn("Email2");
        p2.addColumn("Nombre Enfants");
            Afficher_Info();
       table_per2.setModel(p2);
       //*******************
        sc.addColumn("N Inscription");
        sc.addColumn("Date Inscription");
        sc.addColumn("Boursiere");
        sc.addColumn("Année d'obtention du bac");
        sc.addColumn("Mention du bac");
        sc.addColumn("Moyenne du bac");
        sc.addColumn("Lycée");
        sc.addColumn("Filière");
        sc.addColumn("Option");
        sc.addColumn("Niveau");
            Afficher_Info_Scolaire();
       table_scolaire.setModel(sc);
       //******************
        co.addColumn("Nom");
        co.addColumn("Langues maîtrisées");
        co.addColumn("Logiciels_maîtrisées");
        co.addColumn("Formation antérieure");
        co.addColumn("Formation attelier");
        co.addColumn("Diplômes obtenus");
        Afficher_Compethence();
        table_compethence.setModel(co);
        
          v.addColumn("Nom");
        v.addColumn("Langues maîtrisées");
        v.addColumn("Logiciels_maîtrisées");
        v.addColumn("Formation antérieure");
        v.addColumn("Formation attelier");
        v.addColumn("Diplômes obtenus");
        table_compethence1.setModel(v);
        
        //*************************************************
         sco.addColumn("Nom");
        sco.addColumn("Livres empruntés");
        sco.addColumn("Nombre d'abcenses");
        sco.addColumn("Résultat");
        
        //table_scolair2.setModel(sco);
        
        //*****************************
         se.addColumn("Nom_Module");
        se.addColumn("Note_Generale");
        se.addColumn("Etat");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        bodyPanel1 = new javax.swing.JPanel();
        menuPanel1 = new javax.swing.JPanel();
        btnhome = new javax.swing.JButton();
        btninscription = new javax.swing.JButton();
        btnabcense = new javax.swing.JButton();
        btnmodule = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnnote = new javax.swing.JButton();
        btnfiliere = new javax.swing.JButton();
        btn_inter = new javax.swing.JButton();
        btncoor = new javax.swing.JButton();
        btnniveau = new javax.swing.JButton();
        jLabel33 = new javax.swing.JLabel();
        btnresultat = new javax.swing.JButton();
        mainPanel = new javax.swing.JPanel();
        homePanel = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        retardpanel = new javax.swing.JPanel();
        abcensepanel2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jButton13 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        filiere_ret = new javax.swing.JComboBox<>();
        jLabel111 = new javax.swing.JLabel();
        module_ret = new javax.swing.JComboBox<>();
        jLabel114 = new javax.swing.JLabel();
        option_ret = new javax.swing.JComboBox<>();
        jLabel115 = new javax.swing.JLabel();
        niveau_ret = new javax.swing.JComboBox<>();
        jLabel38 = new javax.swing.JLabel();
        modulepanel = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        nom_module = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        nbr_elem = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        Table_Element = new javax.swing.JTable();
        jLabel26 = new javax.swing.JLabel();
        nom_elem = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        horaire_elem = new javax.swing.JTextField();
        jLabel91 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        mod_elem = new javax.swing.JComboBox<>();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jLabel94 = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        filiere_mod = new javax.swing.JComboBox<>();
        option_mod = new javax.swing.JComboBox<>();
        niveau_mod = new javax.swing.JComboBox<>();
        inter_elem = new javax.swing.JComboBox<>();
        horaire_mod = new javax.swing.JComboBox<>();
        jLabel124 = new javax.swing.JLabel();
        type = new javax.swing.JComboBox<>();
        jButton44 = new javax.swing.JButton();
        jButton46 = new javax.swing.JButton();
        jButton47 = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        notepanel = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        filiere_etud = new javax.swing.JComboBox<>();
        jLabel49 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        niveau_etud = new javax.swing.JComboBox<>();
        option_etud = new javax.swing.JComboBox<>();
        module_etud = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        btnresultat1 = new javax.swing.JButton();
        btnresultat2 = new javax.swing.JButton();
        btnresultat3 = new javax.swing.JButton();
        jButton56 = new javax.swing.JButton();
        abcensepanel = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        just_abc = new javax.swing.JComboBox<>();
        niveau_abc = new javax.swing.JComboBox<>();
        jLabel46 = new javax.swing.JLabel();
        module_abc = new javax.swing.JComboBox<>();
        jLabel112 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        filiere_abc = new javax.swing.JComboBox<>();
        option_abc = new javax.swing.JComboBox<>();
        elem_abc = new javax.swing.JComboBox<>();
        date_abc = new com.toedter.calendar.JDateChooser();
        jLabel76 = new javax.swing.JLabel();
        duree_abc = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        type_abc = new javax.swing.JComboBox<>();
        jButton73 = new javax.swing.JButton();
        filierepanel = new javax.swing.JPanel();
        modulepanel2 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        nomfiliere = new javax.swing.JTextField();
        jScrollPane9 = new javax.swing.JScrollPane();
        Table_Option = new javax.swing.JTable();
        jScrollPane10 = new javax.swing.JScrollPane();
        Table_Filiere = new javax.swing.JTable();
        jLabel39 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        Supprimer = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel40 = new javax.swing.JLabel();
        nom_option = new javax.swing.JTextField();
        nom_filiere = new javax.swing.JComboBox<>();
        jLabel80 = new javax.swing.JLabel();
        code = new javax.swing.JTextField();
        jButton48 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        niveaupanel = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        filiere_etud2 = new javax.swing.JComboBox<>();
        jLabel78 = new javax.swing.JLabel();
        option_etud2 = new javax.swing.JComboBox<>();
        jLabel104 = new javax.swing.JLabel();
        niveau_etud2 = new javax.swing.JComboBox<>();
        jButton14 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        inscriptionpanel = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        cne_p = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        cin = new javax.swing.JTextField();
        nom = new javax.swing.JTextField();
        prenom = new javax.swing.JTextField();
        femme = new javax.swing.JRadioButton();
        homme = new javax.swing.JRadioButton();
        jLabel58 = new javax.swing.JLabel();
        lieux = new javax.swing.JTextField();
        jLabel59 = new javax.swing.JLabel();
        adr1 = new javax.swing.JTextField();
        jLabel60 = new javax.swing.JLabel();
        adr2 = new javax.swing.JTextField();
        jLabel61 = new javax.swing.JLabel();
        tel1 = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        label1 = new javax.swing.JLabel();
        label = new javax.swing.JLabel();
        parcourire = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jLabel79 = new javax.swing.JLabel();
        tel2 = new javax.swing.JTextField();
        url = new javax.swing.JLabel();
        naissance = new com.toedter.calendar.JDateChooser();
        label_number = new javax.swing.JLabel();
        inscription2panel = new javax.swing.JPanel();
        jLabel62 = new javax.swing.JLabel();
        nationalite = new javax.swing.JTextField();
        jLabel63 = new javax.swing.JLabel();
        adr_actuel = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        situation = new javax.swing.JComboBox<>();
        jLabel65 = new javax.swing.JLabel();
        email1 = new javax.swing.JTextField();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        email2 = new javax.swing.JTextField();
        jLabel82 = new javax.swing.JLabel();
        whatsup = new javax.swing.JTextField();
        jButton18 = new javax.swing.JButton();
        jLabel85 = new javax.swing.JLabel();
        label_enf = new javax.swing.JLabel();
        nbr_enfant = new javax.swing.JTextField();
        Oui = new javax.swing.JRadioButton();
        Non = new javax.swing.JRadioButton();
        jButton25 = new javax.swing.JButton();
        inscription3panel = new javax.swing.JPanel();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        mention = new javax.swing.JTextField();
        moyenne = new javax.swing.JTextField();
        obtention = new javax.swing.JTextField();
        jLabel77 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel83 = new javax.swing.JLabel();
        lycee = new javax.swing.JTextField();
        jLabel68 = new javax.swing.JLabel();
        oui = new javax.swing.JRadioButton();
        non = new javax.swing.JRadioButton();
        jLabel84 = new javax.swing.JLabel();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        filiere = new javax.swing.JComboBox<>();
        option = new javax.swing.JComboBox<>();
        jLabel90 = new javax.swing.JLabel();
        inscription = new com.toedter.calendar.JDateChooser();
        inscription4panel = new javax.swing.JPanel();
        logiciel = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        langue = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        jScrollPane20 = new javax.swing.JScrollPane();
        anterieure = new javax.swing.JTextArea();
        num_insc = new javax.swing.JTextField();
        insc = new javax.swing.JLabel();
        jLabel161 = new javax.swing.JLabel();
        Ar = new javax.swing.JCheckBox();
        jLabel70 = new javax.swing.JLabel();
        jLabel87 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jScrollPane19 = new javax.swing.JScrollPane();
        diplome = new javax.swing.JTextArea();
        jScrollPane18 = new javax.swing.JScrollPane();
        attelier = new javax.swing.JTextArea();
        jPanel8 = new javax.swing.JPanel();
        jButton19 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        Es = new javax.swing.JCheckBox();
        Fr = new javax.swing.JCheckBox();
        An = new javax.swing.JCheckBox();
        Ta = new javax.swing.JCheckBox();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox4 = new javax.swing.JComboBox<>();
        jComboBox5 = new javax.swing.JComboBox<>();
        jButton16 = new javax.swing.JButton();
        jButton38 = new javax.swing.JButton();
        coordinateurpanel = new javax.swing.JPanel();
        modulepanel4 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        nom_coor = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        table_coor = new javax.swing.JTable();
        jButton12 = new javax.swing.JButton();
        Supprimer2 = new javax.swing.JButton();
        jLabel99 = new javax.swing.JLabel();
        jLabel100 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        email_coor = new javax.swing.JTextField();
        tel1_coor = new javax.swing.JTextField();
        cin_coor = new javax.swing.JTextField();
        jLabel121 = new javax.swing.JLabel();
        num_compte = new javax.swing.JTextField();
        jLabel122 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        type_coor = new javax.swing.JComboBox<>();
        jLabel125 = new javax.swing.JLabel();
        f = new javax.swing.JLabel();
        m = new javax.swing.JLabel();
        fonction_coor = new javax.swing.JComboBox<>();
        module_coor = new javax.swing.JComboBox<>();
        filiere_coor = new javax.swing.JComboBox<>();
        o = new javax.swing.JLabel();
        option_coor = new javax.swing.JComboBox<>();
        prenom_coor = new javax.swing.JTextField();
        grade_coor = new javax.swing.JTextField();
        jLabel129 = new javax.swing.JLabel();
        tel2_coor = new javax.swing.JTextField();
        jButton42 = new javax.swing.JButton();
        moduleretard = new javax.swing.JPanel();
        module_retard1 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel147 = new javax.swing.JLabel();
        jLabel158 = new javax.swing.JLabel();
        jLabel186 = new javax.swing.JLabel();
        jLabel187 = new javax.swing.JLabel();
        fi1 = new javax.swing.JComboBox<>();
        ni1 = new javax.swing.JComboBox<>();
        op1 = new javax.swing.JComboBox<>();
        mo1 = new javax.swing.JComboBox<>();
        jButton30 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        choix_module = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jButton39 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Table_Abc1 = new javax.swing.JTable();
        Liste_Abc1 = new javax.swing.JPanel();
        Liste_Abc2 = new javax.swing.JPanel();
        jLabel108 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        Table_Abcense1 = new javax.swing.JTable();
        jButton65 = new javax.swing.JButton();
        jButton66 = new javax.swing.JButton();
        Liste_Retard = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel119 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Table_Retard1 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        etudiant = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel136 = new javax.swing.JLabel();
        filiere_info = new javax.swing.JComboBox<>();
        jLabel137 = new javax.swing.JLabel();
        option_info = new javax.swing.JComboBox<>();
        jLabel138 = new javax.swing.JLabel();
        niveau_info = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();
        jLabel140 = new javax.swing.JLabel();
        jYearChooser1 = new com.toedter.calendar.JYearChooser();
        Afficher_Etud = new javax.swing.JPanel();
        jScrollPane15 = new javax.swing.JScrollPane();
        table_per1 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        btnniveau1 = new javax.swing.JButton();
        btnniveau2 = new javax.swing.JButton();
        btnniveau3 = new javax.swing.JButton();
        btnniveau4 = new javax.swing.JButton();
        btnniveau18 = new javax.swing.JButton();
        pa1 = new javax.swing.JPanel();
        jLabel101 = new javax.swing.JLabel();
        cne_a = new javax.swing.JTextField();
        jLabel126 = new javax.swing.JLabel();
        cin_a = new javax.swing.JTextField();
        jLabel127 = new javax.swing.JLabel();
        nom_a = new javax.swing.JTextField();
        jLabel128 = new javax.swing.JLabel();
        prenom_a = new javax.swing.JTextField();
        jLabel130 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        lieux_a = new javax.swing.JTextField();
        jLabel132 = new javax.swing.JLabel();
        naissance_a = new javax.swing.JTextField();
        jLabel133 = new javax.swing.JLabel();
        adr1_a = new javax.swing.JTextField();
        jLabel134 = new javax.swing.JLabel();
        adr2_a = new javax.swing.JTextField();
        sexe_a = new javax.swing.JTextField();
        jPanel10 = new javax.swing.JPanel();
        photo_a = new javax.swing.JLabel();
        jButton45 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        comborech = new javax.swing.JComboBox<>();
        textrech = new javax.swing.JTextField();
        jButton43 = new javax.swing.JButton();
        info_per2 = new javax.swing.JPanel();
        Afficher_Etud4 = new javax.swing.JPanel();
        jScrollPane23 = new javax.swing.JScrollPane();
        table_per2 = new javax.swing.JTable();
        jPanel15 = new javax.swing.JPanel();
        btnniveau5 = new javax.swing.JButton();
        btnniveau6 = new javax.swing.JButton();
        btnniveau19 = new javax.swing.JButton();
        btnniveau7 = new javax.swing.JButton();
        btnniveau20 = new javax.swing.JButton();
        pa2 = new javax.swing.JPanel();
        jLabel165 = new javax.swing.JLabel();
        tel1_a = new javax.swing.JTextField();
        jLabel166 = new javax.swing.JLabel();
        tel2_a = new javax.swing.JTextField();
        jLabel167 = new javax.swing.JLabel();
        nationalite_a = new javax.swing.JTextField();
        jLabel168 = new javax.swing.JLabel();
        actuel_a = new javax.swing.JTextField();
        jLabel169 = new javax.swing.JLabel();
        jLabel170 = new javax.swing.JLabel();
        jLabel171 = new javax.swing.JLabel();
        jLabel172 = new javax.swing.JLabel();
        jLabel173 = new javax.swing.JLabel();
        situation_a = new javax.swing.JTextField();
        whatsup_a = new javax.swing.JTextField();
        email1_a = new javax.swing.JTextField();
        email2_a = new javax.swing.JTextField();
        nbr_enfant_a = new javax.swing.JTextField();
        cnee = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        btnniveau27 = new javax.swing.JButton();
        btnniveau28 = new javax.swing.JButton();
        btnniveau29 = new javax.swing.JButton();
        btnniveau30 = new javax.swing.JButton();
        btnniveau31 = new javax.swing.JButton();
        info_scolaire = new javax.swing.JPanel();
        Afficher_Etud5 = new javax.swing.JPanel();
        jScrollPane24 = new javax.swing.JScrollPane();
        table_scolaire = new javax.swing.JTable();
        pa3 = new javax.swing.JPanel();
        jLabel174 = new javax.swing.JLabel();
        num_a = new javax.swing.JTextField();
        jLabel175 = new javax.swing.JLabel();
        jLabel176 = new javax.swing.JLabel();
        jLabel177 = new javax.swing.JLabel();
        jLabel178 = new javax.swing.JLabel();
        jLabel179 = new javax.swing.JLabel();
        jLabel180 = new javax.swing.JLabel();
        jLabel181 = new javax.swing.JLabel();
        jLabel182 = new javax.swing.JLabel();
        jLabel192 = new javax.swing.JLabel();
        insc_a = new javax.swing.JTextField();
        bou_a = new javax.swing.JTextField();
        mention_a = new javax.swing.JTextField();
        obtention_a = new javax.swing.JTextField();
        moyenne_a = new javax.swing.JTextField();
        lycee_a = new javax.swing.JTextField();
        filiere_a = new javax.swing.JTextField();
        option_a = new javax.swing.JTextField();
        niveau_a = new javax.swing.JTextField();
        jPanel14 = new javax.swing.JPanel();
        btnresultat7 = new javax.swing.JButton();
        btnresultat5 = new javax.swing.JButton();
        btnresultat6 = new javax.swing.JButton();
        btnresultat8 = new javax.swing.JButton();
        btnresultat9 = new javax.swing.JButton();
        compethence = new javax.swing.JPanel();
        Afficher_Etud6 = new javax.swing.JPanel();
        jScrollPane25 = new javax.swing.JScrollPane();
        table_compethence = new javax.swing.JTable();
        jPanel19 = new javax.swing.JPanel();
        btnniveau13 = new javax.swing.JButton();
        btnniveau14 = new javax.swing.JButton();
        btnniveau15 = new javax.swing.JButton();
        btnniveau16 = new javax.swing.JButton();
        btnniveau21 = new javax.swing.JButton();
        pa5 = new javax.swing.JPanel();
        jScrollPane27 = new javax.swing.JScrollPane();
        table_compethence1 = new javax.swing.JTable();
        jButton53 = new javax.swing.JButton();
        scolaire2 = new javax.swing.JPanel();
        Afficher_Etud7 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        btnniveau22 = new javax.swing.JButton();
        btnniveau23 = new javax.swing.JButton();
        btnniveau24 = new javax.swing.JButton();
        btnniveau25 = new javax.swing.JButton();
        btnniveau26 = new javax.swing.JButton();
        pa4 = new javax.swing.JPanel();
        jLabel191 = new javax.swing.JLabel();
        jLabel194 = new javax.swing.JLabel();
        nbr_abc_a = new javax.swing.JTextField();
        res_a = new javax.swing.JTextField();
        text_num = new javax.swing.JTextField();
        jButton35 = new javax.swing.JButton();
        table_mod = new javax.swing.JPanel();
        jScrollPane28 = new javax.swing.JScrollPane();
        Table_Module1 = new javax.swing.JTable();
        jLabel37 = new javax.swing.JLabel();
        jButton50 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        tablenote = new javax.swing.JPanel();
        noter_abc = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        Table_Abc = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jButton37 = new javax.swing.JButton();
        jButton49 = new javax.swing.JButton();
        jButton51 = new javax.swing.JButton();
        jButton52 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        sessionrattrapage = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel86 = new javax.swing.JLabel();
        filiere_etud1 = new javax.swing.JComboBox<>();
        jLabel97 = new javax.swing.JLabel();
        option_etud1 = new javax.swing.JComboBox<>();
        jLabel107 = new javax.swing.JLabel();
        niveau_etud1 = new javax.swing.JComboBox<>();
        jLabel109 = new javax.swing.JLabel();
        module_etud1 = new javax.swing.JComboBox<>();
        jButton36 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        Semestre = new javax.swing.JPanel();
        jButton54 = new javax.swing.JButton();
        jLabel143 = new javax.swing.JLabel();
        filiere_s = new javax.swing.JComboBox<>();
        jLabel144 = new javax.swing.JLabel();
        option_s = new javax.swing.JComboBox<>();
        jLabel145 = new javax.swing.JLabel();
        niveau_s = new javax.swing.JComboBox<>();
        res_label = new javax.swing.JLabel();
        jButton55 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        Table_Et1 = new javax.swing.JTable();
        jButton58 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jButton34 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        bodyPanel1.setBackground(new java.awt.Color(255, 255, 255));
        bodyPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menuPanel1.setBackground(new java.awt.Color(204, 204, 204));
        menuPanel1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        menuPanel1.setForeground(new java.awt.Color(204, 204, 204));
        menuPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnhome.setBackground(new java.awt.Color(204, 204, 204));
        btnhome.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnhome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-home-32.png"))); // NOI18N
        btnhome.setText("    Accueil");
        btnhome.setBorder(null);
        btnhome.setContentAreaFilled(false);
        btnhome.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnhome.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnhome.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnhome.setIconTextGap(10);
        btnhome.setOpaque(true);
        btnhome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnhomeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnhomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnhomeMouseExited(evt);
            }
        });
        btnhome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhomeActionPerformed(evt);
            }
        });
        menuPanel1.add(btnhome, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 190, 40));

        btninscription.setBackground(new java.awt.Color(204, 204, 204));
        btninscription.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btninscription.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-inscription-27.png"))); // NOI18N
        btninscription.setText("     Inscription");
        btninscription.setBorder(null);
        btninscription.setContentAreaFilled(false);
        btninscription.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btninscription.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btninscription.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btninscription.setIconTextGap(10);
        btninscription.setOpaque(true);
        btninscription.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btninscriptionMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btninscriptionMouseExited(evt);
            }
        });
        btninscription.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninscriptionActionPerformed(evt);
            }
        });
        menuPanel1.add(btninscription, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 190, 40));

        btnabcense.setBackground(new java.awt.Color(204, 204, 204));
        btnabcense.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnabcense.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-planner-filled-27.png"))); // NOI18N
        btnabcense.setText("    Absence & Retard");
        btnabcense.setBorder(null);
        btnabcense.setContentAreaFilled(false);
        btnabcense.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnabcense.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnabcense.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnabcense.setIconTextGap(10);
        btnabcense.setOpaque(true);
        btnabcense.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnabcenseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnabcenseMouseExited(evt);
            }
        });
        btnabcense.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnabcenseActionPerformed(evt);
            }
        });
        menuPanel1.add(btnabcense, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 190, 40));

        btnmodule.setBackground(new java.awt.Color(204, 204, 204));
        btnmodule.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnmodule.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-book-27.png"))); // NOI18N
        btnmodule.setText("     Modules");
        btnmodule.setBorder(null);
        btnmodule.setContentAreaFilled(false);
        btnmodule.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnmodule.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnmodule.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnmodule.setIconTextGap(10);
        btnmodule.setOpaque(true);
        btnmodule.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnmoduleMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnmoduleMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnmoduleMouseExited(evt);
            }
        });
        btnmodule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmoduleActionPerformed(evt);
            }
        });
        menuPanel1.add(btnmodule, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 190, 40));
        menuPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(33, 28, -1, -1));

        btnnote.setBackground(new java.awt.Color(204, 204, 204));
        btnnote.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnnote.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-test-passed-filled-27.png"))); // NOI18N
        btnnote.setText("     Notes");
        btnnote.setBorder(null);
        btnnote.setContentAreaFilled(false);
        btnnote.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnnote.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnnote.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnnote.setIconTextGap(10);
        btnnote.setOpaque(true);
        btnnote.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnnoteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnnoteMouseExited(evt);
            }
        });
        btnnote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnoteActionPerformed(evt);
            }
        });
        menuPanel1.add(btnnote, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, 190, 40));

        btnfiliere.setBackground(new java.awt.Color(204, 204, 204));
        btnfiliere.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnfiliere.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-classroom-filled-27.png"))); // NOI18N
        btnfiliere.setText("     Filières");
        btnfiliere.setBorder(null);
        btnfiliere.setContentAreaFilled(false);
        btnfiliere.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnfiliere.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnfiliere.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnfiliere.setIconTextGap(10);
        btnfiliere.setOpaque(true);
        btnfiliere.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnfiliereMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnfiliereMouseExited(evt);
            }
        });
        btnfiliere.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfiliereActionPerformed(evt);
            }
        });
        menuPanel1.add(btnfiliere, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 190, 40));

        btn_inter.setBackground(new java.awt.Color(204, 204, 204));
        btn_inter.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btn_inter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-person-27.png"))); // NOI18N
        btn_inter.setText("     Etudiants");
        btn_inter.setBorder(null);
        btn_inter.setContentAreaFilled(false);
        btn_inter.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_inter.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btn_inter.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btn_inter.setIconTextGap(10);
        btn_inter.setOpaque(true);
        btn_inter.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_interMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_interMouseExited(evt);
            }
        });
        btn_inter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_interActionPerformed(evt);
            }
        });
        menuPanel1.add(btn_inter, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 390, 190, 40));

        btncoor.setBackground(new java.awt.Color(204, 204, 204));
        btncoor.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btncoor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-employee-filled-27.png"))); // NOI18N
        btncoor.setText("    Corps enseignant");
        btncoor.setBorder(null);
        btncoor.setContentAreaFilled(false);
        btncoor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btncoor.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btncoor.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btncoor.setIconTextGap(10);
        btncoor.setOpaque(true);
        btncoor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btncoorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btncoorMouseExited(evt);
            }
        });
        btncoor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncoorActionPerformed(evt);
            }
        });
        menuPanel1.add(btncoor, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, 190, 40));

        btnniveau.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnniveau.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-buy-upgrade-27.png"))); // NOI18N
        btnniveau.setText("     Fin du Semestre");
        btnniveau.setBorder(null);
        btnniveau.setContentAreaFilled(false);
        btnniveau.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau.setIconTextGap(10);
        btnniveau.setOpaque(true);
        btnniveau.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveauMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveauMouseExited(evt);
            }
        });
        btnniveau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveauActionPerformed(evt);
            }
        });
        menuPanel1.add(btnniveau, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 490, 190, 40));
        menuPanel1.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 80, 70));

        btnresultat.setBackground(new java.awt.Color(204, 204, 204));
        btnresultat.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnresultat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-student-male-27.png"))); // NOI18N
        btnresultat.setText("     Résultat");
        btnresultat.setBorder(null);
        btnresultat.setContentAreaFilled(false);
        btnresultat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnresultat.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnresultat.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnresultat.setIconTextGap(10);
        btnresultat.setOpaque(true);
        btnresultat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnresultatMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnresultatMouseExited(evt);
            }
        });
        btnresultat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresultatActionPerformed(evt);
            }
        });
        menuPanel1.add(btnresultat, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 540, 190, 40));

        bodyPanel1.add(menuPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 190, 610));

        mainPanel.setBackground(new java.awt.Color(26, 188, 156));
        mainPanel.setLayout(new java.awt.CardLayout());

        homePanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("MACA - MENU HOME");

        jLabel30.setBackground(new java.awt.Color(0, 204, 51));
        jLabel30.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel30.setText("des étudiants");
        jLabel30.setToolTipText("");

        jLabel31.setBackground(new java.awt.Color(0, 204, 51));
        jLabel31.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel31.setText("Bienvenue dans l'espace");
        jLabel31.setToolTipText("");

        jLabel11.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout homePanelLayout = new javax.swing.GroupLayout(homePanel);
        homePanel.setLayout(homePanelLayout);
        homePanelLayout.setHorizontalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homePanelLayout.createSequentialGroup()
                .addGroup(homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(homePanelLayout.createSequentialGroup()
                        .addGap(299, 299, 299)
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(homePanelLayout.createSequentialGroup()
                        .addGap(237, 237, 237)
                        .addGroup(homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(163, Short.MAX_VALUE))
            .addGroup(homePanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        homePanelLayout.setVerticalGroup(
            homePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(homePanelLayout.createSequentialGroup()
                .addGap(111, 111, 111)
                .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1458, 1458, 1458)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainPanel.add(homePanel, "card2");

        retardpanel.setBackground(new java.awt.Color(255, 255, 255));

        abcensepanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel10.setText("Choisir un module");

        jLabel106.setFont(new java.awt.Font("Traditional Arabic", 0, 12)); // NOI18N
        jLabel106.setText("Nom du Module");

        jButton13.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-eye-27.png"))); // NOI18N
        jButton13.setText("Voir");
        jButton13.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        jButton13.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton31.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-undo-27.png"))); // NOI18N
        jButton31.setText("Retour");
        jButton31.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        jButton31.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });

        filiere_ret.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere_ret.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiere_retMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiere_retMouseExited(evt);
            }
        });

        jLabel111.setFont(new java.awt.Font("Traditional Arabic", 0, 12)); // NOI18N
        jLabel111.setText("Filière");

        module_ret.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un module" }));
        module_ret.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                module_retMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                module_retMouseExited(evt);
            }
        });
        module_ret.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                module_retActionPerformed(evt);
            }
        });

        jLabel114.setFont(new java.awt.Font("Traditional Arabic", 0, 12)); // NOI18N
        jLabel114.setText("Option");

        option_ret.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option_ret.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                option_retMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                option_retMouseExited(evt);
            }
        });

        jLabel115.setFont(new java.awt.Font("Traditional Arabic", 0, 12)); // NOI18N
        jLabel115.setText("Niveau");

        niveau_ret.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un niveau" }));
        niveau_ret.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                niveau_retMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                niveau_retMouseExited(evt);
            }
        });

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/res1.jpg"))); // NOI18N

        javax.swing.GroupLayout abcensepanel2Layout = new javax.swing.GroupLayout(abcensepanel2);
        abcensepanel2.setLayout(abcensepanel2Layout);
        abcensepanel2Layout.setHorizontalGroup(
            abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(abcensepanel2Layout.createSequentialGroup()
                .addGap(226, 226, 226)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(abcensepanel2Layout.createSequentialGroup()
                .addGroup(abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(abcensepanel2Layout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addGroup(abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel106, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel114, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel115, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel111, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(niveau_ret, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(option_ret, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(filiere_ret, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(module_ret, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(93, 93, 93))
                    .addGroup(abcensepanel2Layout.createSequentialGroup()
                        .addGap(305, 305, 305)
                        .addGroup(abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(94, 94, 94))
        );
        abcensepanel2Layout.setVerticalGroup(
            abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(abcensepanel2Layout.createSequentialGroup()
                .addContainerGap(128, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(104, 104, 104)
                .addGroup(abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(abcensepanel2Layout.createSequentialGroup()
                        .addComponent(jLabel106)
                        .addGap(50, 50, 50)
                        .addComponent(jButton13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton31)
                        .addGap(137, 137, 137))
                    .addGroup(abcensepanel2Layout.createSequentialGroup()
                        .addGroup(abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filiere_ret, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel111))
                        .addGap(14, 14, 14)
                        .addGroup(abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(abcensepanel2Layout.createSequentialGroup()
                                .addGroup(abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(option_ret, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel114))
                                .addGap(18, 18, 18)
                                .addGroup(abcensepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(niveau_ret, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel115))
                                .addGap(18, 18, 18)
                                .addComponent(module_ret, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(151, 151, 151))))
        );

        javax.swing.GroupLayout retardpanelLayout = new javax.swing.GroupLayout(retardpanel);
        retardpanel.setLayout(retardpanelLayout);
        retardpanelLayout.setHorizontalGroup(
            retardpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(abcensepanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        retardpanelLayout.setVerticalGroup(
            retardpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(retardpanelLayout.createSequentialGroup()
                .addComponent(abcensepanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        mainPanel.add(retardpanel, "card3");

        modulepanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel20.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel20.setText("Les modules");

        jLabel21.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel21.setText("Nom du module");

        jLabel22.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel22.setText(" Nombre des éléments");

        Table_Element.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Table_Element.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Table_ElementMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(Table_Element);

        jLabel26.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel26.setText("Nom d'élément");

        jLabel28.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel28.setText("Les éléments");

        jLabel50.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel50.setText("Nom de module");

        jLabel91.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel91.setText("Volume d'horaire");

        jLabel92.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel92.setText("Intervenant");

        jLabel93.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel93.setText("Volume d'horaire");

        mod_elem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un module" }));
        mod_elem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mod_elemMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                mod_elemMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                mod_elemMouseExited(evt);
            }
        });

        jButton26.setBackground(new java.awt.Color(0, 0, 204));
        jButton26.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton26.setForeground(new java.awt.Color(255, 255, 255));
        jButton26.setText("Sauvegarder");
        jButton26.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        jButton27.setBackground(new java.awt.Color(0, 0, 204));
        jButton27.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton27.setForeground(new java.awt.Color(255, 255, 255));
        jButton27.setText("Supprimer");
        jButton27.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        jButton28.setBackground(new java.awt.Color(0, 0, 204));
        jButton28.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton28.setForeground(new java.awt.Color(255, 255, 255));
        jButton28.setText("Sauvegarder");
        jButton28.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        jButton29.setBackground(new java.awt.Color(0, 0, 204));
        jButton29.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton29.setForeground(new java.awt.Color(255, 255, 255));
        jButton29.setText("Supprimer");
        jButton29.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });

        jLabel94.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel94.setText("Filiere");

        jLabel95.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel95.setText("Niveau");

        jLabel96.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel96.setText("Option");

        filiere_mod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere_mod.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                filiere_modMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiere_modMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiere_modMouseExited(evt);
            }
        });

        option_mod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option_mod.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                option_modMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                option_modMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                option_modMouseExited(evt);
            }
        });

        niveau_mod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un niveau" }));
        niveau_mod.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                niveau_modMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                niveau_modMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                niveau_modMouseExited(evt);
            }
        });
        niveau_mod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                niveau_modActionPerformed(evt);
            }
        });
        niveau_mod.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                niveau_modKeyPressed(evt);
            }
        });

        inter_elem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un intervenant" }));
        inter_elem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inter_elemMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                inter_elemMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                inter_elemMouseExited(evt);
            }
        });

        horaire_mod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "50 heures", "120 heures" }));

        jLabel124.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel124.setText("Nature du module");

        type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Majeur", "Complémentaire", "Stage" }));

        jButton44.setBackground(new java.awt.Color(0, 0, 204));
        jButton44.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton44.setForeground(new java.awt.Color(255, 255, 255));
        jButton44.setText("Modifier");
        jButton44.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton44ActionPerformed(evt);
            }
        });

        jButton46.setBackground(new java.awt.Color(0, 0, 204));
        jButton46.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton46.setForeground(new java.awt.Color(255, 255, 255));
        jButton46.setText("Modifier");
        jButton46.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton46ActionPerformed(evt);
            }
        });

        jButton47.setBackground(new java.awt.Color(0, 0, 204));
        jButton47.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton47.setForeground(new java.awt.Color(255, 255, 255));
        jButton47.setText("Afficher");
        jButton47.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton47ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout modulepanelLayout = new javax.swing.GroupLayout(modulepanel);
        modulepanel.setLayout(modulepanelLayout);
        modulepanelLayout.setHorizontalGroup(
            modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modulepanelLayout.createSequentialGroup()
                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulepanelLayout.createSequentialGroup()
                        .addGap(164, 164, 164)
                        .addComponent(jButton27))
                    .addGroup(modulepanelLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(modulepanelLayout.createSequentialGroup()
                                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel91, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel124, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(36, 36, 36)
                                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(horaire_mod, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(type, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(modulepanelLayout.createSequentialGroup()
                                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel94, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel96, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel95, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(36, 36, 36)
                                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(filiere_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(option_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(niveau_mod, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(modulepanelLayout.createSequentialGroup()
                                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(modulepanelLayout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(72, 72, 72))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulepanelLayout.createSequentialGroup()
                                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nbr_elem, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(nom_module, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(modulepanelLayout.createSequentialGroup()
                                .addComponent(jButton26)
                                .addGap(18, 18, 18)
                                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButton47, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton44, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(18, 18, 18)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(modulepanelLayout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(modulepanelLayout.createSequentialGroup()
                                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel50)
                                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel92, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel93, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGap(33, 33, 33)
                                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(nom_elem, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(mod_elem, javax.swing.GroupLayout.Alignment.LEADING, 0, 195, Short.MAX_VALUE))
                                    .addComponent(inter_elem, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(horaire_elem, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(32, 32, 32))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulepanelLayout.createSequentialGroup()
                                .addComponent(jButton28)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton29)
                                .addGap(76, 76, 76)))))
                .addContainerGap(22, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulepanelLayout.createSequentialGroup()
                .addGap(141, 141, 141)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton46, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(183, 183, 183))
        );
        modulepanelLayout.setVerticalGroup(
            modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modulepanelLayout.createSequentialGroup()
                .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(modulepanelLayout.createSequentialGroup()
                        .addGap(147, 147, 147)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel26)
                            .addComponent(nom_elem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(mod_elem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel50))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel92)
                            .addComponent(inter_elem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel93)
                            .addComponent(horaire_elem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton28)
                            .addComponent(jButton46)
                            .addComponent(jButton29))
                        .addGap(49, 49, 49)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(modulepanelLayout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 74, Short.MAX_VALUE)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nom_module, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nbr_elem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(modulepanelLayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabel91))
                            .addComponent(horaire_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel124)
                            .addComponent(type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filiere_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel94))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(option_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel96))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(niveau_mod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel95))
                        .addGap(76, 76, 76)
                        .addGroup(modulepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton26)
                            .addComponent(jButton44)
                            .addComponent(jButton27))
                        .addGap(46, 46, 46)
                        .addComponent(jButton47)
                        .addGap(12, 12, 12)))
                .addGap(49, 49, 49))
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        mainPanel.add(modulepanel, "card4");

        notepanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel23.setText("Session normale");

        jLabel35.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel35.setText("Module");

        jLabel47.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel47.setText("Filiere");

        jLabel48.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel48.setText("Option");

        filiere_etud.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere_etud.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                filiere_etudMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiere_etudMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiere_etudMouseExited(evt);
            }
        });

        jLabel49.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/images (1).jpg"))); // NOI18N

        jLabel103.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel103.setText("Niveau");

        niveau_etud.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un niveau" }));
        niveau_etud.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                niveau_etudMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                niveau_etudMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                niveau_etudMouseExited(evt);
            }
        });

        option_etud.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option_etud.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                option_etudMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                option_etudMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                option_etudMouseExited(evt);
            }
        });

        module_etud.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un module" }));
        module_etud.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                module_etudMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                module_etudMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                module_etudMouseExited(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));

        btnresultat1.setBackground(new java.awt.Color(204, 204, 204));
        btnresultat1.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnresultat1.setText("           Session normale");
        btnresultat1.setBorder(null);
        btnresultat1.setContentAreaFilled(false);
        btnresultat1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnresultat1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnresultat1.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnresultat1.setIconTextGap(10);
        btnresultat1.setOpaque(true);
        btnresultat1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnresultat1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnresultat1MouseExited(evt);
            }
        });
        btnresultat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresultat1ActionPerformed(evt);
            }
        });

        btnresultat2.setBackground(new java.awt.Color(204, 204, 204));
        btnresultat2.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnresultat2.setText("Session rattrapage");
        btnresultat2.setBorder(null);
        btnresultat2.setContentAreaFilled(false);
        btnresultat2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnresultat2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnresultat2.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnresultat2.setIconTextGap(10);
        btnresultat2.setOpaque(true);
        btnresultat2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnresultat2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnresultat2MouseExited(evt);
            }
        });
        btnresultat2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresultat2ActionPerformed(evt);
            }
        });

        btnresultat3.setBackground(new java.awt.Color(204, 204, 204));
        btnresultat3.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        btnresultat3.setText("Voir les notes");
        btnresultat3.setBorder(null);
        btnresultat3.setContentAreaFilled(false);
        btnresultat3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnresultat3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnresultat3.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnresultat3.setIconTextGap(10);
        btnresultat3.setOpaque(true);
        btnresultat3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnresultat3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnresultat3MouseExited(evt);
            }
        });
        btnresultat3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresultat3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(btnresultat1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnresultat2, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnresultat3, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnresultat1, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
            .addComponent(btnresultat2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnresultat3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jButton56.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton56.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-curved-arrow-27.png"))); // NOI18N
        jButton56.setText("Suivant");
        jButton56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton56ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout notepanelLayout = new javax.swing.GroupLayout(notepanel);
        notepanel.setLayout(notepanelLayout);
        notepanelLayout.setHorizontalGroup(
            notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(notepanelLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(notepanelLayout.createSequentialGroup()
                        .addGroup(notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(notepanelLayout.createSequentialGroup()
                                .addGroup(notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel103, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel47)
                                    .addComponent(jLabel48)
                                    .addComponent(jLabel35))
                                .addGap(112, 112, 112)
                                .addGroup(notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(option_etud, 0, 216, Short.MAX_VALUE)
                                    .addComponent(niveau_etud, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(module_etud, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(filiere_etud, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(notepanelLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButton56, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(53, 53, 53)
                        .addComponent(jLabel49)
                        .addGap(58, 58, 58))
                    .addGroup(notepanelLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        notepanelLayout.setVerticalGroup(
            notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(notepanelLayout.createSequentialGroup()
                .addGroup(notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(notepanelLayout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addComponent(jLabel49)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(notepanelLayout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(jLabel23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 102, Short.MAX_VALUE)
                        .addGroup(notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel47)
                            .addComponent(filiere_etud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel48)
                            .addComponent(option_etud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel103)
                            .addComponent(niveau_etud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(notepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel35)
                            .addComponent(module_etud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(85, 85, 85)
                        .addComponent(jButton56, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(86, 86, 86)))
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        mainPanel.add(notepanel, "card5");

        abcensepanel.setBackground(new java.awt.Color(255, 255, 255));
        abcensepanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel3.setText("Absence & Retard");
        abcensepanel.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 60, 415, 23));

        jLabel6.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel6.setText("Nom du Module");
        abcensepanel.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 146, -1));

        jLabel7.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel7.setText("Nom d'élément");
        abcensepanel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 146, -1));

        jLabel8.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel8.setText("Date");
        abcensepanel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, 146, -1));

        jLabel9.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel9.setText("Justification");
        abcensepanel.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, 146, -1));

        just_abc.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        just_abc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Absence justifiée", "Absence non justifiée" }));
        just_abc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                just_abcMouseEntered(evt);
            }
        });
        abcensepanel.add(just_abc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 400, 230, -1));

        niveau_abc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un niveau" }));
        niveau_abc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                niveau_abcMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                niveau_abcMouseExited(evt);
            }
        });
        abcensepanel.add(niveau_abc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 220, 230, -1));

        jLabel46.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel46.setText("Niveau");
        abcensepanel.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 77, -1));

        module_abc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un module" }));
        module_abc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                module_abcMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                module_abcMouseExited(evt);
            }
        });
        abcensepanel.add(module_abc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 250, 230, -1));

        jLabel112.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel112.setText("Filiere");
        abcensepanel.add(jLabel112, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 77, -1));

        jLabel113.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel113.setText("Option");
        abcensepanel.add(jLabel113, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 77, -1));

        filiere_abc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere_abc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiere_abcMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiere_abcMouseExited(evt);
            }
        });
        abcensepanel.add(filiere_abc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 230, -1));

        option_abc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option_abc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                option_abcMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                option_abcMouseExited(evt);
            }
        });
        abcensepanel.add(option_abc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 190, 230, -1));

        elem_abc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un élément" }));
        elem_abc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                elem_abcMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                elem_abcMouseExited(evt);
            }
        });
        abcensepanel.add(elem_abc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 230, -1));

        date_abc.setDateFormatString("yyyy-MM-dd");
        abcensepanel.add(date_abc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 340, 230, -1));

        jLabel76.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel76.setText("Durée");
        abcensepanel.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 146, -1));

        duree_abc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Séance 1", "Séance 2", "Séance 3", "Séance 4" }));
        duree_abc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                duree_abcMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                duree_abcMouseExited(evt);
            }
        });
        abcensepanel.add(duree_abc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 370, 230, -1));

        jLabel13.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel13.setText("Type");
        abcensepanel.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 146, -1));

        type_abc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Absence", "Retard" }));
        type_abc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                type_abcMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                type_abcMouseExited(evt);
            }
        });
        type_abc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                type_abcActionPerformed(evt);
            }
        });
        abcensepanel.add(type_abc, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 310, 230, -1));

        jButton73.setBackground(new java.awt.Color(0, 0, 204));
        jButton73.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton73.setForeground(new java.awt.Color(255, 255, 255));
        jButton73.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-curved-arrow-27.png"))); // NOI18N
        jButton73.setText("Suivant");
        jButton73.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton73.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        jButton73.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton73jButton4ActionPerformed(evt);
            }
        });
        abcensepanel.add(jButton73, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 480, 110, -1));

        mainPanel.add(abcensepanel, "card7");

        filierepanel.setBackground(new java.awt.Color(255, 255, 255));

        modulepanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel32.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel32.setText("Les filières");

        jLabel36.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel36.setText("Intitulé de la  filière");

        Table_Option.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Table_Option.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Table_OptionMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(Table_Option);

        Table_Filiere.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Table_Filiere.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Table_FiliereMouseClicked(evt);
            }
        });
        jScrollPane10.setViewportView(Table_Filiere);

        jLabel39.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel39.setText("Nom d'option");

        jLabel41.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel41.setText("Les options");

        jButton8.setBackground(new java.awt.Color(0, 0, 204));
        jButton8.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-plus-math-filled-27 (1).png"))); // NOI18N
        jButton8.setText("Ajouter");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        Supprimer.setBackground(new java.awt.Color(0, 0, 204));
        Supprimer.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        Supprimer.setForeground(new java.awt.Color(255, 255, 255));
        Supprimer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-trash-27.png"))); // NOI18N
        Supprimer.setText("Supprimer");
        Supprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SupprimerActionPerformed(evt);
            }
        });

        jButton10.setBackground(new java.awt.Color(0, 0, 204));
        jButton10.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-trash-27.png"))); // NOI18N
        jButton10.setText("Supprimer");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setBackground(new java.awt.Color(0, 0, 204));
        jButton11.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-plus-math-filled-27 (1).png"))); // NOI18N
        jButton11.setText("Ajouter");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel40.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel40.setText("Nom de la filière");

        nom_filiere.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        nom_filiere.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nom_filiereMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                nom_filiereMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                nom_filiereMouseExited(evt);
            }
        });

        jLabel80.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel80.setText("Code d'option");

        jButton48.setBackground(new java.awt.Color(0, 0, 204));
        jButton48.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton48.setForeground(new java.awt.Color(255, 255, 255));
        jButton48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-edit-file-27.png"))); // NOI18N
        jButton48.setText("Modifier");
        jButton48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton48ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 0, 204));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout modulepanel2Layout = new javax.swing.GroupLayout(modulepanel2);
        modulepanel2.setLayout(modulepanel2Layout);
        modulepanel2Layout.setHorizontalGroup(
            modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modulepanel2Layout.createSequentialGroup()
                .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(modulepanel2Layout.createSequentialGroup()
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(modulepanel2Layout.createSequentialGroup()
                                .addGap(170, 170, 170)
                                .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(modulepanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                        .addGap(24, 24, 24))
                    .addGroup(modulepanel2Layout.createSequentialGroup()
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(modulepanel2Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(modulepanel2Layout.createSequentialGroup()
                                .addGap(44, 44, 44)
                                .addComponent(jButton8)))
                        .addGap(31, 31, 31)
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Supprimer, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nomfiliere, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)))
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(modulepanel2Layout.createSequentialGroup()
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(modulepanel2Layout.createSequentialGroup()
                                .addGap(154, 154, 154)
                                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(modulepanel2Layout.createSequentialGroup()
                                .addGap(54, 54, 54)
                                .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(modulepanel2Layout.createSequentialGroup()
                                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(37, 37, 37)
                                        .addComponent(nom_filiere, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(modulepanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel80, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(50, 50, 50)
                                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(nom_option, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(code, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulepanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulepanel2Layout.createSequentialGroup()
                                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 421, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(22, 22, 22))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulepanel2Layout.createSequentialGroup()
                                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton48)
                                .addGap(18, 18, 18)
                                .addComponent(jButton10)
                                .addGap(63, 63, 63))))))
        );
        modulepanel2Layout.setVerticalGroup(
            modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modulepanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(modulepanel2Layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel36)
                            .addComponent(nomfiliere, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Supprimer)
                            .addComponent(jButton8))
                        .addGap(49, 49, 49)
                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(modulepanel2Layout.createSequentialGroup()
                        .addGap(104, 104, 104)
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel80)
                            .addComponent(code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14)
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel40)
                            .addComponent(nom_filiere, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nom_option, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel39))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 118, Short.MAX_VALUE)
                        .addGroup(modulepanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton48)
                            .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton10))
                        .addGap(45, 45, 45)
                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(75, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout filierepanelLayout = new javax.swing.GroupLayout(filierepanel);
        filierepanel.setLayout(filierepanelLayout);
        filierepanelLayout.setHorizontalGroup(
            filierepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 890, Short.MAX_VALUE)
            .addGroup(filierepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(modulepanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        filierepanelLayout.setVerticalGroup(
            filierepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
            .addGroup(filierepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(modulepanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mainPanel.add(filierepanel, "card8");

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel34.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel34.setText("Fin du semestre");

        jLabel69.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel69.setText("Filiere");

        filiere_etud2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere_etud2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                filiere_etud2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiere_etud2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiere_etud2MouseExited(evt);
            }
        });

        jLabel78.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel78.setText("Option");

        option_etud2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option_etud2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                option_etud2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                option_etud2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                option_etud2MouseExited(evt);
            }
        });

        jLabel104.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel104.setText("Niveau");

        niveau_etud2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un niveau" }));
        niveau_etud2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                niveau_etud2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                niveau_etud2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                niveau_etud2MouseExited(evt);
            }
        });

        jButton14.setBackground(new java.awt.Color(0, 0, 204));
        jButton14.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton14.setForeground(new java.awt.Color(255, 255, 255));
        jButton14.setText("Valider");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/infirmier.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel104, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel69)
                    .addComponent(jLabel78))
                .addGap(112, 112, 112)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(option_etud2, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(filiere_etud2, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(niveau_etud2, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(300, 300, 300)
                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 104, Short.MAX_VALUE)
                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(93, 93, 93)
                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(535, Short.MAX_VALUE)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(246, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel69)
                    .addComponent(filiere_etud2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel78)
                    .addComponent(option_etud2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel104)
                    .addComponent(niveau_etud2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addComponent(jButton14)
                        .addGap(121, 121, 121))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE))))
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(117, 117, 117)
                    .addComponent(jLabel34)
                    .addContainerGap(465, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout niveaupanelLayout = new javax.swing.GroupLayout(niveaupanel);
        niveaupanel.setLayout(niveaupanelLayout);
        niveaupanelLayout.setHorizontalGroup(
            niveaupanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        niveaupanelLayout.setVerticalGroup(
            niveaupanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        mainPanel.add(niveaupanel, "card9");

        inscriptionpanel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel51.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel51.setText("Informations personnells");
        jLabel51.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, new java.awt.Color(0, 0, 0), java.awt.Color.white));

        jLabel52.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel52.setText("CNE");

        jLabel53.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel53.setText("CIN");

        jLabel54.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel54.setText("Nom");

        jLabel55.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel55.setText("Prénom");

        jLabel56.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel56.setText("Sexe");

        jLabel57.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel57.setText("Date de naissance");

        cin.setText(" ");

        nom.setText(" ");

        prenom.setText(" ");

        femme.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup2.add(femme);
        femme.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        femme.setText("Femme");
        femme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                femmeActionPerformed(evt);
            }
        });

        homme.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup2.add(homme);
        homme.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        homme.setText("Homme");
        homme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hommeActionPerformed(evt);
            }
        });

        jLabel58.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel58.setText("Lieux de naissance");

        lieux.setText(" ");

        jLabel59.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel59.setText("Adresse    1");

        adr1.setText(" ");

        jLabel60.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel60.setText("Adresse    2");

        adr2.setText(" ");
        adr2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                adr2KeyPressed(evt);
            }
        });

        jLabel61.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel61.setText("Télephone 1");

        tel1.setText(" ");
        tel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tel1ActionPerformed(evt);
            }
        });
        tel1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tel1KeyPressed(evt);
            }
        });

        label.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        label.setText("       Photo");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addComponent(label, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(label1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(label1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(label, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        parcourire.setBackground(new java.awt.Color(0, 0, 204));
        parcourire.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        parcourire.setText("Parcourire..");
        parcourire.setToolTipText("");
        parcourire.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        parcourire.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                parcourireActionPerformed(evt);
            }
        });

        jButton17.setBackground(new java.awt.Color(0, 0, 204));
        jButton17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-curved-arrow-27.png"))); // NOI18N
        jButton17.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jLabel79.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel79.setText("Télephone 2");

        tel2.setText(" ");
        tel2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tel2KeyPressed(evt);
            }
        });

        naissance.setDateFormatString("yyyy-MM-dd");

        label_number.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_number.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout inscriptionpanelLayout = new javax.swing.GroupLayout(inscriptionpanel);
        inscriptionpanel.setLayout(inscriptionpanelLayout);
        inscriptionpanelLayout.setHorizontalGroup(
            inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscriptionpanelLayout.createSequentialGroup()
                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addComponent(jLabel52, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(90, 90, 90)
                                .addComponent(cne_p, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addComponent(jLabel53)
                                .addGap(176, 176, 176)
                                .addComponent(cin, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addComponent(jLabel54)
                                .addGap(172, 172, 172)
                                .addComponent(nom, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addComponent(jLabel55, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(90, 90, 90)
                                .addComponent(prenom, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(90, 90, 90)
                                .addComponent(femme, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addComponent(homme, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                            .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(90, 90, 90)
                                            .addComponent(adr1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                            .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(90, 90, 90)
                                            .addComponent(adr2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                            .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel79, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                                    .addGap(90, 90, 90)
                                                    .addComponent(tel2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscriptionpanelLayout.createSequentialGroup()
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(tel1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel58, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(90, 90, 90)
                                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(lieux, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                                            .addComponent(naissance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(label_number, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                        .addGap(123, 123, 123)
                                        .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscriptionpanelLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(189, 189, 189)))
                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(url, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(parcourire, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(59, 59, 59))
        );
        inscriptionpanelLayout.setVerticalGroup(
            inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel51)
                        .addGap(18, 18, 18)
                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel52)
                            .addComponent(cne_p, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel53)
                            .addComponent(cin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel54))
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(nom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(prenom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel55)))
                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(parcourire, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(url, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(19, 19, 19)
                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel56)
                    .addComponent(femme)
                    .addComponent(homme))
                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel57))
                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(naissance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(17, 17, 17)
                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel58)
                    .addComponent(lieux, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel59)
                    .addComponent(adr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(adr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel61)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel79))
                    .addGroup(inscriptionpanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label_number, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(inscriptionpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(inscriptionpanelLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(tel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(91, Short.MAX_VALUE))
        );

        mainPanel.add(inscriptionpanel, "card10");

        inscription2panel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel62.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel62.setText("Nationalité");

        nationalite.setText(" ");

        jLabel63.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel63.setText("Adresse Actuelle");

        adr_actuel.setText(" ");

        jLabel64.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel64.setText("Situation de famille");

        situation.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        situation.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Célibataire", "Marié (e)", "Veuf (ve)", "Dévorcé (e)" }));
        situation.setSelectedIndex(1);
        situation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                situationActionPerformed(evt);
            }
        });

        jLabel65.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel65.setText("Numéro WhatsApp");

        email1.setText(" ");

        jLabel66.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel66.setText("Email 1");

        jLabel67.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel67.setText("Email 2");

        email2.setText(" ");

        jLabel82.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel82.setText("Informations personnells");
        jLabel82.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.black, java.awt.Color.white));

        whatsup.setText(" ");
        whatsup.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                whatsupKeyPressed(evt);
            }
        });

        jButton18.setBackground(new java.awt.Color(0, 0, 204));
        jButton18.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-curved-arrow-27.png"))); // NOI18N
        jButton18.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jLabel85.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel85.setText("Avez vous des enfants");

        label_enf.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        label_enf.setText("Nombre d'enfants");

        nbr_enfant.setText(" ");
        nbr_enfant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nbr_enfantActionPerformed(evt);
            }
        });
        nbr_enfant.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nbr_enfantKeyPressed(evt);
            }
        });

        Oui.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(Oui);
        Oui.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Oui.setText("Oui");
        Oui.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                OuiMouseEntered(evt);
            }
        });
        Oui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OuiActionPerformed(evt);
            }
        });

        Non.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(Non);
        Non.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Non.setText("Non");
        Non.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NonActionPerformed(evt);
            }
        });

        jButton25.setBackground(new java.awt.Color(0, 0, 204));
        jButton25.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-undo-27.png"))); // NOI18N
        jButton25.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout inscription2panelLayout = new javax.swing.GroupLayout(inscription2panel);
        inscription2panel.setLayout(inscription2panelLayout);
        inscription2panelLayout.setHorizontalGroup(
            inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inscription2panelLayout.createSequentialGroup()
                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(whatsup, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(inscription2panelLayout.createSequentialGroup()
                                    .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(90, 90, 90)
                                    .addComponent(nationalite, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(inscription2panelLayout.createSequentialGroup()
                                    .addComponent(jLabel63, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(44, 44, 44)
                                    .addComponent(adr_actuel, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(inscription2panelLayout.createSequentialGroup()
                                    .addComponent(jLabel64, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(90, 90, 90)
                                    .addComponent(situation, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(inscription2panelLayout.createSequentialGroup()
                                        .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(inscription2panelLayout.createSequentialGroup()
                                                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel67, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel66, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(label_enf, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(84, 84, 84))
                                            .addGroup(inscription2panelLayout.createSequentialGroup()
                                                .addComponent(jLabel85, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(38, 38, 38)))
                                        .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(email1)
                                            .addGroup(inscription2panelLayout.createSequentialGroup()
                                                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(email2, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(nbr_enfant, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(inscription2panelLayout.createSequentialGroup()
                                                        .addComponent(Oui, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(6, 6, 6)
                                                        .addComponent(Non, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGap(0, 0, Short.MAX_VALUE))))
                                    .addGroup(inscription2panelLayout.createSequentialGroup()
                                        .addComponent(jLabel65)
                                        .addGap(267, 267, 267))))))
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(253, 253, 253)
                        .addComponent(jLabel82, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(295, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription2panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton25)
                .addGap(18, 18, 18)
                .addComponent(jButton18)
                .addGap(250, 250, 250))
        );
        inscription2panelLayout.setVerticalGroup(
            inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inscription2panelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel82)
                .addGap(44, 44, 44)
                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel62)
                    .addComponent(nationalite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel63)
                    .addComponent(adr_actuel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel64)
                    .addComponent(situation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel65))
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(whatsup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel66, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(email1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jLabel67))
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(email2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton25, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(inscription2panelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Oui)
                                .addComponent(jLabel85))
                            .addComponent(Non))
                        .addGap(18, 18, 18)
                        .addGroup(inscription2panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(label_enf)
                            .addComponent(nbr_enfant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(134, Short.MAX_VALUE))
        );

        mainPanel.add(inscription2panel, "card11");

        inscription3panel.setBackground(new java.awt.Color(255, 255, 255));

        jLabel73.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel73.setText("Année d'obtention du bac");

        jLabel74.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel74.setText("Moyenne du bac");

        jLabel75.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel75.setText("Mention du bac");

        mention.setText(" ");

        moyenne.setText(" ");
        moyenne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                moyenneActionPerformed(evt);
            }
        });
        moyenne.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                moyenneKeyPressed(evt);
            }
        });

        obtention.setText(" ");
        obtention.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                obtentionKeyPressed(evt);
            }
        });

        jLabel77.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel77.setText("Date d'inscription");

        jLabel81.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel81.setText("Lycée");

        jLabel83.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel83.setText("Filière");

        lycee.setText(" ");

        jLabel68.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel68.setText("Boursièr (e) ?");

        buttonGroup3.add(oui);
        oui.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        oui.setText("Oui");
        oui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ouiActionPerformed(evt);
            }
        });

        buttonGroup3.add(non);
        non.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        non.setText("Non");
        non.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nonActionPerformed(evt);
            }
        });

        jLabel84.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel84.setText("Option");

        jButton23.setBackground(new java.awt.Color(0, 0, 204));
        jButton23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-curved-arrow-27.png"))); // NOI18N
        jButton23.setToolTipText("");
        jButton23.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jButton24.setBackground(new java.awt.Color(0, 0, 204));
        jButton24.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-undo-27.png"))); // NOI18N
        jButton24.setToolTipText("");
        jButton24.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        filiere.setBackground(new java.awt.Color(204, 204, 255));
        filiere.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                filiereMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiereMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiereMouseExited(evt);
            }
        });

        option.setBackground(new java.awt.Color(204, 204, 255));
        option.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                optionMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                optionMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                optionMouseExited(evt);
            }
        });

        jLabel90.setBackground(new java.awt.Color(51, 51, 255));
        jLabel90.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel90.setText("Informations scolaire");
        jLabel90.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.black, java.awt.Color.white));

        inscription.setDateFormatString("yyyy-MM-dd");

        javax.swing.GroupLayout inscription3panelLayout = new javax.swing.GroupLayout(inscription3panel);
        inscription3panel.setLayout(inscription3panelLayout);
        inscription3panelLayout.setHorizontalGroup(
            inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription3panelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton24)
                .addGap(18, 18, 18)
                .addComponent(jButton23)
                .addGap(193, 193, 193))
            .addGroup(inscription3panelLayout.createSequentialGroup()
                .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription3panelLayout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscription3panelLayout.createSequentialGroup()
                                .addComponent(jLabel74, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(90, 90, 90)
                                .addComponent(moyenne, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(inscription3panelLayout.createSequentialGroup()
                                .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel75, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel81, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel83, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel84, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(90, 90, 90)
                                .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lycee)
                                    .addComponent(mention)
                                    .addComponent(filiere, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(option, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(inscription3panelLayout.createSequentialGroup()
                                .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel68)
                                    .addComponent(jLabel73)
                                    .addComponent(jLabel77, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(57, 57, 57)
                                .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(obtention)
                                    .addGroup(inscription3panelLayout.createSequentialGroup()
                                        .addComponent(oui)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(non)
                                        .addGap(36, 36, 36))
                                    .addComponent(inscription, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(inscription3panelLayout.createSequentialGroup()
                        .addGap(265, 265, 265)
                        .addComponent(jLabel90, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(383, Short.MAX_VALUE))
        );
        inscription3panelLayout.setVerticalGroup(
            inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inscription3panelLayout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jLabel90)
                .addGap(73, 73, 73)
                .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(inscription3panelLayout.createSequentialGroup()
                        .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel77)
                            .addComponent(inscription, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(oui)
                            .addComponent(non)
                            .addComponent(jLabel68))
                        .addGap(18, 18, 18)
                        .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel73)
                            .addComponent(obtention, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel74, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(moyenne, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel75)
                            .addComponent(mention, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel81)
                            .addComponent(lycee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscription3panelLayout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(filiere, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription3panelLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel83)))
                        .addGap(18, 18, 18)
                        .addComponent(option, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel84))
                .addGap(45, 45, 45)
                .addGroup(inscription3panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton24, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(60, Short.MAX_VALUE))
        );

        mainPanel.add(inscription3panel, "card12");

        inscription4panel.setBackground(new java.awt.Color(255, 255, 255));

        logiciel.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        logiciel.setText("Les logiciels maîtrisés");

        jLabel71.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel71.setText("Formation antérieure");

        langue.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        langue.setText("Les langues maîtrisées");

        jLabel89.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel89.setText("Les compétences");
        jLabel89.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.white, java.awt.Color.white, java.awt.Color.black, java.awt.Color.white));

        anterieure.setColumns(20);
        anterieure.setRows(5);
        jScrollPane20.setViewportView(anterieure);

        num_insc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                num_inscMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                num_inscMouseExited(evt);
            }
        });

        insc.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        insc.setText("Numéro d'inscription");

        jLabel161.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel161.setText("Niveau de la langue");

        Ar.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        Ar.setText("Arabe");
        Ar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ArActionPerformed(evt);
            }
        });

        jLabel70.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel70.setText("Diplôme universitaire ");

        jLabel87.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel87.setText("obtenus aprés le bac");

        jLabel72.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel72.setText("Formation attelier");

        diplome.setColumns(20);
        diplome.setRows(5);
        jScrollPane19.setViewportView(diplome);

        attelier.setColumns(20);
        attelier.setRows(5);
        jScrollPane18.setViewportView(attelier);

        jPanel8.setBackground(new java.awt.Color(204, 204, 204));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton19.setBackground(new java.awt.Color(0, 0, 204));
        jButton19.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 255, 255));
        jButton19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-add-user-group-man-man-filled-27.png"))); // NOI18N
        jButton19.setText("Sauvegarder");
        jButton19.setActionCommand("");
        jButton19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton19MouseEntered(evt);
            }
        });
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 10, -1, 32));

        jButton22.setBackground(new java.awt.Color(0, 0, 204));
        jButton22.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton22.setForeground(new java.awt.Color(255, 255, 255));
        jButton22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-undo-27.png"))); // NOI18N
        jButton22.setText("Retour");
        jButton22.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton22MouseEntered(evt);
            }
        });
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton22, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 132, 32));

        jButton20.setBackground(new java.awt.Color(0, 0, 204));
        jButton20.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton20.setForeground(new java.awt.Color(255, 255, 255));
        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-writer-male-27.png"))); // NOI18N
        jButton20.setText("Modifier");
        jButton20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton20MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton20MouseEntered(evt);
            }
        });
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton20, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, 137, 32));

        jButton21.setBackground(new java.awt.Color(0, 0, 204));
        jButton21.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-trash-27.png"))); // NOI18N
        jButton21.setText("Supprimer");
        jButton21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton21MouseEntered(evt);
            }
        });
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 137, 32));

        Es.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        Es.setText("Espagnol");

        Fr.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        Fr.setText("Français");

        An.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        An.setText("Anglais");

        Ta.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        Ta.setText("Tamazirt");

        jCheckBox1.setText("Access");

        jCheckBox2.setText("Word");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jCheckBox3.setText("Excel");

        jCheckBox4.setText("Power point");

        jComboBox1.setFont(new java.awt.Font("Traditional Arabic", 1, 11)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1/5", "2/5", "3/5", "4/5", "5/5" }));

        jComboBox2.setFont(new java.awt.Font("Traditional Arabic", 1, 11)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1/5", "2/5", "3/5", "4/5", "5/5" }));

        jComboBox3.setFont(new java.awt.Font("Traditional Arabic", 1, 11)); // NOI18N
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1/5", "2/5", "3/5", "4/5", "5/5" }));

        jComboBox4.setFont(new java.awt.Font("Traditional Arabic", 1, 11)); // NOI18N
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1/5", "2/5", "3/5", "4/5", "5/5" }));

        jComboBox5.setFont(new java.awt.Font("Traditional Arabic", 1, 11)); // NOI18N
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1/5", "2/5", "3/5", "4/5", "5/5" }));

        jButton16.setBackground(new java.awt.Color(51, 102, 255));
        jButton16.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jButton16.setText("Afficher");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton38.setBackground(new java.awt.Color(51, 102, 255));
        jButton38.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jButton38.setText("Actualiser");
        jButton38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton38ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout inscription4panelLayout = new javax.swing.GroupLayout(inscription4panel);
        inscription4panel.setLayout(inscription4panelLayout);
        inscription4panelLayout.setHorizontalGroup(
            inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inscription4panelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(langue, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel161, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(insc, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel72))
                    .addComponent(jLabel87)
                    .addComponent(jLabel70))
                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription4panelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(num_insc, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton38))
                    .addGroup(inscription4panelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Ar, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(31, 31, 31)
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(An, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Es, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Ta, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(30, 30, 30)
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Fr, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(inscription4panelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane18, javax.swing.GroupLayout.DEFAULT_SIZE, 186, Short.MAX_VALUE)
                            .addComponent(jScrollPane19))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription4panelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription4panelLayout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 892, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(inscription4panelLayout.createSequentialGroup()
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscription4panelLayout.createSequentialGroup()
                                .addGap(290, 290, 290)
                                .addComponent(jLabel89, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription4panelLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel71, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(logiciel, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(inscription4panelLayout.createSequentialGroup()
                                .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jCheckBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(inscription4panelLayout.createSequentialGroup()
                                .addComponent(jCheckBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jCheckBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane20))
                        .addGap(52, 52, 52))))
        );
        inscription4panelLayout.setVerticalGroup(
            inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inscription4panelLayout.createSequentialGroup()
                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription4panelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel89)
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscription4panelLayout.createSequentialGroup()
                                .addGap(53, 53, 53)
                                .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription4panelLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(logiciel)
                                .addGap(34, 34, 34))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription4panelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription4panelLayout.createSequentialGroup()
                                .addComponent(jLabel70)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel87)
                                .addGap(23, 23, 23))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription4panelLayout.createSequentialGroup()
                                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jCheckBox1)
                                    .addComponent(jCheckBox3))
                                .addGap(18, 18, 18)
                                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jCheckBox2)
                                    .addComponent(jCheckBox4))
                                .addGap(18, 18, 18)))))
                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inscription4panelLayout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addComponent(jLabel72)
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(langue)
                            .addGroup(inscription4panelLayout.createSequentialGroup()
                                .addGap(61, 61, 61)
                                .addComponent(jLabel161))))
                    .addGroup(inscription4panelLayout.createSequentialGroup()
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscription4panelLayout.createSequentialGroup()
                                .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inscription4panelLayout.createSequentialGroup()
                                .addComponent(jLabel71, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(68, 68, 68))
                            .addGroup(inscription4panelLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)))
                        .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Ar)
                                .addComponent(An)
                                .addComponent(Es)
                                .addComponent(Ta)
                                .addComponent(Fr))
                            .addGroup(inscription4panelLayout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addGroup(inscription4panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(num_insc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(insc)
                    .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton38, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        mainPanel.add(inscription4panel, "card13");

        coordinateurpanel.setBackground(new java.awt.Color(255, 255, 255));

        modulepanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel43.setFont(new java.awt.Font("Bernard MT Condensed", 0, 18)); // NOI18N
        jLabel43.setText("Cors Ensignant");

        jLabel44.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel44.setText("CIN");

        jLabel45.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel45.setText("Nom");

        table_coor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        table_coor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table_coorMouseClicked(evt);
            }
        });
        jScrollPane13.setViewportView(table_coor);

        jButton12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-plus-math-filled-27 (1).png"))); // NOI18N
        jButton12.setText("Ajouter");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        Supprimer2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Supprimer2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-trash-27.png"))); // NOI18N
        Supprimer2.setText("Supprimer");
        Supprimer2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Supprimer2ActionPerformed(evt);
            }
        });

        jLabel99.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel99.setText("Prénom");

        jLabel100.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel100.setText("Grade");

        jLabel102.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel102.setText("Télephone 2");

        tel1_coor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tel1_coorActionPerformed(evt);
            }
        });
        tel1_coor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tel1_coorKeyPressed(evt);
            }
        });

        jLabel121.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel121.setText("Télephone 1");

        jLabel122.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel122.setText("Numéro du compte");

        jLabel123.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel123.setText("Type");

        type_coor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Vacataire", "Permanente" }));
        type_coor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                type_coorMouseEntered(evt);
            }
        });

        jLabel125.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel125.setText("Fonction");

        f.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        f.setText("Filière");

        m.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        m.setText("Modules");

        fonction_coor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Responsable du module", "Intervenant", "Coordinateur Option", "Responsable Filière" }));
        fonction_coor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                fonction_coorMouseEntered(evt);
            }
        });
        fonction_coor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fonction_coorActionPerformed(evt);
            }
        });

        module_coor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un module" }));
        module_coor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                module_coorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                module_coorMouseExited(evt);
            }
        });
        module_coor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                module_coorActionPerformed(evt);
            }
        });

        filiere_coor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere_coor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiere_coorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiere_coorMouseExited(evt);
            }
        });
        filiere_coor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filiere_coorActionPerformed(evt);
            }
        });

        o.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        o.setText("Option");

        option_coor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option_coor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                option_coorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                option_coorMouseExited(evt);
            }
        });

        jLabel129.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel129.setText("Email");

        tel2_coor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tel2_coorKeyPressed(evt);
            }
        });

        jButton42.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-edit-file-27.png"))); // NOI18N
        jButton42.setText("Modifier");
        jButton42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton42ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout modulepanel4Layout = new javax.swing.GroupLayout(modulepanel4);
        modulepanel4.setLayout(modulepanel4Layout);
        modulepanel4Layout.setHorizontalGroup(
            modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modulepanel4Layout.createSequentialGroup()
                .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, modulepanel4Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel100, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel99, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel121, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel102, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel129, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(tel1_coor, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE)
                            .addComponent(nom_coor, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cin_coor, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(prenom_coor)
                            .addComponent(grade_coor)
                            .addComponent(tel2_coor, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(email_coor))
                        .addGap(101, 101, 101)
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel122, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                            .addComponent(jLabel123, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel125, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(f, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(o, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(m, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(modulepanel4Layout.createSequentialGroup()
                                .addComponent(module_coor, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(option_coor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(filiere_coor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fonction_coor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(type_coor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(num_compte)))
                    .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(modulepanel4Layout.createSequentialGroup()
                            .addGap(311, 311, 311)
                            .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(modulepanel4Layout.createSequentialGroup()
                            .addGap(152, 152, 152)
                            .addComponent(jButton12)
                            .addGap(55, 55, 55)
                            .addComponent(jButton42)
                            .addGap(53, 53, 53)
                            .addComponent(Supprimer2))
                        .addGroup(modulepanel4Layout.createSequentialGroup()
                            .addGap(37, 37, 37)
                            .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 740, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(90, 90, 90))
        );
        modulepanel4Layout.setVerticalGroup(
            modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modulepanel4Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 95, Short.MAX_VALUE)
                .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(modulepanel4Layout.createSequentialGroup()
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel44)
                            .addGroup(modulepanel4Layout.createSequentialGroup()
                                .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(cin_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel122))
                                .addGap(18, 18, 18)
                                .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(nom_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel45)
                                    .addComponent(jLabel123))
                                .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(modulepanel4Layout.createSequentialGroup()
                                        .addGap(28, 28, 28)
                                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel99)
                                            .addComponent(prenom_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(modulepanel4Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel125)))
                                .addGap(18, 18, 18)
                                .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(modulepanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel100)
                                        .addGap(28, 28, 28))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modulepanel4Layout.createSequentialGroup()
                                        .addComponent(grade_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)))
                                .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(tel1_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel121))
                                .addGap(18, 18, 18)
                                .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel102)
                                    .addComponent(tel2_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel129)
                            .addComponent(email_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton12)
                            .addComponent(Supprimer2)
                            .addComponent(jButton42))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(modulepanel4Layout.createSequentialGroup()
                        .addComponent(num_compte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(type_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(fonction_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(filiere_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(f))
                        .addGap(13, 13, 13)
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(option_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(o))
                        .addGap(18, 18, 18)
                        .addGroup(modulepanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(module_coor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(m))))
                .addContainerGap())
        );

        javax.swing.GroupLayout coordinateurpanelLayout = new javax.swing.GroupLayout(coordinateurpanel);
        coordinateurpanel.setLayout(coordinateurpanelLayout);
        coordinateurpanelLayout.setHorizontalGroup(
            coordinateurpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 890, Short.MAX_VALUE)
            .addGroup(coordinateurpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(modulepanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        coordinateurpanelLayout.setVerticalGroup(
            coordinateurpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
            .addGroup(coordinateurpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(coordinateurpanelLayout.createSequentialGroup()
                    .addComponent(modulepanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        mainPanel.add(coordinateurpanel, "card14");

        moduleretard.setBackground(new java.awt.Color(255, 255, 255));

        module_retard1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel16.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel16.setText("Choisir un module");

        jLabel147.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel147.setText("Filière");

        jLabel158.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel158.setText("Option");

        jLabel186.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel186.setText("Niveau");

        jLabel187.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel187.setText("Module");

        fi1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        fi1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                fi1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                fi1MouseExited(evt);
            }
        });

        ni1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un niveau" }));
        ni1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ni1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ni1MouseExited(evt);
            }
        });

        op1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        op1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                op1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                op1MouseExited(evt);
            }
        });

        mo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un module" }));
        mo1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                mo1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                mo1MouseExited(evt);
            }
        });

        jButton30.setBackground(new java.awt.Color(0, 0, 204));
        jButton30.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton30.setForeground(new java.awt.Color(255, 255, 255));
        jButton30.setText("Voir");
        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });

        jButton33.setBackground(new java.awt.Color(0, 0, 204));
        jButton33.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton33.setForeground(new java.awt.Color(255, 255, 255));
        jButton33.setText("Retour");
        jButton33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton33ActionPerformed(evt);
            }
        });

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ret.jpg"))); // NOI18N

        javax.swing.GroupLayout module_retard1Layout = new javax.swing.GroupLayout(module_retard1);
        module_retard1.setLayout(module_retard1Layout);
        module_retard1Layout.setHorizontalGroup(
            module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(module_retard1Layout.createSequentialGroup()
                .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(module_retard1Layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel16)
                            .addGroup(module_retard1Layout.createSequentialGroup()
                                .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel147, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel158, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel186, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel187, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(36, 36, 36)
                                .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(ni1, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(op1, javax.swing.GroupLayout.Alignment.LEADING, 0, 242, Short.MAX_VALUE)
                                        .addComponent(fi1, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(mo1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(module_retard1Layout.createSequentialGroup()
                        .addGap(242, 242, 242)
                        .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton30, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 94, Short.MAX_VALUE)
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(129, 129, 129))
        );
        module_retard1Layout.setVerticalGroup(
            module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(module_retard1Layout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addComponent(jLabel16)
                .addGap(96, 96, 96)
                .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(module_retard1Layout.createSequentialGroup()
                        .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel147)
                            .addComponent(fi1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel158)
                            .addComponent(op1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ni1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel186))
                        .addGap(18, 18, 18)
                        .addGroup(module_retard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(mo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel187))
                        .addGap(51, 51, 51)
                        .addComponent(jButton30)
                        .addGap(18, 18, 18)
                        .addComponent(jButton33))
                    .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(184, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout moduleretardLayout = new javax.swing.GroupLayout(moduleretard);
        moduleretard.setLayout(moduleretardLayout);
        moduleretardLayout.setHorizontalGroup(
            moduleretardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 890, Short.MAX_VALUE)
            .addGroup(moduleretardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(moduleretardLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(module_retard1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        moduleretardLayout.setVerticalGroup(
            moduleretardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 703, Short.MAX_VALUE)
            .addGroup(moduleretardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(moduleretardLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(module_retard1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainPanel.add(moduleretard, "card15");

        choix_module.setBackground(new java.awt.Color(255, 255, 255));

        jLabel14.setFont(new java.awt.Font("Traditional Arabic", 0, 24)); // NOI18N
        jLabel14.setText("Notes du Rattrapage");

        jButton39.setBackground(new java.awt.Color(0, 0, 204));
        jButton39.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton39.setForeground(new java.awt.Color(255, 255, 255));
        jButton39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-undo-27.png"))); // NOI18N
        jButton39.setText("Retour");
        jButton39.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton39ActionPerformed(evt);
            }
        });

        Table_Abc1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Table_Abc1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Table_Abc1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Table_Abc1);

        javax.swing.GroupLayout choix_moduleLayout = new javax.swing.GroupLayout(choix_module);
        choix_module.setLayout(choix_moduleLayout);
        choix_moduleLayout.setHorizontalGroup(
            choix_moduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, choix_moduleLayout.createSequentialGroup()
                .addGap(0, 232, Short.MAX_VALUE)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 453, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(205, 205, 205))
            .addGroup(choix_moduleLayout.createSequentialGroup()
                .addGroup(choix_moduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(choix_moduleLayout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 659, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(choix_moduleLayout.createSequentialGroup()
                        .addGap(376, 376, 376)
                        .addComponent(jButton39, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        choix_moduleLayout.setVerticalGroup(
            choix_moduleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(choix_moduleLayout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE)
                .addGap(28, 28, 28)
                .addComponent(jButton39, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62))
        );

        mainPanel.add(choix_module, "card17");

        Liste_Abc2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel108.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel108.setText("Liste des absences");

        Table_Abcense1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Table_Abcense1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Table_Abcense1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Table_Abcense1MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(Table_Abcense1);

        jButton65.setBackground(new java.awt.Color(0, 0, 204));
        jButton65.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton65.setForeground(new java.awt.Color(255, 255, 255));
        jButton65.setText("Retour");
        jButton65.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton65.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton65jButton61ActionPerformed(evt);
            }
        });

        jButton66.setBackground(new java.awt.Color(0, 0, 204));
        jButton66.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton66.setForeground(new java.awt.Color(255, 255, 255));
        jButton66.setText("Imprimer");
        jButton66.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton66.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton66jButton62ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Liste_Abc2Layout = new javax.swing.GroupLayout(Liste_Abc2);
        Liste_Abc2.setLayout(Liste_Abc2Layout);
        Liste_Abc2Layout.setHorizontalGroup(
            Liste_Abc2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Liste_Abc2Layout.createSequentialGroup()
                .addContainerGap(724, Short.MAX_VALUE)
                .addGroup(Liste_Abc2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton66, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton65, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49))
            .addGroup(Liste_Abc2Layout.createSequentialGroup()
                .addGroup(Liste_Abc2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Liste_Abc2Layout.createSequentialGroup()
                        .addGap(257, 257, 257)
                        .addComponent(jLabel108, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Liste_Abc2Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 826, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Liste_Abc2Layout.setVerticalGroup(
            Liste_Abc2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Liste_Abc2Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel108, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jButton66, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton65, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout Liste_Abc1Layout = new javax.swing.GroupLayout(Liste_Abc1);
        Liste_Abc1.setLayout(Liste_Abc1Layout);
        Liste_Abc1Layout.setHorizontalGroup(
            Liste_Abc1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 890, Short.MAX_VALUE)
            .addGroup(Liste_Abc1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Liste_Abc1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Liste_Abc2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        Liste_Abc1Layout.setVerticalGroup(
            Liste_Abc1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 610, Short.MAX_VALUE)
            .addGroup(Liste_Abc1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Liste_Abc1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Liste_Abc2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainPanel.add(Liste_Abc1, "card18");

        Liste_Retard.setBackground(new java.awt.Color(255, 255, 255));

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        jLabel119.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel119.setText("Liste des Retards");

        Table_Retard1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(Table_Retard1);

        jButton4.setBackground(new java.awt.Color(0, 0, 204));
        jButton4.setFont(new java.awt.Font("Traditional Arabic", 1, 11)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Imprimer");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton6.setBackground(new java.awt.Color(0, 0, 204));
        jButton6.setFont(new java.awt.Font("Traditional Arabic", 1, 11)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Retour");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel119, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 717, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(67, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jLabel119)
                .addGap(71, 71, 71)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 326, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jButton4)
                .addGap(18, 18, 18)
                .addComponent(jButton6)
                .addGap(38, 38, 38))
        );

        javax.swing.GroupLayout Liste_RetardLayout = new javax.swing.GroupLayout(Liste_Retard);
        Liste_Retard.setLayout(Liste_RetardLayout);
        Liste_RetardLayout.setHorizontalGroup(
            Liste_RetardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 890, Short.MAX_VALUE)
            .addGroup(Liste_RetardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Liste_RetardLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        Liste_RetardLayout.setVerticalGroup(
            Liste_RetardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 618, Short.MAX_VALUE)
            .addGroup(Liste_RetardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Liste_RetardLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainPanel.add(Liste_Retard, "card19");

        etudiant.setBackground(new java.awt.Color(255, 255, 255));

        jLabel17.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel17.setText("Information sur les étudiants");

        jLabel136.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel136.setText("Filière");

        filiere_info.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere_info.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiere_infoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiere_infoMouseExited(evt);
            }
        });

        jLabel137.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel137.setText("Option");

        option_info.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option_info.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                option_infoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                option_infoMouseExited(evt);
            }
        });

        jLabel138.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel138.setText("Niveau");

        niveau_info.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un niveau" }));
        niveau_info.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                niveau_infoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                niveau_infoMouseExited(evt);
            }
        });

        jButton5.setBackground(new java.awt.Color(0, 0, 204));
        jButton5.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Afficher");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton5MouseEntered(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel140.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel140.setText("Année");

        javax.swing.GroupLayout etudiantLayout = new javax.swing.GroupLayout(etudiant);
        etudiant.setLayout(etudiantLayout);
        etudiantLayout.setHorizontalGroup(
            etudiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(etudiantLayout.createSequentialGroup()
                .addGap(177, 177, 177)
                .addGroup(etudiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(etudiantLayout.createSequentialGroup()
                        .addGroup(etudiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel137, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel138, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel136, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel140, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(59, 59, 59)
                        .addGroup(etudiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(niveau_info, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(option_info, 0, 276, Short.MAX_VALUE)
                            .addComponent(filiere_info, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jYearChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(etudiantLayout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(301, Short.MAX_VALUE))
        );
        etudiantLayout.setVerticalGroup(
            etudiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(etudiantLayout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(131, 131, 131)
                .addGroup(etudiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel136)
                    .addComponent(filiere_info, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(etudiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel137)
                    .addComponent(option_info, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(etudiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel138)
                    .addComponent(niveau_info, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(etudiantLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel140)
                    .addComponent(jYearChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(59, 59, 59)
                .addComponent(jButton5)
                .addContainerGap(144, Short.MAX_VALUE))
        );

        mainPanel.add(etudiant, "card20");

        Afficher_Etud.setBackground(new java.awt.Color(255, 255, 255));

        table_per1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9"
            }
        ));
        table_per1.setGridColor(new java.awt.Color(0, 204, 0));
        table_per1.setSelectionBackground(new java.awt.Color(204, 204, 255));
        table_per1.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jScrollPane15.setViewportView(table_per1);

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        btnniveau1.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau1.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau1.setText("Information personnel(suite)");
        btnniveau1.setBorder(null);
        btnniveau1.setContentAreaFilled(false);
        btnniveau1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau1.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau1.setIconTextGap(10);
        btnniveau1.setOpaque(true);
        btnniveau1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau1MouseExited(evt);
            }
        });
        btnniveau1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau1ActionPerformed(evt);
            }
        });

        btnniveau2.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau2.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau2.setText("    Informations personnel");
        btnniveau2.setBorder(null);
        btnniveau2.setContentAreaFilled(false);
        btnniveau2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau2.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau2.setIconTextGap(10);
        btnniveau2.setOpaque(true);
        btnniveau2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau2MouseExited(evt);
            }
        });
        btnniveau2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau2ActionPerformed(evt);
            }
        });

        btnniveau3.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau3.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau3.setText("Compéthences");
        btnniveau3.setBorder(null);
        btnniveau3.setContentAreaFilled(false);
        btnniveau3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau3.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau3.setIconTextGap(10);
        btnniveau3.setOpaque(true);
        btnniveau3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau3MouseExited(evt);
            }
        });
        btnniveau3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau3ActionPerformed(evt);
            }
        });

        btnniveau4.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau4.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau4.setText("Informations scolaire(suite)");
        btnniveau4.setBorder(null);
        btnniveau4.setContentAreaFilled(false);
        btnniveau4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau4.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau4.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau4.setIconTextGap(10);
        btnniveau4.setOpaque(true);
        btnniveau4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau4MouseExited(evt);
            }
        });
        btnniveau4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau4ActionPerformed(evt);
            }
        });

        btnniveau18.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau18.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau18.setText("Informations scolaire");
        btnniveau18.setBorder(null);
        btnniveau18.setContentAreaFilled(false);
        btnniveau18.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau18.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau18.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau18.setIconTextGap(10);
        btnniveau18.setOpaque(true);
        btnniveau18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau18MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau18MouseExited(evt);
            }
        });
        btnniveau18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau18ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(177, 177, 177)
                .addComponent(btnniveau1, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnniveau4, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau3, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addComponent(btnniveau2, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 725, Short.MAX_VALUE)))
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addGap(352, 352, 352)
                    .addComponent(btnniveau18, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(394, Short.MAX_VALUE)))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnniveau3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addComponent(btnniveau1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnniveau4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(btnniveau2, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addComponent(btnniveau18, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pa1.setBackground(new java.awt.Color(255, 255, 255));
        pa1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Informations personnel", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Traditional Arabic", 1, 14))); // NOI18N

        jLabel101.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel101.setText("CNE");

        cne_a.setBorder(null);

        jLabel126.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel126.setText("CIN");

        cin_a.setText(" ");
        cin_a.setBorder(null);
        cin_a.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cin_aActionPerformed(evt);
            }
        });

        jLabel127.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel127.setText("Nom");

        nom_a.setText(" ");
        nom_a.setBorder(null);

        jLabel128.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel128.setText("Prénom");

        prenom_a.setText(" ");
        prenom_a.setBorder(null);
        prenom_a.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prenom_aActionPerformed(evt);
            }
        });

        jLabel130.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel130.setText("Sexe");

        jLabel131.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel131.setText("Date de naissance");

        lieux_a.setBorder(null);

        jLabel132.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel132.setText("Lieux de naissance");

        naissance_a.setText(" ");
        naissance_a.setBorder(null);

        jLabel133.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel133.setText("Adresse 1");

        adr1_a.setText(" ");
        adr1_a.setBorder(null);

        jLabel134.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel134.setText("Adresse2");

        adr2_a.setText(" ");
        adr2_a.setBorder(null);

        sexe_a.setBorder(null);

        jPanel10.setLayout(null);

        photo_a.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        photo_a.setText("    Photo");
        jPanel10.add(photo_a);
        photo_a.setBounds(0, 0, 90, 80);

        javax.swing.GroupLayout pa1Layout = new javax.swing.GroupLayout(pa1);
        pa1.setLayout(pa1Layout);
        pa1Layout.setHorizontalGroup(
            pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pa1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel126)
                    .addComponent(jLabel127)
                    .addComponent(jLabel101, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel128, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel130, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel132)
                    .addComponent(jLabel133)
                    .addComponent(jLabel134, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel131, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(sexe_a)
                        .addComponent(adr2_a, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                        .addComponent(adr1_a)
                        .addComponent(lieux_a)
                        .addComponent(naissance_a))
                    .addGroup(pa1Layout.createSequentialGroup()
                        .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cin_a, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cne_a, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nom_a, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(prenom_a, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        pa1Layout.setVerticalGroup(
            pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pa1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pa1Layout.createSequentialGroup()
                        .addComponent(jLabel101)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel126)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel127)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel128)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pa1Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pa1Layout.createSequentialGroup()
                                .addComponent(cne_a, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(prenom_a, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cin_a, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nom_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel131)
                            .addComponent(naissance_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel132)
                            .addComponent(lieux_a, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pa1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel133))
                            .addGroup(pa1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(adr1_a, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(adr2_a)
                            .addComponent(jLabel134))
                        .addGap(8, 8, 8)
                        .addGroup(pa1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel130)
                            .addComponent(sexe_a, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(66, 66, 66))))
        );

        jButton45.setBackground(new java.awt.Color(0, 0, 204));
        jButton45.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton45.setForeground(new java.awt.Color(255, 255, 255));
        jButton45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-send-to-printer-27.png"))); // NOI18N
        jButton45.setText("Imprimer");
        jButton45.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton45.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton45ActionPerformed(evt);
            }
        });

        jButton7.setBackground(new java.awt.Color(0, 0, 204));
        jButton7.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Rechercher par :");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        comborech.setBackground(new java.awt.Color(204, 204, 255));
        comborech.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        comborech.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Numéro d'inscription", "Nom" }));

        jButton43.setBackground(new java.awt.Color(0, 0, 204));
        jButton43.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton43.setForeground(new java.awt.Color(255, 255, 255));
        jButton43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-undo-27.png"))); // NOI18N
        jButton43.setText("Retour");
        jButton43.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton43ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Afficher_EtudLayout = new javax.swing.GroupLayout(Afficher_Etud);
        Afficher_Etud.setLayout(Afficher_EtudLayout);
        Afficher_EtudLayout.setHorizontalGroup(
            Afficher_EtudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(Afficher_EtudLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 879, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(Afficher_EtudLayout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addGroup(Afficher_EtudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pa1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Afficher_EtudLayout.createSequentialGroup()
                        .addComponent(jButton7)
                        .addGap(31, 31, 31)
                        .addComponent(comborech, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(textrech)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Afficher_EtudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(97, 97, 97))
        );
        Afficher_EtudLayout.setVerticalGroup(
            Afficher_EtudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Afficher_EtudLayout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(Afficher_EtudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Afficher_EtudLayout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addComponent(jButton45, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton43, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Afficher_EtudLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(pa1, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Afficher_EtudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(Afficher_EtudLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(comborech, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(textrech, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton7))
                .addGap(29, 29, 29)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        mainPanel.add(Afficher_Etud, "card21");

        Afficher_Etud4.setBackground(new java.awt.Color(255, 255, 255));

        table_per2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9"
            }
        ));
        table_per2.setGridColor(new java.awt.Color(0, 153, 0));
        table_per2.setSelectionBackground(new java.awt.Color(204, 51, 0));
        jScrollPane23.setViewportView(table_per2);

        jPanel15.setBackground(new java.awt.Color(204, 204, 204));

        btnniveau5.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau5.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau5.setText("Information personnel(suite)");
        btnniveau5.setBorder(null);
        btnniveau5.setContentAreaFilled(false);
        btnniveau5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau5.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau5.setIconTextGap(10);
        btnniveau5.setOpaque(true);
        btnniveau5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau5MouseExited(evt);
            }
        });
        btnniveau5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau5ActionPerformed(evt);
            }
        });

        btnniveau6.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau6.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau6.setText("    Informations personnel");
        btnniveau6.setBorder(null);
        btnniveau6.setContentAreaFilled(false);
        btnniveau6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau6.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau6.setIconTextGap(10);
        btnniveau6.setOpaque(true);
        btnniveau6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau6MouseExited(evt);
            }
        });
        btnniveau6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau6ActionPerformed(evt);
            }
        });

        btnniveau19.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau19.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau19.setText("Informations scolaire(suite)");
        btnniveau19.setBorder(null);
        btnniveau19.setContentAreaFilled(false);
        btnniveau19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau19.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau19.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau19.setIconTextGap(10);
        btnniveau19.setOpaque(true);
        btnniveau19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau19MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau19MouseExited(evt);
            }
        });
        btnniveau19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau19ActionPerformed(evt);
            }
        });

        btnniveau7.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau7.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau7.setText("Compéthences");
        btnniveau7.setBorder(null);
        btnniveau7.setContentAreaFilled(false);
        btnniveau7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau7.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau7.setIconTextGap(10);
        btnniveau7.setOpaque(true);
        btnniveau7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau7MouseExited(evt);
            }
        });
        btnniveau7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau7ActionPerformed(evt);
            }
        });

        btnniveau20.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau20.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau20.setText("Informations scolaire");
        btnniveau20.setBorder(null);
        btnniveau20.setContentAreaFilled(false);
        btnniveau20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau20.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau20.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau20.setIconTextGap(10);
        btnniveau20.setOpaque(true);
        btnniveau20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau20MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau20MouseExited(evt);
            }
        });
        btnniveau20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau20ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(176, 176, 176)
                .addComponent(btnniveau5, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnniveau20, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau19, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau7, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(158, Short.MAX_VALUE))
            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel15Layout.createSequentialGroup()
                    .addComponent(btnniveau6, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 912, Short.MAX_VALUE)))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnniveau5, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
            .addComponent(btnniveau20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnniveau19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnniveau7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(btnniveau6, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE))
        );

        pa2.setBackground(new java.awt.Color(255, 255, 255));
        pa2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Informations personnel", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Traditional Arabic", 1, 14))); // NOI18N

        jLabel165.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel165.setText("Télephone 1");

        tel1_a.setBorder(null);

        jLabel166.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel166.setText("Télephone 2");

        tel2_a.setText(" ");
        tel2_a.setBorder(null);

        jLabel167.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel167.setText("Nationalité");

        nationalite_a.setText(" ");
        nationalite_a.setBorder(null);

        jLabel168.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel168.setText("Adresse actuel");

        actuel_a.setText(" ");
        actuel_a.setBorder(null);
        actuel_a.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                actuel_aActionPerformed(evt);
            }
        });

        jLabel169.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel169.setText("Situation de famille");

        jLabel170.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel170.setText("Numéro whatsApp");

        jLabel171.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel171.setText("Email 1");

        jLabel172.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel172.setText("Email 2");

        jLabel173.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel173.setText("Nombre d'enfants");

        situation_a.setBorder(null);

        whatsup_a.setBorder(null);

        email1_a.setBorder(null);

        email2_a.setBorder(null);
        email2_a.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                email2_aActionPerformed(evt);
            }
        });

        nbr_enfant_a.setBorder(null);

        javax.swing.GroupLayout pa2Layout = new javax.swing.GroupLayout(pa2);
        pa2.setLayout(pa2Layout);
        pa2Layout.setHorizontalGroup(
            pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pa2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pa2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(nationalite_a, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(843, 843, 843))
                    .addGroup(pa2Layout.createSequentialGroup()
                        .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel170, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel171))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pa2Layout.createSequentialGroup()
                        .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel169, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(pa2Layout.createSequentialGroup()
                                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel167)
                                    .addComponent(jLabel165, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel166, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel168, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel172)
                                    .addComponent(jLabel173, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pa2Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tel1_a, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tel2_a, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pa2Layout.createSequentialGroup()
                                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pa2Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(nbr_enfant_a))
                                    .addComponent(situation_a, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(actuel_a, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                                    .addComponent(whatsup_a, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(email1_a, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(email2_a, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(843, 843, 843))))))
        );
        pa2Layout.setVerticalGroup(
            pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pa2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel165)
                    .addComponent(tel1_a))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel166)
                    .addComponent(tel2_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel167)
                    .addComponent(nationalite_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel168)
                    .addComponent(actuel_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel169)
                    .addComponent(situation_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel170)
                    .addComponent(whatsup_a, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel171)
                    .addComponent(email1_a, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(email2_a, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel172))
                .addGap(6, 6, 6)
                .addGroup(pa2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nbr_enfant_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel173))
                .addGap(98, 98, 98))
        );

        cnee.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cneeMouseEntered(evt);
            }
        });

        jPanel21.setBackground(new java.awt.Color(204, 204, 204));

        btnniveau27.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau27.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau27.setText("Information personnel(suite)");
        btnniveau27.setBorder(null);
        btnniveau27.setContentAreaFilled(false);
        btnniveau27.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau27.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau27.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau27.setIconTextGap(10);
        btnniveau27.setOpaque(true);
        btnniveau27.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau27MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau27MouseExited(evt);
            }
        });
        btnniveau27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau27ActionPerformed(evt);
            }
        });

        btnniveau28.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau28.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau28.setText("    Informations personnel");
        btnniveau28.setBorder(null);
        btnniveau28.setContentAreaFilled(false);
        btnniveau28.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau28.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau28.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau28.setIconTextGap(10);
        btnniveau28.setOpaque(true);
        btnniveau28.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau28MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau28MouseExited(evt);
            }
        });
        btnniveau28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau28ActionPerformed(evt);
            }
        });

        btnniveau29.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau29.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau29.setText("Informations scolaire(suite)");
        btnniveau29.setBorder(null);
        btnniveau29.setContentAreaFilled(false);
        btnniveau29.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau29.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau29.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau29.setIconTextGap(10);
        btnniveau29.setOpaque(true);
        btnniveau29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau29MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau29MouseExited(evt);
            }
        });
        btnniveau29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau29ActionPerformed(evt);
            }
        });

        btnniveau30.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau30.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau30.setText("Informations scolaire");
        btnniveau30.setBorder(null);
        btnniveau30.setContentAreaFilled(false);
        btnniveau30.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau30.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau30.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau30.setIconTextGap(10);
        btnniveau30.setOpaque(true);
        btnniveau30.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau30MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau30MouseExited(evt);
            }
        });
        btnniveau30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau30ActionPerformed(evt);
            }
        });

        btnniveau31.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau31.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau31.setText("Compéthences");
        btnniveau31.setBorder(null);
        btnniveau31.setContentAreaFilled(false);
        btnniveau31.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau31.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau31.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau31.setIconTextGap(10);
        btnniveau31.setOpaque(true);
        btnniveau31.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau31MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau31MouseExited(evt);
            }
        });
        btnniveau31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau31ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(btnniveau27, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau30, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau29, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau31, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(164, Short.MAX_VALUE))
            .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel21Layout.createSequentialGroup()
                    .addComponent(btnniveau28, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 903, Short.MAX_VALUE)))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
                .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnniveau27, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                    .addComponent(btnniveau30, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnniveau29, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnniveau31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel21Layout.createSequentialGroup()
                    .addComponent(btnniveau28, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout Afficher_Etud4Layout = new javax.swing.GroupLayout(Afficher_Etud4);
        Afficher_Etud4.setLayout(Afficher_Etud4Layout);
        Afficher_Etud4Layout.setHorizontalGroup(
            Afficher_Etud4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(Afficher_Etud4Layout.createSequentialGroup()
                .addGroup(Afficher_Etud4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Afficher_Etud4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 865, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Afficher_Etud4Layout.createSequentialGroup()
                        .addGap(195, 195, 195)
                        .addComponent(pa2, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cnee, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(Afficher_Etud4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Afficher_Etud4Layout.setVerticalGroup(
            Afficher_Etud4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Afficher_Etud4Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jScrollPane23, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                .addGroup(Afficher_Etud4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Afficher_Etud4Layout.createSequentialGroup()
                        .addGap(234, 234, 234)
                        .addComponent(cnee, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Afficher_Etud4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(pa2, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(74, 74, 74)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(Afficher_Etud4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Afficher_Etud4Layout.createSequentialGroup()
                    .addGap(564, 564, 564)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(43, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout info_per2Layout = new javax.swing.GroupLayout(info_per2);
        info_per2.setLayout(info_per2Layout);
        info_per2Layout.setHorizontalGroup(
            info_per2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1082, Short.MAX_VALUE)
            .addGroup(info_per2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(info_per2Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Afficher_Etud4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        info_per2Layout.setVerticalGroup(
            info_per2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 659, Short.MAX_VALUE)
            .addGroup(info_per2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(info_per2Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Afficher_Etud4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainPanel.add(info_per2, "card22");

        Afficher_Etud5.setBackground(new java.awt.Color(255, 255, 255));

        table_scolaire.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8", "Title 9"
            }
        ));
        table_scolaire.setGridColor(new java.awt.Color(0, 153, 0));
        table_scolaire.setSelectionBackground(new java.awt.Color(204, 51, 0));
        jScrollPane24.setViewportView(table_scolaire);

        pa3.setBackground(new java.awt.Color(255, 255, 255));
        pa3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Informations scolaire", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Traditional Arabic", 1, 14))); // NOI18N

        jLabel174.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel174.setText("Numéro d'inscription");

        num_a.setBorder(null);

        jLabel175.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel175.setText("Date d'inscription");

        jLabel176.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel176.setText("Boursière");

        jLabel177.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel177.setText("Mention du bac");

        jLabel178.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel178.setText("Année d'obtention du bac");

        jLabel179.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel179.setText("Moyenne du bac");

        jLabel180.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel180.setText("Lycée");

        jLabel181.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel181.setText("Filière");

        jLabel182.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel182.setText("Option");

        jLabel192.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel192.setText("Niveau");

        insc_a.setBorder(null);

        bou_a.setBorder(null);

        mention_a.setBorder(null);

        obtention_a.setBorder(null);

        moyenne_a.setBorder(null);

        lycee_a.setBorder(null);
        lycee_a.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lycee_aActionPerformed(evt);
            }
        });

        filiere_a.setBorder(null);

        option_a.setBorder(null);

        niveau_a.setBorder(null);

        javax.swing.GroupLayout pa3Layout = new javax.swing.GroupLayout(pa3);
        pa3.setLayout(pa3Layout);
        pa3Layout.setHorizontalGroup(
            pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pa3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pa3Layout.createSequentialGroup()
                        .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pa3Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel174, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel175, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel176, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel177, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(31, 31, 31))
                            .addGroup(pa3Layout.createSequentialGroup()
                                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel180)
                                    .addComponent(jLabel178, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel179, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(num_a)
                            .addComponent(insc_a)
                            .addComponent(bou_a)
                            .addComponent(mention_a, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                            .addComponent(obtention_a)
                            .addComponent(moyenne_a)
                            .addComponent(lycee_a)))
                    .addGroup(pa3Layout.createSequentialGroup()
                        .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel182, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel181)
                            .addComponent(jLabel192, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(filiere_a, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                            .addComponent(option_a)
                            .addComponent(niveau_a))))
                .addGap(21, 21, 21))
        );
        pa3Layout.setVerticalGroup(
            pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pa3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel174, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(num_a))
                .addGap(6, 6, 6)
                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel175)
                    .addComponent(insc_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel176)
                    .addComponent(bou_a, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel177)
                    .addComponent(mention_a, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(obtention_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel178))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel180)
                    .addComponent(moyenne_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel179)
                    .addComponent(lycee_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pa3Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel181)
                            .addComponent(filiere_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel182)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pa3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel192)
                            .addComponent(niveau_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pa3Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(option_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(40, 40, 40))
        );

        jPanel14.setBackground(new java.awt.Color(204, 204, 204));

        btnresultat7.setBackground(new java.awt.Color(204, 204, 204));
        btnresultat7.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnresultat7.setText("   Informations personnel ");
        btnresultat7.setBorder(null);
        btnresultat7.setContentAreaFilled(false);
        btnresultat7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnresultat7.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnresultat7.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnresultat7.setIconTextGap(10);
        btnresultat7.setOpaque(true);
        btnresultat7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnresultat7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnresultat7MouseExited(evt);
            }
        });
        btnresultat7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresultat7ActionPerformed(evt);
            }
        });

        btnresultat5.setBackground(new java.awt.Color(204, 204, 204));
        btnresultat5.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnresultat5.setText("   Informations scolaire");
        btnresultat5.setBorder(null);
        btnresultat5.setContentAreaFilled(false);
        btnresultat5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnresultat5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnresultat5.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnresultat5.setIconTextGap(10);
        btnresultat5.setOpaque(true);
        btnresultat5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnresultat5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnresultat5MouseExited(evt);
            }
        });
        btnresultat5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresultat5ActionPerformed(evt);
            }
        });

        btnresultat6.setBackground(new java.awt.Color(204, 204, 204));
        btnresultat6.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnresultat6.setText("   Informations scolaiure (suite)");
        btnresultat6.setBorder(null);
        btnresultat6.setContentAreaFilled(false);
        btnresultat6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnresultat6.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnresultat6.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnresultat6.setIconTextGap(10);
        btnresultat6.setOpaque(true);
        btnresultat6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnresultat6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnresultat6MouseExited(evt);
            }
        });
        btnresultat6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresultat6ActionPerformed(evt);
            }
        });

        btnresultat8.setBackground(new java.awt.Color(204, 204, 204));
        btnresultat8.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnresultat8.setText(" Comphéthences");
        btnresultat8.setBorder(null);
        btnresultat8.setContentAreaFilled(false);
        btnresultat8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnresultat8.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnresultat8.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnresultat8.setIconTextGap(10);
        btnresultat8.setOpaque(true);
        btnresultat8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnresultat8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnresultat8MouseExited(evt);
            }
        });
        btnresultat8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresultat8ActionPerformed(evt);
            }
        });

        btnresultat9.setBackground(new java.awt.Color(204, 204, 204));
        btnresultat9.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnresultat9.setText("   Informations personnel (suite)");
        btnresultat9.setBorder(null);
        btnresultat9.setContentAreaFilled(false);
        btnresultat9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnresultat9.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnresultat9.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnresultat9.setIconTextGap(10);
        btnresultat9.setOpaque(true);
        btnresultat9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnresultat9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnresultat9MouseExited(evt);
            }
        });
        btnresultat9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnresultat9ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(btnresultat7, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnresultat9, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnresultat5, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnresultat6, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnresultat8, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 83, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(btnresultat7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnresultat5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnresultat6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnresultat8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnresultat9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout Afficher_Etud5Layout = new javax.swing.GroupLayout(Afficher_Etud5);
        Afficher_Etud5.setLayout(Afficher_Etud5Layout);
        Afficher_Etud5Layout.setHorizontalGroup(
            Afficher_Etud5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Afficher_Etud5Layout.createSequentialGroup()
                .addGroup(Afficher_Etud5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Afficher_Etud5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 904, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Afficher_Etud5Layout.createSequentialGroup()
                        .addGap(238, 238, 238)
                        .addComponent(pa3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(197, Short.MAX_VALUE))
        );
        Afficher_Etud5Layout.setVerticalGroup(
            Afficher_Etud5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Afficher_Etud5Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(pa3, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout info_scolaireLayout = new javax.swing.GroupLayout(info_scolaire);
        info_scolaire.setLayout(info_scolaireLayout);
        info_scolaireLayout.setHorizontalGroup(
            info_scolaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1176, Short.MAX_VALUE)
            .addGroup(info_scolaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(info_scolaireLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Afficher_Etud5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        info_scolaireLayout.setVerticalGroup(
            info_scolaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 642, Short.MAX_VALUE)
            .addGroup(info_scolaireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(info_scolaireLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Afficher_Etud5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainPanel.add(info_scolaire, "card23");

        Afficher_Etud6.setBackground(new java.awt.Color(255, 255, 255));

        table_compethence.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        table_compethence.setGridColor(new java.awt.Color(0, 153, 0));
        table_compethence.setSelectionBackground(new java.awt.Color(204, 204, 255));
        jScrollPane25.setViewportView(table_compethence);

        jPanel19.setBackground(new java.awt.Color(204, 204, 204));

        btnniveau13.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau13.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau13.setText("Information personnel(suite)");
        btnniveau13.setBorder(null);
        btnniveau13.setContentAreaFilled(false);
        btnniveau13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau13.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau13.setIconTextGap(10);
        btnniveau13.setOpaque(true);
        btnniveau13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau13MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau13MouseExited(evt);
            }
        });
        btnniveau13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau13ActionPerformed(evt);
            }
        });

        btnniveau14.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau14.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau14.setText("    Informations personnel");
        btnniveau14.setBorder(null);
        btnniveau14.setContentAreaFilled(false);
        btnniveau14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau14.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau14.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau14.setIconTextGap(10);
        btnniveau14.setOpaque(true);
        btnniveau14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau14MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau14MouseExited(evt);
            }
        });
        btnniveau14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau14ActionPerformed(evt);
            }
        });

        btnniveau15.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau15.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau15.setText("Compéthences");
        btnniveau15.setBorder(null);
        btnniveau15.setContentAreaFilled(false);
        btnniveau15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau15.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau15.setIconTextGap(10);
        btnniveau15.setOpaque(true);
        btnniveau15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau15MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau15MouseExited(evt);
            }
        });
        btnniveau15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau15ActionPerformed(evt);
            }
        });

        btnniveau16.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau16.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau16.setText("Informations scolaire");
        btnniveau16.setBorder(null);
        btnniveau16.setContentAreaFilled(false);
        btnniveau16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau16.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau16.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau16.setIconTextGap(10);
        btnniveau16.setOpaque(true);
        btnniveau16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau16MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau16MouseExited(evt);
            }
        });
        btnniveau16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau16ActionPerformed(evt);
            }
        });

        btnniveau21.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau21.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau21.setText("Informations scolaire(suite)");
        btnniveau21.setBorder(null);
        btnniveau21.setContentAreaFilled(false);
        btnniveau21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau21.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau21.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau21.setIconTextGap(10);
        btnniveau21.setOpaque(true);
        btnniveau21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau21MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau21MouseExited(evt);
            }
        });
        btnniveau21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau21ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addComponent(btnniveau14, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau13, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau16, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau21, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnniveau15, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnniveau13, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
            .addComponent(btnniveau14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnniveau16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnniveau21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnniveau15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pa5.setBackground(new java.awt.Color(255, 255, 255));
        pa5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Compéthences", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Traditional Arabic", 1, 14))); // NOI18N

        table_compethence1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        table_compethence1.setGridColor(new java.awt.Color(0, 153, 0));
        table_compethence1.setSelectionBackground(new java.awt.Color(204, 204, 255));
        jScrollPane27.setViewportView(table_compethence1);

        javax.swing.GroupLayout pa5Layout = new javax.swing.GroupLayout(pa5);
        pa5.setLayout(pa5Layout);
        pa5Layout.setHorizontalGroup(
            pa5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pa5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jScrollPane27, javax.swing.GroupLayout.PREFERRED_SIZE, 783, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pa5Layout.setVerticalGroup(
            pa5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pa5Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jScrollPane27, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(62, Short.MAX_VALUE))
        );

        jButton53.setBackground(new java.awt.Color(0, 0, 204));
        jButton53.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton53.setForeground(new java.awt.Color(255, 255, 255));
        jButton53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-send-to-printer-27.png"))); // NOI18N
        jButton53.setText("Imprimer");
        jButton53.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton53.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton53ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Afficher_Etud6Layout = new javax.swing.GroupLayout(Afficher_Etud6);
        Afficher_Etud6.setLayout(Afficher_Etud6Layout);
        Afficher_Etud6Layout.setHorizontalGroup(
            Afficher_Etud6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(Afficher_Etud6Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(Afficher_Etud6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane25, javax.swing.GroupLayout.PREFERRED_SIZE, 851, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Afficher_Etud6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jButton53)
                        .addComponent(pa5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Afficher_Etud6Layout.setVerticalGroup(
            Afficher_Etud6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Afficher_Etud6Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jScrollPane25, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(pa5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jButton53, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 87, Short.MAX_VALUE)
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout compethenceLayout = new javax.swing.GroupLayout(compethence);
        compethence.setLayout(compethenceLayout);
        compethenceLayout.setHorizontalGroup(
            compethenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 904, Short.MAX_VALUE)
            .addGroup(compethenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Afficher_Etud6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        compethenceLayout.setVerticalGroup(
            compethenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 628, Short.MAX_VALUE)
            .addGroup(compethenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(compethenceLayout.createSequentialGroup()
                    .addComponent(Afficher_Etud6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainPanel.add(compethence, "card24");

        scolaire2.setBackground(new java.awt.Color(204, 204, 204));

        Afficher_Etud7.setBackground(new java.awt.Color(255, 255, 255));

        jPanel20.setBackground(new java.awt.Color(204, 204, 204));

        btnniveau22.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau22.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau22.setText("Information personnel(suite)");
        btnniveau22.setBorder(null);
        btnniveau22.setContentAreaFilled(false);
        btnniveau22.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau22.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau22.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau22.setIconTextGap(10);
        btnniveau22.setOpaque(true);
        btnniveau22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau22MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau22MouseExited(evt);
            }
        });
        btnniveau22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau22ActionPerformed(evt);
            }
        });

        btnniveau23.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau23.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau23.setText("    Informations personnel");
        btnniveau23.setBorder(null);
        btnniveau23.setContentAreaFilled(false);
        btnniveau23.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau23.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau23.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau23.setIconTextGap(10);
        btnniveau23.setOpaque(true);
        btnniveau23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau23MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau23MouseExited(evt);
            }
        });
        btnniveau23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau23ActionPerformed(evt);
            }
        });

        btnniveau24.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau24.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau24.setText("Informations scolaire(suite)");
        btnniveau24.setBorder(null);
        btnniveau24.setContentAreaFilled(false);
        btnniveau24.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau24.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau24.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau24.setIconTextGap(10);
        btnniveau24.setOpaque(true);
        btnniveau24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau24MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau24MouseExited(evt);
            }
        });
        btnniveau24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau24ActionPerformed(evt);
            }
        });

        btnniveau25.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau25.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau25.setText("Informations scolaire");
        btnniveau25.setBorder(null);
        btnniveau25.setContentAreaFilled(false);
        btnniveau25.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau25.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau25.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau25.setIconTextGap(10);
        btnniveau25.setOpaque(true);
        btnniveau25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau25MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau25MouseExited(evt);
            }
        });
        btnniveau25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau25ActionPerformed(evt);
            }
        });

        btnniveau26.setBackground(new java.awt.Color(204, 204, 204));
        btnniveau26.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        btnniveau26.setText("Compéthences");
        btnniveau26.setBorder(null);
        btnniveau26.setContentAreaFilled(false);
        btnniveau26.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnniveau26.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnniveau26.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnniveau26.setIconTextGap(10);
        btnniveau26.setOpaque(true);
        btnniveau26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnniveau26MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnniveau26MouseExited(evt);
            }
        });
        btnniveau26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnniveau26ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(186, 186, 186)
                .addComponent(btnniveau22, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau25, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau24, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnniveau26, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
            .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel20Layout.createSequentialGroup()
                    .addComponent(btnniveau23, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 840, Short.MAX_VALUE)))
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnniveau25, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
            .addComponent(btnniveau24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnniveau26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnniveau22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel20Layout.createSequentialGroup()
                    .addComponent(btnniveau23, javax.swing.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pa4.setBackground(new java.awt.Color(255, 255, 255));
        pa4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Informations scolaire", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Traditional Arabic", 1, 14))); // NOI18N

        jLabel191.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel191.setText("Résultat du semestre");

        jLabel194.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jLabel194.setText("Nombre d'abcenses");

        nbr_abc_a.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        nbr_abc_a.setBorder(null);

        res_a.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        res_a.setBorder(null);

        javax.swing.GroupLayout pa4Layout = new javax.swing.GroupLayout(pa4);
        pa4.setLayout(pa4Layout);
        pa4Layout.setHorizontalGroup(
            pa4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pa4Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(pa4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel194, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nbr_abc_a, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel191, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(res_a, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(242, Short.MAX_VALUE))
        );
        pa4Layout.setVerticalGroup(
            pa4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pa4Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jLabel194)
                .addGap(18, 18, 18)
                .addComponent(nbr_abc_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(jLabel191)
                .addGap(32, 32, 32)
                .addComponent(res_a, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(107, Short.MAX_VALUE))
        );

        jButton35.setBackground(new java.awt.Color(51, 0, 255));
        jButton35.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton35.setForeground(new java.awt.Color(255, 255, 255));
        jButton35.setText("Imprimer la relver des notes");
        jButton35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton35ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Afficher_Etud7Layout = new javax.swing.GroupLayout(Afficher_Etud7);
        Afficher_Etud7.setLayout(Afficher_Etud7Layout);
        Afficher_Etud7Layout.setHorizontalGroup(
            Afficher_Etud7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Afficher_Etud7Layout.createSequentialGroup()
                .addGroup(Afficher_Etud7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Afficher_Etud7Layout.createSequentialGroup()
                        .addGap(323, 323, 323)
                        .addComponent(text_num, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel20, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(Afficher_Etud7Layout.createSequentialGroup()
                .addGap(101, 101, 101)
                .addComponent(pa4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton35)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        Afficher_Etud7Layout.setVerticalGroup(
            Afficher_Etud7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Afficher_Etud7Layout.createSequentialGroup()
                .addContainerGap(103, Short.MAX_VALUE)
                .addGroup(Afficher_Etud7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pa4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton35, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(39, 39, 39)
                .addComponent(text_num, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout scolaire2Layout = new javax.swing.GroupLayout(scolaire2);
        scolaire2.setLayout(scolaire2Layout);
        scolaire2Layout.setHorizontalGroup(
            scolaire2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1029, Short.MAX_VALUE)
            .addGroup(scolaire2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, scolaire2Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(Afficher_Etud7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        scolaire2Layout.setVerticalGroup(
            scolaire2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 621, Short.MAX_VALUE)
            .addGroup(scolaire2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(scolaire2Layout.createSequentialGroup()
                    .addComponent(Afficher_Etud7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainPanel.add(scolaire2, "card25");

        table_mod.setBackground(new java.awt.Color(255, 255, 255));

        Table_Module1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        Table_Module1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Table_Module1MouseClicked(evt);
            }
        });
        jScrollPane28.setViewportView(Table_Module1);

        jLabel37.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        jLabel37.setText("Modules");

        jButton50.setBackground(new java.awt.Color(0, 0, 204));
        jButton50.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton50.setForeground(new java.awt.Color(255, 255, 255));
        jButton50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-undo-27.png"))); // NOI18N
        jButton50.setText("Retour");
        jButton50.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton50ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(0, 0, 204));
        jButton2.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Imprimer");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout table_modLayout = new javax.swing.GroupLayout(table_mod);
        table_mod.setLayout(table_modLayout);
        table_modLayout.setHorizontalGroup(
            table_modLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(table_modLayout.createSequentialGroup()
                .addGroup(table_modLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(table_modLayout.createSequentialGroup()
                        .addGap(554, 554, 554)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton50, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(table_modLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(table_modLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane28, javax.swing.GroupLayout.PREFERRED_SIZE, 830, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(table_modLayout.createSequentialGroup()
                                .addGap(80, 80, 80)
                                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(42, Short.MAX_VALUE))
        );
        table_modLayout.setVerticalGroup(
            table_modLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(table_modLayout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jLabel37)
                .addGap(61, 61, 61)
                .addComponent(jScrollPane28, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(table_modLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton50, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(51, Short.MAX_VALUE))
        );

        mainPanel.add(table_mod, "card26");

        tablenote.setBackground(new java.awt.Color(255, 255, 255));

        noter_abc.setBackground(new java.awt.Color(255, 255, 255));

        Table_Abc.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        Table_Abc.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Num...", "Nom...", "Prénom...",  new Boolean(true)},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Numéro d'inscription", "Nom", "Prénom", "Absent(e)?"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        Table_Abc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Table_AbcMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(Table_Abc);

        jLabel5.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel5.setText("Noter une absence ou un retard");

        jPanel7.setBackground(new java.awt.Color(204, 204, 204));

        jButton37.setBackground(new java.awt.Color(0, 0, 204));
        jButton37.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton37.setForeground(new java.awt.Color(255, 255, 255));
        jButton37.setText("Sauvegarder");
        jButton37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton37ActionPerformed(evt);
            }
        });

        jButton49.setBackground(new java.awt.Color(0, 0, 204));
        jButton49.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton49.setForeground(new java.awt.Color(255, 255, 255));
        jButton49.setText("Supprimer");
        jButton49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton49ActionPerformed(evt);
            }
        });

        jButton51.setBackground(new java.awt.Color(0, 0, 204));
        jButton51.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton51.setForeground(new java.awt.Color(255, 255, 255));
        jButton51.setText("Voir les absences");
        jButton51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton51ActionPerformed(evt);
            }
        });

        jButton52.setBackground(new java.awt.Color(0, 0, 204));
        jButton52.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton52.setForeground(new java.awt.Color(255, 255, 255));
        jButton52.setText("Voir les retards");
        jButton52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton52ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(116, 116, 116)
                .addComponent(jButton37, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46)
                .addComponent(jButton49, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81)
                .addComponent(jButton52, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(77, 77, 77)
                .addComponent(jButton51)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton49, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton52, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton51, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jButton15.setBackground(new java.awt.Color(204, 204, 204));
        jButton15.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton15.setForeground(new java.awt.Color(255, 0, 204));
        jButton15.setText("Retour");
        jButton15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout noter_abcLayout = new javax.swing.GroupLayout(noter_abc);
        noter_abc.setLayout(noter_abcLayout);
        noter_abcLayout.setHorizontalGroup(
            noter_abcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(noter_abcLayout.createSequentialGroup()
                .addGap(82, 82, 82)
                .addGroup(noter_abcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 721, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton15)
                    .addGroup(noter_abcLayout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(449, 449, 449)))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        noter_abcLayout.setVerticalGroup(
            noter_abcLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, noter_abcLayout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(jLabel5)
                .addGap(55, 55, 55)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(jButton15)
                .addGap(39, 39, 39)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout tablenoteLayout = new javax.swing.GroupLayout(tablenote);
        tablenote.setLayout(tablenoteLayout);
        tablenoteLayout.setHorizontalGroup(
            tablenoteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 890, Short.MAX_VALUE)
            .addGroup(tablenoteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(tablenoteLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(noter_abc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        tablenoteLayout.setVerticalGroup(
            tablenoteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 624, Short.MAX_VALUE)
            .addGroup(tablenoteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(tablenoteLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(noter_abc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainPanel.add(tablenote, "card27");

        sessionrattrapage.setBackground(new java.awt.Color(255, 255, 255));

        jLabel24.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel24.setText("Session rattrapage");

        jLabel86.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel86.setText("Filiere");

        filiere_etud1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere_etud1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                filiere_etud1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiere_etud1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiere_etud1MouseExited(evt);
            }
        });

        jLabel97.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel97.setText("Option");

        option_etud1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option_etud1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                option_etud1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                option_etud1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                option_etud1MouseExited(evt);
            }
        });

        jLabel107.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel107.setText("Niveau");

        niveau_etud1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un niveau" }));
        niveau_etud1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                niveau_etud1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                niveau_etud1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                niveau_etud1MouseExited(evt);
            }
        });

        jLabel109.setFont(new java.awt.Font("Traditional Arabic", 1, 14)); // NOI18N
        jLabel109.setText("Module");

        module_etud1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un module" }));
        module_etud1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                module_etud1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                module_etud1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                module_etud1MouseExited(evt);
            }
        });

        jButton36.setBackground(new java.awt.Color(0, 0, 204));
        jButton36.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton36.setForeground(new java.awt.Color(255, 255, 255));
        jButton36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-curved-arrow-27.png"))); // NOI18N
        jButton36.setText("Suivant");
        jButton36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton36ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(0, 0, 204));
        jButton3.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-undo-27.png"))); // NOI18N
        jButton3.setText("Retour");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout sessionrattrapageLayout = new javax.swing.GroupLayout(sessionrattrapage);
        sessionrattrapage.setLayout(sessionrattrapageLayout);
        sessionrattrapageLayout.setHorizontalGroup(
            sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sessionrattrapageLayout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addGroup(sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(sessionrattrapageLayout.createSequentialGroup()
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(502, 502, 502))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, sessionrattrapageLayout.createSequentialGroup()
                        .addGroup(sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(sessionrattrapageLayout.createSequentialGroup()
                                .addGroup(sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel107, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel86)
                                    .addComponent(jLabel97)
                                    .addComponent(jLabel109))
                                .addGap(112, 112, 112)
                                .addGroup(sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(option_etud1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(niveau_etud1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(module_etud1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(filiere_etud1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(sessionrattrapageLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton36, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(278, 278, 278))))
        );
        sessionrattrapageLayout.setVerticalGroup(
            sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sessionrattrapageLayout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(jLabel24)
                .addGap(95, 95, 95)
                .addGroup(sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel86)
                    .addComponent(filiere_etud1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel97)
                    .addComponent(option_etud1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel107)
                    .addComponent(niveau_etud1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(sessionrattrapageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel109)
                    .addComponent(module_etud1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(83, 83, 83)
                .addComponent(jButton36, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3)
                .addContainerGap(101, Short.MAX_VALUE))
        );

        mainPanel.add(sessionrattrapage, "card32");

        Semestre.setBackground(new java.awt.Color(255, 255, 255));

        jButton54.setBackground(new java.awt.Color(0, 0, 204));
        jButton54.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jButton54.setForeground(new java.awt.Color(255, 255, 255));
        jButton54.setText("Afficher");
        jButton54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton54ActionPerformed(evt);
            }
        });

        jLabel143.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel143.setText("Filiere");

        filiere_s.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une filière" }));
        filiere_s.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                filiere_sMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                filiere_sMouseExited(evt);
            }
        });

        jLabel144.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel144.setText("Option");

        option_s.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir une option" }));
        option_s.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                option_sMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                option_sMouseExited(evt);
            }
        });

        jLabel145.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jLabel145.setText("Niveau");

        niveau_s.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Choisir un niveau" }));
        niveau_s.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                niveau_sMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                niveau_sMouseExited(evt);
            }
        });

        res_label.setFont(new java.awt.Font("Traditional Arabic", 1, 24)); // NOI18N
        res_label.setText("Résultat du semestre");

        jButton55.setBackground(new java.awt.Color(0, 0, 204));
        jButton55.setFont(new java.awt.Font("Traditional Arabic", 0, 14)); // NOI18N
        jButton55.setForeground(new java.awt.Color(255, 255, 255));
        jButton55.setText("Calculer");
        jButton55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton55ActionPerformed(evt);
            }
        });

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/تنزيل.jpg"))); // NOI18N

        javax.swing.GroupLayout SemestreLayout = new javax.swing.GroupLayout(Semestre);
        Semestre.setLayout(SemestreLayout);
        SemestreLayout.setHorizontalGroup(
            SemestreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SemestreLayout.createSequentialGroup()
                .addGap(257, 257, 257)
                .addGroup(SemestreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton55, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton54, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 229, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addGap(97, 97, 97))
            .addGroup(SemestreLayout.createSequentialGroup()
                .addGap(113, 113, 113)
                .addGroup(SemestreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SemestreLayout.createSequentialGroup()
                        .addComponent(jLabel143, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(143, 143, 143)
                        .addComponent(filiere_s, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(SemestreLayout.createSequentialGroup()
                        .addComponent(jLabel144, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(143, 143, 143)
                        .addComponent(option_s, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(SemestreLayout.createSequentialGroup()
                        .addComponent(jLabel145, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(143, 143, 143)
                        .addComponent(niveau_s, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(SemestreLayout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(res_label, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SemestreLayout.setVerticalGroup(
            SemestreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SemestreLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addGap(86, 86, 86))
            .addGroup(SemestreLayout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(res_label, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102)
                .addGroup(SemestreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(filiere_s, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel143))
                .addGap(10, 10, 10)
                .addGroup(SemestreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel144)
                    .addComponent(option_s, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(SemestreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel145)
                    .addComponent(niveau_s, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 140, Short.MAX_VALUE)
                .addComponent(jButton55)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton54)
                .addGap(112, 112, 112))
        );

        mainPanel.add(Semestre, "card28");

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));

        Table_Et1.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        Table_Et1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Numéro d'inscription", "Nom", "Note du contrôle continus", "Note du contrôle final"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane4.setViewportView(Table_Et1);
        if (Table_Et1.getColumnModel().getColumnCount() > 0) {
            Table_Et1.getColumnModel().getColumn(2).setResizable(false);
            Table_Et1.getColumnModel().getColumn(3).setResizable(false);
        }

        jButton58.setBackground(new java.awt.Color(0, 0, 204));
        jButton58.setFont(new java.awt.Font("Traditional Arabic", 0, 12)); // NOI18N
        jButton58.setForeground(new java.awt.Color(255, 255, 255));
        jButton58.setText("Sauvegarder");
        jButton58.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton58ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Traditional Arabic", 1, 18)); // NOI18N
        jLabel15.setText("Table des notes");

        jButton34.setBackground(new java.awt.Color(51, 0, 255));
        jButton34.setFont(new java.awt.Font("Traditional Arabic", 1, 12)); // NOI18N
        jButton34.setForeground(new java.awt.Color(255, 255, 255));
        jButton34.setText("Retour");
        jButton34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton34ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 702, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(386, 386, 386)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton58, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                            .addComponent(jButton34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(97, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jButton58)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton34)
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 890, Short.MAX_VALUE)
            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel11Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 616, Short.MAX_VALUE)
            .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel11Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        mainPanel.add(jPanel11, "card29");

        bodyPanel1.add(mainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 47, 890, 610));

        jPanel1.setBackground(new java.awt.Color(0, 0, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setBackground(new java.awt.Color(255, 153, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 5)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8-delete-26.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.setContentAreaFilled(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 10, 50, 30));
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 40, 30));

        jButton9.setContentAreaFilled(false);
        jButton9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 10, 40, 30));

        bodyPanel1.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bodyPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bodyPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 658, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnhomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhomeActionPerformed
        

        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(homePanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnhomeActionPerformed

    private void btninscriptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninscriptionActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(inscriptionpanel);
        mainPanel.repaint();
        mainPanel.revalidate();      
    }//GEN-LAST:event_btninscriptionActionPerformed

    private void btnabcenseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnabcenseActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(abcensepanel);
        mainPanel.repaint();
        mainPanel.revalidate();      
    }//GEN-LAST:event_btnabcenseActionPerformed

    private void btnmoduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmoduleActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(modulepanel);
        mainPanel.repaint();
        mainPanel.revalidate();

       
    }//GEN-LAST:event_btnmoduleActionPerformed

    private void btnnoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnoteActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(notepanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnnoteActionPerformed

    private void btnresultatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresultatActionPerformed
       // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(Semestre);
        mainPanel.repaint();
        mainPanel.revalidate();
        
    }//GEN-LAST:event_btnresultatActionPerformed

    private void btnhomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseClicked
        
    }//GEN-LAST:event_btnhomeMouseClicked

    private void btninscriptionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btninscriptionMouseEntered
 btninscription.setBackground(new Color (0,0,204));    }//GEN-LAST:event_btninscriptionMouseEntered

    private void btnabcenseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnabcenseMouseEntered
       btnabcense.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnabcenseMouseEntered

    private void btnmoduleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnmoduleMouseClicked
        
    }//GEN-LAST:event_btnmoduleMouseClicked

    private void btnnoteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnnoteMouseEntered
       btnnote.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnnoteMouseEntered

    private void btnresultatMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultatMouseEntered
        btnresultat.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnresultatMouseEntered

    private void btnresultatMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultatMouseExited
        btnresultat.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnresultatMouseExited

    private void btnnoteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnnoteMouseExited
       btnnote.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnnoteMouseExited

    private void btnmoduleMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnmoduleMouseExited
        btnmodule.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnmoduleMouseExited

    private void btnabcenseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnabcenseMouseExited
        btnabcense.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnabcenseMouseExited

    private void btninscriptionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btninscriptionMouseExited
        btninscription.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btninscriptionMouseExited

    private void btnhomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseExited
        btnhome.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnhomeMouseExited

    private void btnhomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnhomeMouseEntered
        
        btnhome.setBackground(new Color (0,0,204));
       
    }//GEN-LAST:event_btnhomeMouseEntered

    private void btnmoduleMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnmoduleMouseEntered
        btnmodule.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnmoduleMouseEntered

    private void btnfiliereMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnfiliereMouseEntered
             btnfiliere.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnfiliereMouseEntered

    private void btnfiliereMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnfiliereMouseExited
           btnfiliere.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnfiliereMouseExited

    private void btnfiliereActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfiliereActionPerformed
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(filierepanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnfiliereActionPerformed

    private void SupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SupprimerActionPerformed
        if(nomfiliere.getText().length()==0){
            JOptionPane.showMessageDialog(null,"Vieullez taper le nom de la filière pour la supprimer !");
        }else{
             Supprimer_Filiere();
             Afficher_Filiere();
             nomfiliere.setText("");
             
        }
        
       
    }//GEN-LAST:event_SupprimerActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        Ajouter_Filiere();
        Afficher_Filiere();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void Table_FiliereMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Table_FiliereMouseClicked
        try{
           //Séléctionner une ligne de la table
          i=Table_Filiere.getSelectedRow();
          //Déplacer la ligne
         Deplacer_Filiere(i);
       }catch(Exception e){
           JOptionPane.showMessageDialog(null,"Erreur Séléctionné !");
       }
    }//GEN-LAST:event_Table_FiliereMouseClicked

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        Ajouter_Option();
        Afficher_Option();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        Supprimer_Option();
        Afficher_Option();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void Table_OptionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Table_OptionMouseClicked
         try{
           //Séléctionner une ligne de la table
          i=Table_Option.getSelectedRow();
          //Déplacer la ligne
         Deplacer_Option(i);
       }catch(Exception e){
           JOptionPane.showMessageDialog(null,"Erreur Séléctionné !");
       }        
    }//GEN-LAST:event_Table_OptionMouseClicked

    private void femmeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_femmeActionPerformed
     buttonGroup2.add(femme);
        sexe=femme.getText();
    }//GEN-LAST:event_femmeActionPerformed

    private void hommeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hommeActionPerformed
    buttonGroup2.add(homme);
      sexe=homme.getText();
    }//GEN-LAST:event_hommeActionPerformed

    private void parcourireActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_parcourireActionPerformed
        JFileChooser fileChooser=new JFileChooser();
         label.setText("");
        FileNameExtensionFilter filter=new FileNameExtensionFilter("IMAGE","jpg","png","gif");

        fileChooser.addChoosableFileFilter(filter);
        int result=fileChooser.showSaveDialog(null);
        if(result==JFileChooser.APPROVE_OPTION){
            File Selectedfile=fileChooser.getSelectedFile();
            String path=Selectedfile.getAbsolutePath();
            ImageIcon myImage=new ImageIcon(path);
            Image img=myImage.getImage();
            Image newImage=img.getScaledInstance(label.getWidth(),label.getHeight(),Image.SCALE_SMOOTH);
            ImageIcon finalImg=new ImageIcon(newImage);
            label.setIcon(finalImg);
            url.setText(path);

        }
    }//GEN-LAST:event_parcourireActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
                  // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(inscription2panel);
        mainPanel.repaint();
        mainPanel.revalidate();                
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(inscription3panel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton18ActionPerformed

    private void situationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_situationActionPerformed
       if(situation.getSelectedItem().toString().equals("Célibataire")){
           nbr_enfant.setVisible(false);
           Oui.setVisible(false);
           Non.setVisible(false);
           label_enf.setVisible(false);
           jLabel85.setVisible(false);
       }else{
            nbr_enfant.setVisible(true);
           Oui.setVisible(true);
           Non.setVisible(true);
           label_enf.setVisible(true);
           jLabel85.setVisible(true);
       }
    }//GEN-LAST:event_situationActionPerformed

    private void OuiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OuiActionPerformed
         buttonGroup1.add(Oui);
          enfant=Oui.getText();
          if(Oui.isSelected()){
                  label_enf.setVisible(true);
                  nbr_enfant.setVisible(true);
              }else{
                   label_enf.setVisible(false);
                   nbr_enfant.setVisible(false);
              }
    }//GEN-LAST:event_OuiActionPerformed

    private void NonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NonActionPerformed
         buttonGroup1.add(Non);
         enfant=Non.getText();
         if(Oui.isSelected()){
                 label_enf.setVisible(true);
                  nbr_enfant.setVisible(true);
              }else{
                   label_enf.setVisible(false);
                   nbr_enfant.setVisible(false);
              }
    }//GEN-LAST:event_NonActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(inscription2panel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(inscription4panel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(inscriptionpanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton25ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
       try{
             if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                        
//La requête qui permet de supprimer les données de bla base de données ______________________________________________________                    
              String  query="Delete from Element_Module where Nom_Element = '"+nom_elem.getText()+"'";
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
              JOptionPane.showMessageDialog(null,"Les informations sont supprimées !");}
              Afficher_Element();
            
        }catch(HeadlessException | SQLException e){
             JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_jButton29ActionPerformed

    private void btn_interMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_interMouseEntered
       btn_inter.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btn_interMouseEntered

    private void btn_interMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_interMouseExited
         btn_inter.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btn_interMouseExited

    private void btn_interActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_interActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(etudiant);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btn_interActionPerformed

    private void table_coorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table_coorMouseClicked
    /*        try{
           //Séléctionner une ligne de la table
          i=table_coor.getSelectedRow();
          //Déplacer la ligne
         Deplacer_Coordinateur(i);
       }catch(Exception e){
           JOptionPane.showMessageDialog(null,"Erreur Séléctionné !");
       }*/
    }//GEN-LAST:event_table_coorMouseClicked

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
       Ajouter_Coordinateur();
       Afficher_Coordinateur();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void Supprimer2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Supprimer2ActionPerformed
        Supprimer_Coordinateur();
        Afficher_Coordinateur();
        cin_coor.setText("");
        nom_coor.setText("");
        tel1_coor.setText("");
        tel2_coor.setText("");
        num_compte.setText("");
        email_coor.setText("");
        
    }//GEN-LAST:event_Supprimer2ActionPerformed

    private void ouiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ouiActionPerformed
        buttonGroup3.add(oui);
        boursiere=oui.getText();
    }//GEN-LAST:event_ouiActionPerformed

    private void nonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nonActionPerformed
         buttonGroup1.add(non);
        boursiere=non.getText();
    }//GEN-LAST:event_nonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        
        
         
              
    }//GEN-LAST:event_formWindowOpened

    private void tel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tel1ActionPerformed
        
    }//GEN-LAST:event_tel1ActionPerformed

    private void tel1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tel1KeyPressed
       char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            //Can't able to enter in TextField if enter char is not number
            tel1.setEditable(false);
            //Set error message
            label_number.setVisible(true);
            label_number.setText("Veuillez tapez un nombre");
        }else{
             label_number.setVisible(false);
            tel1.setEditable(true);
        }
    }//GEN-LAST:event_tel1KeyPressed

    private void tel2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tel2KeyPressed
         char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            //Can't able to enter in TextField if enter char is not number
            tel2.setEditable(false);
            //Set error message
            label_number.setVisible(true);
            label_number.setText("Veuillez tapez un nombre");
        }else{
             label_number.setVisible(false);
            tel2.setEditable(true);
        }
    }//GEN-LAST:event_tel2KeyPressed

    private void obtentionKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_obtentionKeyPressed
         char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            //Can't able to enter in TextField if enter char is not number
            obtention.setEditable(false);
            //Set error message
           obtention.setBackground(red);
            
        }else{
            obtention.setBackground(white);
            obtention.setEditable(true);
        }
    }//GEN-LAST:event_obtentionKeyPressed

    private void adr2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_adr2KeyPressed
         
    }//GEN-LAST:event_adr2KeyPressed

    private void tel1_coorKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tel1_coorKeyPressed
        char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            //Can't able to enter in TextField if enter char is not number
            tel1_coor.setEditable(false);
            //Set error message
            tel1_coor.setBackground(red);
        }else{
              tel1_coor.setBackground(white);
            tel1_coor.setEditable(true);}
    }//GEN-LAST:event_tel1_coorKeyPressed

    private void nbr_enfantKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nbr_enfantKeyPressed
  char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            //Can't able to enter in TextField if enter char is not number
             nbr_enfant.setEditable(false);
            //Set error message
            nbr_enfant.setBackground(red);
            
        }else{
            nbr_enfant.setBackground(white);
           nbr_enfant.setEditable(true);}        
    }//GEN-LAST:event_nbr_enfantKeyPressed

    private void whatsupKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_whatsupKeyPressed
          char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            //Can't able to enter in TextField if enter char is not number
            whatsup.setEditable(false);
            //Set error message
           whatsup.setBackground(red);
            
        }else{
            whatsup.setBackground(white);
            whatsup.setEditable(true);}
    }//GEN-LAST:event_whatsupKeyPressed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
          String o=option_mod.getSelectedItem().toString();
          String code=Code_Option(o)+Id_Module();
             Calendar calendar = Calendar.getInstance(); 
                int ane=calendar.get( Calendar.YEAR );
         String module = "INSERT INTO Module_E(Code_Module,Intitule_Module,Nombre_Element,Volume_Horaire,Type_Module,Filiere_Mod,Option_Mod,Niveau_Mod,Année) VALUES('"+code+"','"+nom_module.getText()+"','"+nbr_elem.getText()+"','"+horaire_mod.getSelectedItem().toString()+"','"+type.getSelectedItem().toString()+"','"+filiere_mod.getSelectedItem().toString()+"','"+option_mod.getSelectedItem().toString()+"','"+niveau_mod.getSelectedItem().toString()+"','"+ane+"')";
        try{
         if(nom_module.getText().length()!=0 ){
            
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(module);
        ps.executeUpdate();
         JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
        // Afficher_Module();
      }
        else{
             JOptionPane.showMessageDialog(null,"Veuillez d'abord taper un nom pour le module ! ");
        }
       }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
    
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
        try{
             if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                        
//La requête qui permet de supprimer les données de bla base de données ______________________________________________________                    
              String  query="Delete from Module_E where Intitule_Module = '"+nom_module.getText()+"'";
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
              JOptionPane.showMessageDialog(null,"Les informations sont supprimées !");}
              Afficher_Module();
            
        }catch(HeadlessException | SQLException e){
             JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_jButton27ActionPerformed

    private void niveau_modActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_niveau_modActionPerformed
        
    }//GEN-LAST:event_niveau_modActionPerformed

    private void niveau_modKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_niveau_modKeyPressed
      
    }//GEN-LAST:event_niveau_modKeyPressed

    private void niveau_modMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_modMouseClicked
        
    }//GEN-LAST:event_niveau_modMouseClicked

    private void filiere_modMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_modMouseClicked
       
    }//GEN-LAST:event_filiere_modMouseClicked

    private void option_modMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_modMouseClicked
       
    }//GEN-LAST:event_option_modMouseClicked

    private void nom_filiereMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nom_filiereMouseClicked
         
    }//GEN-LAST:event_nom_filiereMouseClicked

    private void filiereMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiereMouseClicked
        
    }//GEN-LAST:event_filiereMouseClicked

    private void optionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_optionMouseClicked
         
    }//GEN-LAST:event_optionMouseClicked

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
         try{
             
         String o = "INSERT INTO Element_Module(Nom_Element,Nom_Module,Volume_Horaire_E,Intervenant_Element) "
                 + "VALUES('"+nom_elem.getText()+"','"+mod_elem.getSelectedItem().toString()+"',"
                 + "'"+horaire_elem.getText()+"','"+inter_elem.getSelectedItem().toString()+"')";
     
      if(nom_elem.getText().length()!=0 ){
            
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
         JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
         Afficher_Element();
      }
        else{
             JOptionPane.showMessageDialog(null,"Veuillez d'abord taper un nom pour l'élément ! ");
        }
       }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
    }//GEN-LAST:event_jButton28ActionPerformed

    private void Table_ElementMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Table_ElementMouseClicked
            try{
           //Séléctionner une ligne de la table
          i=Table_Element.getSelectedRow();
          //Déplacer la ligne
         Deplacer_Element(i);
       }catch(Exception e){
           JOptionPane.showMessageDialog(null,"Erreur Séléctionné !");
       }
    }//GEN-LAST:event_Table_ElementMouseClicked

    private void mod_elemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mod_elemMouseClicked
             
        
    }//GEN-LAST:event_mod_elemMouseClicked

    private void filiere_etudMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_etudMouseClicked
          
    }//GEN-LAST:event_filiere_etudMouseClicked

    private void option_etudMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_etudMouseClicked
        
       
    }//GEN-LAST:event_option_etudMouseClicked

    private void niveau_etudMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_etudMouseClicked
      
        
    }//GEN-LAST:event_niveau_etudMouseClicked

    private void module_etudMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_etudMouseClicked
        
    }//GEN-LAST:event_module_etudMouseClicked

    private void inter_elemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inter_elemMouseClicked
      
    }//GEN-LAST:event_inter_elemMouseClicked

    private void filiere_modMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_modMouseEntered
         filiere_mod.removeAllItems();
        remplirecomboboxFiliere();
    }//GEN-LAST:event_filiere_modMouseEntered

    private void option_modMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_modMouseEntered
         option_mod.removeAllItems();
        remplirecomboboxOption();
    }//GEN-LAST:event_option_modMouseEntered

    private void niveau_modMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_modMouseEntered
      niveau_mod.removeAllItems();
      niveau_mod.addItem("Semestre1");
      niveau_mod.addItem("Semestre2");
      niveau_mod.addItem("Semestre3");
      niveau_mod.addItem("Semestre4");
      niveau_mod.addItem("Semestre5");
      niveau_mod.addItem("Semestre6");
      
      
    }//GEN-LAST:event_niveau_modMouseEntered

    private void mod_elemMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mod_elemMouseEntered
          String requet="Select * From Module_E ";
      
        try{
            mod_elem.removeAllItems();
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
              String nommod=rs.getString("Intitule_Module");
              mod_elem.addItem(nommod);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_mod_elemMouseEntered

    private void inter_elemMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inter_elemMouseEntered
         inter_elem.removeAllItems();
        Afficher_F_Intervenant();
    }//GEN-LAST:event_inter_elemMouseEntered

    private void filiere_etudMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_etudMouseEntered
        filiere_etud.removeAllItems();
        remplirecomboboxFiliere();     
    }//GEN-LAST:event_filiere_etudMouseEntered

    private void option_etudMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_etudMouseEntered
         String s1 = filiere_etud.getSelectedItem().toString();
 //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************      
         String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";
             option_etud.removeAllItems();
        try{
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
             
              String nomoption=rs.getString("Nom_Option");
                option_etud.addItem(nomoption);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_option_etudMouseEntered

    private void niveau_etudMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_etudMouseEntered
         niveau_etud.removeAllItems();
        niveau_etud.addItem("Semestre1");  
            niveau_etud.addItem("Semestre2");  
             niveau_etud.addItem("Semestre3"); 
              niveau_etud.addItem("Semestre4");    
               niveau_etud.addItem("Semestre5"); 
                niveau_etud.addItem("Semestre6");    
              
    }//GEN-LAST:event_niveau_etudMouseEntered

    private void module_etudMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_etudMouseEntered
        String s1= option_etud.getSelectedItem().toString();
         String s2= niveau_etud.getSelectedItem().toString();
         String requet="Select * From Module_E where Option_Mod='"+s1+"' AND "
                 + "Niveau_Mod='"+s2+"'";
      
        try{
            module_etud.removeAllItems();
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
               //Extraire le nom du module 
              String nommod=rs.getString("Intitule_Module");
              module_etud.addItem(nommod);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_module_etudMouseEntered

    private void nom_filiereMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nom_filiereMouseEntered
        nom_filiere.removeAllItems();
        remplirecomboboxFiliere();
    }//GEN-LAST:event_nom_filiereMouseEntered

    private void filiereMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiereMouseEntered
        filiere.removeAllItems();
        remplirecomboboxFiliere();
    }//GEN-LAST:event_filiereMouseEntered

    private void optionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_optionMouseEntered
    
             
      String s1 = filiere.getSelectedItem().toString();
 //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************      
         String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";
             option.removeAllItems();
        try{
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
                 //if(filiere.getSelectedItem().toString().length()!=0){
              String nomoption=rs.getString("Nom_Option");
                option.addItem(nomoption);
               
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
        
        
    }//GEN-LAST:event_optionMouseEntered

    private void btncoorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncoorMouseEntered
         btncoor.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btncoorMouseEntered

    private void btncoorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btncoorMouseExited
        btncoor.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btncoorMouseExited

    private void btncoorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncoorActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(coordinateurpanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btncoorActionPerformed

    private void filiere_abcMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_abcMouseEntered
        
        filiere_abc.removeAllItems();
        remplirecomboboxFiliere();
    }//GEN-LAST:event_filiere_abcMouseEntered

    private void option_abcMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_abcMouseEntered
       
        String s1 = filiere_abc.getSelectedItem().toString();
 //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************      
         String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";
      
        try{
            option_abc.removeAllItems();
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
               //Format du date 
              
            
              String nomoption=rs.getString("Nom_Option");
                option_abc.addItem(nomoption);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_option_abcMouseEntered

    private void niveau_abcMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_abcMouseEntered
         
      niveau_abc.removeAllItems();
      niveau_abc.addItem("Semestre1");
       niveau_abc.addItem("Semestre2");
        niveau_abc.addItem("Semestre3");
         niveau_abc.addItem("Semestre4");
          niveau_abc.addItem("Semestre5");
           niveau_abc.addItem("Semestre6");
    }//GEN-LAST:event_niveau_abcMouseEntered

    private void module_abcMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_abcMouseEntered
       
        String s1= option_abc.getSelectedItem().toString();
         String s2= niveau_abc.getSelectedItem().toString();
         String requet="Select * From Module_E where Option_Mod='"+s1+"' AND "
                 + "Niveau_Mod='"+s2+"'";
      
        try{
            module_abc.removeAllItems();
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
               //Extraire le nom du module 
              String nommod=rs.getString("Intitule_Module");
              module_abc.addItem(nommod);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_module_abcMouseEntered

    private void elem_abcMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_elem_abcMouseEntered
         String s1= module_abc.getSelectedItem().toString();          
         String requet="Select * From Element_Module where Nom_Module='"+s1+"' ";
      
        try{
            elem_abc.removeAllItems();
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
               //Extraire le nom du module 
              String nom=rs.getString("Nom_Element");
              elem_abc.addItem(nom);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_elem_abcMouseEntered

    private void filiere_abcMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_abcMouseExited
        filiere_abc.addItem("Choisir une filière");
    }//GEN-LAST:event_filiere_abcMouseExited

    private void option_abcMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_abcMouseExited
        option_abc.addItem("Choisir une option");
    }//GEN-LAST:event_option_abcMouseExited

    private void niveau_abcMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_abcMouseExited
//        niveau_abc.addItem("Choisir un niveau");
    }//GEN-LAST:event_niveau_abcMouseExited

    private void module_abcMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_abcMouseExited
       module_abc.addItem("Choisir un module");
    }//GEN-LAST:event_module_abcMouseExited

    private void elem_abcMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_elem_abcMouseExited
        elem_abc.addItem("Choisir un élément");
    }//GEN-LAST:event_elem_abcMouseExited

    private void filiereMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiereMouseExited
         filiere.addItem("Choisir une filière");
    }//GEN-LAST:event_filiereMouseExited

    private void optionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_optionMouseExited
        filiere.addItem("Choisir une option");
    }//GEN-LAST:event_optionMouseExited

    private void module_etudMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_etudMouseExited
        module_etud.addItem("Choisir un module");
    }//GEN-LAST:event_module_etudMouseExited

    private void niveau_etudMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_etudMouseExited
//       niveau_etud.addItem("Choisir un niveau");
    }//GEN-LAST:event_niveau_etudMouseExited

    private void option_etudMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_etudMouseExited
        option_etud.addItem("Choisir une option");
    }//GEN-LAST:event_option_etudMouseExited

    private void filiere_etudMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_etudMouseExited
        filiere_etud.addItem("Choisir une filière");
    }//GEN-LAST:event_filiere_etudMouseExited

    private void niveau_modMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_modMouseExited
     // niveau_mod.addItem("Choisir un niveau");      
    }//GEN-LAST:event_niveau_modMouseExited

    private void option_modMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_modMouseExited
         option_mod.addItem("Choisir une option");
    }//GEN-LAST:event_option_modMouseExited

    private void filiere_modMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_modMouseExited
        filiere_mod.addItem("Choisir une filière");
    }//GEN-LAST:event_filiere_modMouseExited

    private void inter_elemMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inter_elemMouseExited
         inter_elem.addItem("Choisir un intervenant");
    }//GEN-LAST:event_inter_elemMouseExited

    private void mod_elemMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mod_elemMouseExited
         mod_elem.addItem("Choisir un module");
    }//GEN-LAST:event_mod_elemMouseExited

    private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(sessionrattrapage);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton39ActionPerformed

    private void tel1_coorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tel1_coorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tel1_coorActionPerformed

    private void filiere_coorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_coorMouseEntered
       
             filiere_coor.removeAllItems();
             remplirecomboboxFiliere();
        
    }//GEN-LAST:event_filiere_coorMouseEntered

    private void option_coorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_coorMouseEntered
        
        
        
        String s1 = filiere_coor.getSelectedItem().toString();
 //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************      
         String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";
      
        try{
            option_coor.removeAllItems();
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
               //Format du date 
              
            
              String nomoption=rs.getString("Nom_Option");
                option_coor.addItem(nomoption);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    
    }//GEN-LAST:event_option_coorMouseEntered

    private void module_coorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_coorMouseEntered
       
        String requet="Select * From Module_E where Option_Mod='"+option_coor.getSelectedItem().toString()+"'";
      
        try{
            module_coor.removeAllItems();
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
              String nommod=rs.getString("Intitule_Module");
              module_coor.addItem(nommod);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_module_coorMouseEntered

    private void nbr_enfantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nbr_enfantActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nbr_enfantActionPerformed

    private void OuiMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OuiMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_OuiMouseEntered

    private void fonction_coorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fonction_coorActionPerformed
              
       
    }//GEN-LAST:event_fonction_coorActionPerformed

    private void type_coorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_type_coorMouseEntered
       
    }//GEN-LAST:event_type_coorMouseEntered

    private void fonction_coorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fonction_coorMouseEntered
      
    }//GEN-LAST:event_fonction_coorMouseEntered

    private void jButton42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton42ActionPerformed
                  try {
           
      if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                
        String sql="update Cors_Enseignant set Nom='"+nom_coor.getText()+"',Prenom='"+prenom_coor.getText()+"',"
                + "Grade='"+grade_coor.getText()+"',Email='"+email_coor.getText()+"',Telephone1='"+tel1_coor.getText()+"',"
                + "Telephone2='"+tel2_coor.getText()+"',Option_C='"+option_coor.getSelectedItem().toString()+"',"
                + "Filiere_C='"+filiere_coor.getSelectedItem().toString()+"',Module_C='"+module_coor.getSelectedItem().toString()+"'"
                + " WHERE CIN='"+cin_coor.getText()+"'";
        
      
        PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);
           
            pst.executeUpdate();
            Afficher_Coordinateur();
       
                
             JOptionPane.showMessageDialog(null,"modification effectué");
            //Afficher_Abcense();
      }
      
           
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());}
    }//GEN-LAST:event_jButton42ActionPerformed

    private void filiere_infoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_infoMouseEntered
       filiere_info.removeAllItems();
        remplirecomboboxFiliere();
    }//GEN-LAST:event_filiere_infoMouseEntered

    private void filiere_infoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_infoMouseExited
       filiere_info.addItem("Choisir une filière");
    }//GEN-LAST:event_filiere_infoMouseExited

    private void option_infoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_infoMouseEntered
            option_info.addItem("Choisir une option");
        String s1 = filiere_info.getSelectedItem().toString();
 //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************      
         String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";
      
        try{
            option_info.removeAllItems();
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
               //Format du date 
              
            
              String nomoption=rs.getString("Nom_Option");
                option_info.addItem(nomoption);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
           
    }//GEN-LAST:event_option_infoMouseEntered

    private void option_infoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_infoMouseExited
       option_info.addItem("Choisir une option");
    }//GEN-LAST:event_option_infoMouseExited

    private void niveau_infoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_infoMouseEntered
             niveau_info.removeAllItems();
             niveau_info.addItem("Semestre1");
             niveau_info.addItem("Semestre2");
               niveau_info.addItem("Semestre3");
                 niveau_info.addItem("Semestre4");
                   niveau_info.addItem("Semestre5");
                     niveau_info.addItem("Semestre6");
       
    }//GEN-LAST:event_niveau_infoMouseEntered

    private void niveau_infoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_infoMouseExited
//       niveau_info.addItem("Choisir un niveau");
    }//GEN-LAST:event_niveau_infoMouseExited

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
         Actualiser();
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(Afficher_Etud);
        mainPanel.repaint();
        mainPanel.revalidate();
            /* ------------------------------------- Table Afficher_Etudiants ----------------------------------------------------------- */        
         //Les noms des colonnes de la table 
      p1.setRowCount(0);
       
     
         String op=option_info.getSelectedItem().toString();
                String Fi=filiere_info.getSelectedItem().toString();
                String ni=niveau_info.getSelectedItem().toString();
                int an=jYearChooser1.getYear();
                String af="SELECT * FROM Etudiant WHERE Filiere_E='"+Fi+"' AND Option_E='"+op+"' AND Niveau_E='"+ni+"' AND Année='"+an+"' ";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(af);
                   while(rs.next()){
                   p1.addRow(new Object[]{rs.getString("CNE"), rs.getString("CIN"),rs.getString("Nom"),rs.getString("Prenom"),
                   rs.getString("Sexe"),rs.getString("Date_Naissance"),rs.getString("Lieux_Naissance"),rs.getString("Adresse1"),
                   rs.getString("Adresse2")} );
                   
                     
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
    
       
       table_per1.setModel(p1);
       
        
        Afficher_Info_Scolaire();
        Afficher_Compethence();
       Afficher_Info();
      
    }//GEN-LAST:event_jButton5ActionPerformed

    private void btnniveau1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau1MouseEntered
       btnniveau1.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau1MouseEntered

    private void btnniveau1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau1MouseExited
          btnniveau1.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveau1MouseExited

    private void btnniveau1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau1ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_per2);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau1ActionPerformed

    private void btnniveau2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau2MouseEntered
         btnniveau2.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau2MouseEntered

    private void btnniveau2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau2MouseExited
       btnniveau2.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveau2MouseExited

    private void btnniveau2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau2ActionPerformed
           // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(Afficher_Etud);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau2ActionPerformed

    private void btnniveau3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau3MouseEntered
          btnniveau3.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau3MouseEntered

    private void btnniveau3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau3MouseExited
         btnniveau3.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveau3MouseExited

    private void btnniveau3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau3ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(compethence);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau3ActionPerformed

    private void btnniveau4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau4MouseEntered
          btnniveau4.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau4MouseEntered

    private void btnniveau4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau4MouseExited
        btnniveau4.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveau4MouseExited

    private void btnniveau4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau4ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(scolaire2);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau4ActionPerformed

    private void prenom_aActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prenom_aActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prenom_aActionPerformed

    private void btnniveau5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau5MouseEntered
       btnniveau5.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnniveau5MouseEntered

    private void btnniveau5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau5MouseExited
        btnniveau5.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveau5MouseExited

    private void btnniveau5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau5ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_per2);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau5ActionPerformed

    private void btnniveau6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau6MouseEntered
        btnniveau6.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnniveau6MouseEntered

    private void btnniveau6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau6MouseExited
         btnniveau6.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveau6MouseExited

    private void btnniveau6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau6ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(Afficher_Etud);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau6ActionPerformed

    private void btnniveau7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau7MouseEntered
       btnniveau7.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnniveau7MouseEntered

    private void btnniveau7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau7MouseExited
        btnniveau7.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveau7MouseExited

    private void btnniveau7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau7ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(compethence);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau7ActionPerformed

    private void actuel_aActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actuel_aActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_actuel_aActionPerformed

    private void btnniveau13MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau13MouseEntered
        btnniveau13.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau13MouseEntered

    private void btnniveau13MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau13MouseExited
       btnniveau13.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau13MouseExited

    private void btnniveau13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau13ActionPerformed
       // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_per2);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau13ActionPerformed

    private void btnniveau14MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau14MouseEntered
        btnniveau14.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau14MouseEntered

    private void btnniveau14MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau14MouseExited
        btnniveau14.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau14MouseExited

    private void btnniveau14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau14ActionPerformed
       // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(Afficher_Etud);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau14ActionPerformed

    private void btnniveau15MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau15MouseEntered
       btnniveau15.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau15MouseEntered

    private void btnniveau15MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau15MouseExited
       btnniveau15.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau15MouseExited

    private void btnniveau15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau15ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(compethence);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau15ActionPerformed

    private void btnniveau16MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau16MouseEntered
        btnniveau16.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau16MouseEntered

    private void btnniveau16MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau16MouseExited
       btnniveau16.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau16MouseExited

    private void btnniveau16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau16ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_scolaire);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau16ActionPerformed

    private void cin_aActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cin_aActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cin_aActionPerformed

    private void jButton5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseEntered
    
     
    }//GEN-LAST:event_jButton5MouseEntered

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
       try{
       Rechercher_Etudiant();
       Afficher_Image();
     
       }catch(Exception e){
           
       }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton43ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(etudiant);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton43ActionPerformed

    private void email2_aActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_email2_aActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_email2_aActionPerformed

    private void lycee_aActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lycee_aActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lycee_aActionPerformed

    private void btnniveau18MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau18MouseEntered
        btnniveau18.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau18MouseEntered

    private void btnniveau18MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau18MouseExited
       btnniveau18.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau18MouseExited

    private void btnniveau18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau18ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(scolaire2);
        mainPanel.repaint();
        mainPanel.revalidate();        
    }//GEN-LAST:event_btnniveau18ActionPerformed

    private void btnniveau19MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau19MouseEntered
       btnniveau19.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnniveau19MouseEntered

    private void btnniveau19MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau19MouseExited
        btnniveau19.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveau19MouseExited

    private void btnniveau19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau19ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(scolaire2);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau19ActionPerformed

    private void btnniveau20MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau20MouseEntered
        btnniveau20.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnniveau20MouseEntered

    private void btnniveau20MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau20MouseExited
       btnniveau20.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveau20MouseExited

    private void btnniveau20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau20ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_scolaire);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau20ActionPerformed

    private void btnniveau21MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau21MouseEntered
        btnniveau21.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau21MouseEntered

    private void btnniveau21MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau21MouseExited
        btnniveau21.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau21MouseExited

    private void btnniveau21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau21ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(scolaire2);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau21ActionPerformed

    private void btnniveau22MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau22MouseEntered
       btnniveau22.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau22MouseEntered

    private void btnniveau22MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau22MouseExited
        btnniveau22.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau22MouseExited

    private void btnniveau22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau22ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_per2);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau22ActionPerformed

    private void btnniveau23MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau23MouseEntered
        btnniveau23.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau23MouseEntered

    private void btnniveau23MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau23MouseExited
        btnniveau23.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau23MouseExited

    private void btnniveau23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau23ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(Afficher_Etud);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau23ActionPerformed

    private void btnniveau24MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau24MouseEntered
       btnniveau24.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau24MouseEntered

    private void btnniveau24MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau24MouseExited
        btnniveau24.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau24MouseExited

    private void btnniveau24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau24ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(scolaire2);
        mainPanel.repaint();
        mainPanel.revalidate();
         
    }//GEN-LAST:event_btnniveau24ActionPerformed

    private void btnniveau25MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau25MouseEntered
        btnniveau25.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau25MouseEntered

    private void btnniveau25MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau25MouseExited
       btnniveau25.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau25MouseExited

    private void btnniveau25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau25ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_scolaire);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau25ActionPerformed

    private void btnniveau26MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau26MouseEntered
      btnniveau26.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau26MouseEntered

    private void btnniveau26MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau26MouseExited
        btnniveau26.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau26MouseExited

    private void btnniveau26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau26ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(compethence);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveau26ActionPerformed

    private void jButton44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton44ActionPerformed
       Modifier_Module();
       Afficher_Module();
    }//GEN-LAST:event_jButton44ActionPerformed

    private void jButton46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton46ActionPerformed
        Modifier_Element();
        Afficher_Element();
    }//GEN-LAST:event_jButton46ActionPerformed

    private void jButton48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton48ActionPerformed
       Modifier_Option();
       Afficher_Option();
    }//GEN-LAST:event_jButton48ActionPerformed

    private void tel2_coorKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tel2_coorKeyPressed
         char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            //Can't able to enter in TextField if enter char is not number
            tel2_coor.setEditable(false);
            //Set error message
            tel2_coor.setBackground(red);
        }else{
              tel2_coor.setBackground(white);
            tel2_coor.setEditable(true);}
    }//GEN-LAST:event_tel2_coorKeyPressed

    private void jButton47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton47ActionPerformed
       mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(table_mod);
        mainPanel.repaint();
        mainPanel.revalidate();
        Afficher_Module();
    }//GEN-LAST:event_jButton47ActionPerformed

    private void Table_Module1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Table_Module1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_Table_Module1MouseClicked

    private void jButton50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton50ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(modulepanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton50ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        hide();
        Login l=new Login();
       l.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void filiere_sMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_sMouseEntered
       filiere_s.removeAllItems();
       remplirecomboboxFiliere();
    }//GEN-LAST:event_filiere_sMouseEntered

    private void filiere_sMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_sMouseExited
        filiere_s.addItem("Choisir une filière");
    }//GEN-LAST:event_filiere_sMouseExited

    private void option_sMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_sMouseEntered
        String s1 = filiere_s.getSelectedItem().toString();
 //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************      
         String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";
      
        try{
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           option_s.removeAllItems();
            while(rs.next()){
               //Format du date 
              
            
              String nomoption=rs.getString("Nom_Option");
                option_s.addItem(nomoption);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_option_sMouseEntered

    private void option_sMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_sMouseExited
      option_s.addItem("Choisir une option");
    }//GEN-LAST:event_option_sMouseExited

    private void niveau_sMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_sMouseEntered
         niveau_s.removeAllItems();
         niveau_s.addItem("Semestre1");
          niveau_s.addItem("Semestre2");
           niveau_s.addItem("Semestre3");
            niveau_s.addItem("Semestre4");
             niveau_s.addItem("Semestre5");
              niveau_s.addItem("Semestre6");
    }//GEN-LAST:event_niveau_sMouseEntered

    private void niveau_sMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_sMouseExited
//       niveau_s.addItem("Choisir un niveau");
    }//GEN-LAST:event_niveau_sMouseExited

    private void jButton54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton54ActionPerformed
            String fi=filiere_s.getSelectedItem().toString();
            String op=option_s.getSelectedItem().toString();
            String niv=niveau_s.getSelectedItem().toString();
            try{
                 Liste_Etud_Ruisis c = new Liste_Etud_Ruisis(this,fi,op,niv);
             c.setVisible(true);
            }catch(Exception exc){
                JOptionPane.showMessageDialog(null,exc.getMessage());
            }
    }//GEN-LAST:event_jButton54ActionPerformed

    private void jButton45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton45ActionPerformed
                //Si les champs n'est pas vide l'impression fais avec sucées.****************************************************************     
        try{
          
        jButton45.addActionListener(new Imprimer(pa1));
        jButton45.addActionListener(new Imprimer(pa2));
        jButton45.addActionListener(new Imprimer(pa3));
        jButton45.addActionListener(new Imprimer(pa4));
        jButton45.addActionListener(new Imprimer(pa5));
         
       
            }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
          
        }
      
              
    }//GEN-LAST:event_jButton45ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
      
            Supprimer_Etudiant();
       
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton21MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton21MouseEntered
        num_insc.setVisible(true);
        insc.setVisible(true);
    }//GEN-LAST:event_jButton21MouseEntered

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed

        try {

            if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
            if(N_Inscription()){

                //String s1=num_insc.getText() ;
                String sql;
                sql = "update Etudiant set CIN='"+cin.getText()+"',Nom='"+nom.getText()+"',Prenom='"+prenom.getText()+"',Sexe='"+sexe+"',"
                + "Date_Naissance='"+((JTextField)naissance.getDateEditor().getUiComponent()).getText()+"',"
                + "Date_Inscription='"+((JTextField)inscription.getDateEditor().getUiComponent()).getText()+"',CNE='"+cne_p.getText()+"',"
                + "Filiere_E='"+filiere.getSelectedItem().toString()+"',Option_E='"+option.getSelectedItem().toString()+"',N_Telephone1='"+tel1.getText()+"',"
                + "Email2='"+email2.getText()+"',Langues_Maitrises='"+langue.getText()+"',Logiciels_Maitrises='"+logiciel.getText()+"',Photo=?,"
                + "Formation_Anterieure='"+anterieure.getText()+"',Formation_Attelier='"+attelier.getText()+"',Adresse_Actuel='"+adr_actuel.getText()+"',"
                + "Adresse1='"+adr1.getText()+"',Adresse2='"+adr2.getText()+"',Num_WhatsApp='"+whatsup.getText()+"',"
                + "N_Telephone2='"+tel2.getText()+"',Email1='"+email1.getText()+"',Nombre_Enfants='"+nbr_enfant.getText()+"' ,Lycee='"+lycee.getText()+"',Mention_Bac='"+mention.getText()+"',Moyenne_Bac='"+moyenne.getText()+"',Annee_Obtention_Bac='"+obtention.getText()+"',Boursiere='"+boursiere+"',Nationalite='"+nationalite.getText()+"' where N_Inscription='"+num_insc.getText()+"' ";
                   
                PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);
                 pst.setString(1,url.getText());
                pst.executeUpdate();
                 //  connectiontoaccess.Ajouter_Et(cne_p.getText(),cin.getText(), nom.getText(),prenom.getText(),sexe,filiere.getSelectedItem().toString(),
                        // option.getSelectedItem().toString(),"Semestre1", tel1.getText(), url.getText());
                JOptionPane.showMessageDialog(null,"modification effectué");
            }else{
                JOptionPane.showMessageDialog(null,"ce numéro d'inscription n'existe pas !");
            }
        }

        } catch (HeadlessException | SQLException ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton20MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseEntered
      num_insc.setVisible(true);
        insc.setVisible(true);      
    }//GEN-LAST:event_jButton20MouseEntered

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        insc.setVisible(false);
        num_insc.setVisible(false);
        //Afficher_Info_Et();
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(inscription3panel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton22MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton22MouseEntered
        insc.setVisible(false);
        num_insc.setVisible(false);
    }//GEN-LAST:event_jButton22MouseEntered

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        insc.setVisible(false);
        num_insc.setVisible(false);
        Ajouter_Etudiant();
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton19MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton19MouseEntered
        insc.setVisible(false);
        num_insc.setVisible(false);
    }//GEN-LAST:event_jButton19MouseEntered

    private void ArActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ArActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ArActionPerformed

    private void num_inscMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_num_inscMouseExited
        
       
    }//GEN-LAST:event_num_inscMouseExited

    private void num_inscMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_num_inscMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_num_inscMouseEntered

    private void moyenneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_moyenneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_moyenneActionPerformed

    private void duree_abcMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_duree_abcMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_duree_abcMouseEntered

    private void duree_abcMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_duree_abcMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_duree_abcMouseExited

    private void type_abcMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_type_abcMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_type_abcMouseEntered

    private void type_abcMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_type_abcMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_type_abcMouseExited

    private void jButton73jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton73jButton4ActionPerformed
           // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(tablenote);
        mainPanel.repaint();
        mainPanel.revalidate();
        Afficher_Et();
    }//GEN-LAST:event_jButton73jButton4ActionPerformed

    private void niveau_retMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_retMouseExited
        niveau_ret.addItem("Choisir un niveau");
    }//GEN-LAST:event_niveau_retMouseExited

    private void niveau_retMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_retMouseEntered
      niveau_ret.removeAllItems();
      niveau_ret.addItem("Semestre1");
      niveau_ret.addItem("Semestre2");
      niveau_ret.addItem("Semestre3");
      niveau_ret.addItem("Semestre4");
      niveau_ret.addItem("Semestre5");
      niveau_ret.addItem("Semestre6");
    }//GEN-LAST:event_niveau_retMouseEntered

    private void option_retMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_retMouseExited
        option_ret.addItem("Choisir une option");
    }//GEN-LAST:event_option_retMouseExited

    private void option_retMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_retMouseEntered
        String s1 = filiere_ret.getSelectedItem().toString();
        //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************
        String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";

        try{
            option_ret.removeAllItems();
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();

            while(rs.next()){
                //Format du date

                String nomoption=rs.getString("Nom_Option");
                option_ret.addItem(nomoption);
            }

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_option_retMouseEntered

    private void module_retMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_retMouseExited
        module_ret.addItem("Choisir un niveau");
    }//GEN-LAST:event_module_retMouseExited

    private void module_retMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_retMouseEntered
        String s1= option_ret.getSelectedItem().toString();
        String s2= niveau_ret.getSelectedItem().toString();
        String requet="Select * From Module_E where Option_Mod='"+s1+"' AND "
        + "Niveau_Mod='"+s2+"'";

        try{
            module_ret.removeAllItems();

            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();

            while(rs.next()){
                //Extraire le nom du module
                String nommod=rs.getString("Intitule_Module");
                module_ret.addItem(nommod);
            }

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_module_retMouseEntered

    private void filiere_retMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_retMouseExited
        filiere_ret.addItem("Choisir une filière");
    }//GEN-LAST:event_filiere_retMouseExited

    private void filiere_retMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_retMouseEntered
        filiere_ret.removeAllItems();
        remplirecomboboxFiliere();
    }//GEN-LAST:event_filiere_retMouseEntered

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
           // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(tablenote);
        mainPanel.repaint();
        mainPanel.revalidate();
        //Afficher_Abcense();
      
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed

        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(Liste_Abc1);
        mainPanel.repaint();
        mainPanel.revalidate();
      try{
        Afficher_Abcense();
      Table_Abcense1.getColumnModel().getColumn(0).setCellRenderer(new CustomRenderer());
      }catch(Exception e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
   
    }//GEN-LAST:event_jButton13ActionPerformed

    private void module_retActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_module_retActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_module_retActionPerformed

    private void type_abcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_type_abcActionPerformed
        if(type_abc.getSelectedItem().toString().equals("Absence")){
              just_abc.removeAllItems();
              just_abc.addItem("Absence justifiée");
               just_abc.addItem("Absence non justifiée");
        }else{
             just_abc.removeAllItems();
              just_abc.addItem("Retard justifié");
               just_abc.addItem("Retard non justifié");
        }
    }//GEN-LAST:event_type_abcActionPerformed

    private void jButton65jButton61ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton65jButton61ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(retardpanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton65jButton61ActionPerformed

    private void jButton66jButton62ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton66jButton62ActionPerformed
         try {
    boolean complete = Table_Abcense1.print();
    if (complete) {
       JOptionPane.showMessageDialog(null,"L'imperssion est éffectuée avec succés");
    } else {
        JOptionPane.showMessageDialog(null,"L'imperssion n'est pas éffectuées !");
    }
} catch (PrinterException pe) {
    JOptionPane.showMessageDialog(null,pe.getMessage());
}
    }//GEN-LAST:event_jButton66jButton62ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
       // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(moduleretard);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(abcensepanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton33ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(Liste_Retard);
        mainPanel.repaint();
        mainPanel.revalidate();
        Afficher_Retard();
    }//GEN-LAST:event_jButton30ActionPerformed

    private void mo1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mo1MouseEntered
        String s1= op1.getSelectedItem().toString();
        String s2= ni1.getSelectedItem().toString();
        String requet="Select * From Module_E where Option_Mod='"+s1+"' AND "
        + "Niveau_Mod='"+s2+"'";

        try{
            mo1.removeAllItems();

            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();

            while(rs.next()){
                //Extraire le nom du module
                String nommod=rs.getString("Intitule_Module");
                mo1.addItem(nommod);
            }

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_mo1MouseEntered

    private void op1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_op1MouseEntered
        String s1 = fi1.getSelectedItem().toString();
        //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************
        String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";

        try{
            op1.removeAllItems();
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();

            while(rs.next()){
                //Format du date

                String nomoption=rs.getString("Nom_Option");
                op1.addItem(nomoption);
            }

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_op1MouseEntered

    private void ni1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ni1MouseEntered
     ni1.removeAllItems();
        ni1.addItem("Semestre1");
         ni1.addItem("Semestre2");
          ni1.addItem("Semestre3");
           ni1.addItem("Semestre4");
            ni1.addItem("Semestre5");
             ni1.addItem("Semestre6");
    }//GEN-LAST:event_ni1MouseEntered

    private void fi1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fi1MouseEntered
        fi1.removeAllItems();
        remplirecomboboxFiliere();
    }//GEN-LAST:event_fi1MouseEntered

    private void jButton55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton55ActionPerformed
   
       Calculer_Session_Normale();
      Suite_Calcule();
      JOptionPane.showMessageDialog(null,"Calculation effectuées avec succés");
        
    }//GEN-LAST:event_jButton55ActionPerformed

    private void module_etud1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_etud1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_module_etud1MouseExited

    private void module_etud1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_etud1MouseEntered
        String s1= option_etud1.getSelectedItem().toString();
        String s2= niveau_etud1.getSelectedItem().toString();
        String requet="Select * From Module_E where Option_Mod='"+s1+"' AND "
        + "Niveau_Mod='"+s2+"'";

        try{
            module_etud1.removeAllItems();

            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();

            while(rs.next()){
                //Extraire le nom du module
                String nommod=rs.getString("Intitule_Module");
                module_etud1.addItem(nommod);
            }

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_module_etud1MouseEntered

    private void module_etud1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_etud1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_module_etud1MouseClicked

    private void niveau_etud1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_etud1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_niveau_etud1MouseExited

    private void niveau_etud1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_etud1MouseEntered
        String s2 = option_etud1.getSelectedItem().toString();
        niveau_etud1.removeAllItems();

        //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************
        String r="SELECT * From Niveau WHERE Option_Niveau='"+s2+"'";

        try{

            PreparedStatement ps=connection.ConnecteDb().prepareStatement(r);
            rs=ps.executeQuery();

            while(rs.next()){
                //Format du date

                String nomniveau=rs.getString("Intitule_Niveau");
                niveau_etud1.addItem(nomniveau);

            }

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_niveau_etud1MouseEntered

    private void niveau_etud1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_etud1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_niveau_etud1MouseClicked

    private void option_etud1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_etud1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_option_etud1MouseExited

    private void option_etud1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_etud1MouseEntered
        String s1 = filiere_etud1.getSelectedItem().toString();
        //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************
        String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";
        option_etud1.removeAllItems();
        try{

            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();

            while(rs.next()){

                String nomoption=rs.getString("Nom_Option");
                option_etud1.addItem(nomoption);
            }

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_option_etud1MouseEntered

    private void option_etud1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_etud1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_option_etud1MouseClicked

    private void filiere_etud1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_etud1MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_filiere_etud1MouseExited

    private void filiere_etud1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_etud1MouseEntered
        filiere_etud1.removeAllItems();
        remplirecomboboxFiliere();
    }//GEN-LAST:event_filiere_etud1MouseEntered

    private void filiere_etud1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_etud1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_filiere_etud1MouseClicked

    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(choix_module);
        mainPanel.repaint();
        mainPanel.revalidate();
        Afficher_Etud_Ratt();
    }//GEN-LAST:event_jButton36ActionPerformed

    private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed
       Ajouter_Abc();
    }//GEN-LAST:event_jButton37ActionPerformed

    private void jButton49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton49ActionPerformed
        Supprimer_Abc();
    }//GEN-LAST:event_jButton49ActionPerformed

    private void jButton51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton51ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(retardpanel);
        mainPanel.repaint();
        mainPanel.revalidate();
        
    }//GEN-LAST:event_jButton51ActionPerformed

    private void Table_Abc1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Table_Abc1MouseClicked
 try{
              
            //Séléctionner une ligne de la table
            i=Table_Abc1.getSelectedRow();

            String fi=filiere_etud1.getSelectedItem().toString();
            String op=option_etud1.getSelectedItem().toString();
            String niv=niveau_etud1.getSelectedItem().toString();
            String mod=module_etud1.getSelectedItem().toString();
            String num=Table_Abc1.getValueAt(i,0).toString();
            Note_Examen c = new  Note_Examen(this,num,fi,op,niv,mod);
           // Choix c=new Choix();
            c.setVisible(true);
           // Afficher_Etud_Ratt();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Erreur Séléctionné !");
        }      
    }//GEN-LAST:event_Table_Abc1MouseClicked

    private void jButton56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton56ActionPerformed
  // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(jPanel11);
        mainPanel.repaint();
        mainPanel.revalidate();
        String fi=filiere_etud.getSelectedItem().toString();
        String op=option_etud.getSelectedItem().toString();
        String ni=niveau_etud.getSelectedItem().toString();
        Afficher_Etud(fi,op,ni);      
        
    }//GEN-LAST:event_jButton56ActionPerformed

    private void btnniveauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveauActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(niveaupanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnniveauActionPerformed

    private void btnniveauMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveauMouseExited
        btnniveau.setBackground(new Color (204,204,204));
    }//GEN-LAST:event_btnniveauMouseExited

    private void btnniveauMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveauMouseEntered
        btnniveau.setBackground(new Color (0,0,204));
    }//GEN-LAST:event_btnniveauMouseEntered

    private void nom_filiereMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nom_filiereMouseExited
       nom_filiere.addItem("Choisir une filière");
    }//GEN-LAST:event_nom_filiereMouseExited

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        try {
    boolean complete = Table_Retard1.print();
    if (complete) {
       JOptionPane.showMessageDialog(null,"L'imperssion est éffectuée avec succés");
    } else {
        JOptionPane.showMessageDialog(null,"L'imperssion n'est pas éffectuées !");
    }
} catch (PrinterException pe) {
    JOptionPane.showMessageDialog(null,pe.getMessage());
}
    }//GEN-LAST:event_jButton4ActionPerformed

    private void fi1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fi1MouseExited
       fi1.addItem("Choisir une filière");
    }//GEN-LAST:event_fi1MouseExited

    private void op1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_op1MouseExited
       op1.addItem("Choisir une option");
    }//GEN-LAST:event_op1MouseExited

    private void ni1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ni1MouseExited
//      ni1.addItem("Choisir un niveau");
    }//GEN-LAST:event_ni1MouseExited

    private void mo1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mo1MouseExited
      mo1.addItem("Choisir un module");
    }//GEN-LAST:event_mo1MouseExited

    private void filiere_etud2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_etud2MouseClicked

    }//GEN-LAST:event_filiere_etud2MouseClicked

    private void filiere_etud2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_etud2MouseEntered
        filiere_etud2.removeAllItems();
        remplirecomboboxFiliere();
    }//GEN-LAST:event_filiere_etud2MouseEntered

    private void filiere_etud2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_etud2MouseExited
        filiere_etud2.addItem("Choisir une filière");
    }//GEN-LAST:event_filiere_etud2MouseExited

    private void option_etud2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_etud2MouseClicked

    }//GEN-LAST:event_option_etud2MouseClicked

    private void option_etud2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_etud2MouseEntered
        String s1 = filiere_etud2.getSelectedItem().toString();
        //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************
        String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";
        option_etud2.removeAllItems();
        try{

            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();

            while(rs.next()){

                String nomoption=rs.getString("Nom_Option");
                option_etud2.addItem(nomoption);
            }

        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }//GEN-LAST:event_option_etud2MouseEntered

    private void option_etud2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_etud2MouseExited
        option_etud.addItem("Choisir une option");
    }//GEN-LAST:event_option_etud2MouseExited

    private void niveau_etud2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_etud2MouseClicked

    }//GEN-LAST:event_niveau_etud2MouseClicked

    private void niveau_etud2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_etud2MouseEntered
         niveau_etud2.removeAllItems();
        niveau_etud2.addItem("Semestre1");
        niveau_etud2.addItem("Semestre2");
        niveau_etud2.addItem("Semestre3");
        niveau_etud2.addItem("Semestre4");
        niveau_etud2.addItem("Semestre5");
        niveau_etud2.addItem("Semestre6");
    }//GEN-LAST:event_niveau_etud2MouseEntered

    private void niveau_etud2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_niveau_etud2MouseExited
//        niveau_etud2.addItem("Choisir un niveau");
    }//GEN-LAST:event_niveau_etud2MouseExited

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        Afficher_Etud_Ruissis();
    }//GEN-LAST:event_jButton14ActionPerformed

    private void filiere_coorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filiere_coorMouseExited
       filiere_coor.addItem("Choisir une filiére");
    }//GEN-LAST:event_filiere_coorMouseExited

    private void option_coorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_option_coorMouseExited
        option_coor.addItem("Choisir une option");
    }//GEN-LAST:event_option_coorMouseExited

    private void module_coorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_module_coorMouseExited
       module_coor.addItem("Choisir un module");
    }//GEN-LAST:event_module_coorMouseExited

    private void btnresultat1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat1MouseEntered
       btnresultat1.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnresultat1MouseEntered

    private void btnresultat1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat1MouseExited
         btnresultat1.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnresultat1MouseExited

    private void btnresultat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresultat1ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(notepanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnresultat1ActionPerformed

    private void btnresultat2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat2MouseEntered
       btnresultat2.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnresultat2MouseEntered

    private void btnresultat2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat2MouseExited
        btnresultat2.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnresultat2MouseExited

    private void btnresultat2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresultat2ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(sessionrattrapage);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_btnresultat2ActionPerformed

    private void btnresultat3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat3MouseEntered
        btnresultat3.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnresultat3MouseEntered

    private void btnresultat3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat3MouseExited
         btnresultat3.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnresultat3MouseExited

    private void btnresultat3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresultat3ActionPerformed
       Choix c=new Choix();
       c.setVisible(true);
    
    }//GEN-LAST:event_btnresultat3ActionPerformed

    private void jButton58ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton58ActionPerformed
        Sauvegarder();        
    }//GEN-LAST:event_jButton58ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
      Parametre p=new Parametre();
      p.setVisible(true);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(abcensepanel);
        mainPanel.repaint();
        mainPanel.revalidate();      
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(notepanel);
        mainPanel.repaint();
        mainPanel.revalidate();      
    }//GEN-LAST:event_jButton3ActionPerformed

    private void just_abcMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_just_abcMouseEntered
        
    }//GEN-LAST:event_just_abcMouseEntered

    private void Table_Abcense1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Table_Abcense1MouseClicked
        i=Table_Abcense1.getSelectedRow();
        DefaultTableCellRenderer nb=new DefaultTableCellRenderer ();
                   Object value= Table_Abcense1.getModel().getValueAt(i,i);
                   Component  cell =nb.getTableCellRendererComponent(Table_Abcense1, value, false,true,i, i);
                             
				cell.setBackground(Color.RED);
                  
    }//GEN-LAST:event_Table_Abcense1MouseClicked

    private void Table_AbcMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Table_AbcMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_Table_AbcMouseClicked

    private void jButton52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton52ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(moduleretard);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton52ActionPerformed

    private void jButton53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton53ActionPerformed
      try {
    boolean complete = table_compethence1.print();
    if (complete) {
       JOptionPane.showMessageDialog(null,"L'imperssion est éffectuée avec succés");
    } else {
        JOptionPane.showMessageDialog(null,"L'imperssion n'est pas éffectuées !");
    }
} catch (PrinterException pe) {
    JOptionPane.showMessageDialog(null,pe.getMessage());
}
    }//GEN-LAST:event_jButton53ActionPerformed

    private void btnniveau27MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau27MouseEntered
        btnniveau27.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau27MouseEntered

    private void btnniveau27MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau27MouseExited
       btnniveau27.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau27MouseExited

    private void btnniveau27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau27ActionPerformed
           // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_per2);
        mainPanel.repaint();
        mainPanel.revalidate();  
    }//GEN-LAST:event_btnniveau27ActionPerformed

    private void btnniveau28MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau28MouseEntered
       btnniveau28.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau28MouseEntered

    private void btnniveau28MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau28MouseExited
      btnniveau28.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau28MouseExited

    private void btnniveau28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau28ActionPerformed
           // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(Afficher_Etud);
        mainPanel.repaint();
        mainPanel.revalidate();  
    }//GEN-LAST:event_btnniveau28ActionPerformed

    private void btnniveau29MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau29MouseEntered
       btnniveau29.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau29MouseEntered

    private void btnniveau29MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau29MouseExited
        btnniveau29.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau29MouseExited

    private void btnniveau29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau29ActionPerformed
           // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(scolaire2);
        mainPanel.repaint();
        mainPanel.revalidate();  
    }//GEN-LAST:event_btnniveau29ActionPerformed

    private void btnniveau30MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau30MouseEntered
       btnniveau30.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau30MouseEntered

    private void btnniveau30MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau30MouseExited
        btnniveau30.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau30MouseExited

    private void btnniveau30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau30ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_scolaire);
        mainPanel.repaint();
        mainPanel.revalidate();  
    }//GEN-LAST:event_btnniveau30ActionPerformed

    private void btnniveau31MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau31MouseEntered
       btnniveau31.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnniveau31MouseEntered

    private void btnniveau31MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnniveau31MouseExited
        btnniveau28.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnniveau31MouseExited

    private void btnniveau31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnniveau31ActionPerformed
           // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(compethence);
        mainPanel.repaint();
        mainPanel.revalidate();  
    }//GEN-LAST:event_btnniveau31ActionPerformed

    private void btnresultat5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat5MouseEntered
          btnresultat5.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnresultat5MouseEntered

    private void btnresultat5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat5MouseExited
          btnresultat5.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnresultat5MouseExited

    private void btnresultat5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresultat5ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_scolaire);
        mainPanel.repaint();
        mainPanel.revalidate();  
    }//GEN-LAST:event_btnresultat5ActionPerformed

    private void btnresultat6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat6MouseEntered
       btnresultat6.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnresultat6MouseEntered

    private void btnresultat6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat6MouseExited
         btnresultat6.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnresultat6MouseExited

    private void btnresultat6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresultat6ActionPerformed
           // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(scolaire2);
        mainPanel.repaint();
        mainPanel.revalidate();  
    }//GEN-LAST:event_btnresultat6ActionPerformed

    private void btnresultat7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat7MouseEntered
        btnresultat7.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnresultat7MouseEntered

    private void btnresultat7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat7MouseExited
          btnresultat7.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnresultat7MouseExited

    private void btnresultat7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresultat7ActionPerformed
          // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(info_per2);
        mainPanel.repaint();
        mainPanel.revalidate();  
    }//GEN-LAST:event_btnresultat7ActionPerformed

    private void btnresultat8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat8MouseEntered
         btnresultat8.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnresultat8MouseEntered

    private void btnresultat8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat8MouseExited
        btnresultat8.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnresultat8MouseExited

    private void btnresultat8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresultat8ActionPerformed
        // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(scolaire2);
        mainPanel.repaint();
        mainPanel.revalidate();  
    }//GEN-LAST:event_btnresultat8ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          try {
    boolean complete = Table_Module1.print();
    if (complete) {
       JOptionPane.showMessageDialog(null,"L'imperssion est éffectuée avec succés");
    } else {
        JOptionPane.showMessageDialog(null,"L'imperssion n'est pas éffectuées !");
    }
} catch (PrinterException pe) {
    JOptionPane.showMessageDialog(null,pe.getMessage());
}
    }//GEN-LAST:event_jButton2ActionPerformed

    private void cneeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cneeMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_cneeMouseEntered

    private void btnresultat9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat9MouseEntered
       btnresultat9.setBackground(new Color(0,0,204));
    }//GEN-LAST:event_btnresultat9MouseEntered

    private void btnresultat9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnresultat9MouseExited
      btnresultat9.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_btnresultat9MouseExited

    private void btnresultat9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnresultat9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnresultat9ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
     if(num_insc.getText().length()!=0){
            Afficher_Info_Et();             
     }
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton20MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton20MouseClicked

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
      Relver_Note_Lauriat c=new Relver_Note_Lauriat(this,text_num.getText(),filiere_info.getSelectedItem().toString(),option_info.getSelectedItem().toString(),niveau_info.getSelectedItem().toString());
       c.setVisible(true);
    }//GEN-LAST:event_jButton35ActionPerformed

    private void jButton38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton38ActionPerformed
      Actualiser_Et();
    }//GEN-LAST:event_jButton38ActionPerformed

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
         // remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();

        // add panel
        mainPanel.add(notepanel);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton34ActionPerformed

    private void moyenneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_moyenneKeyPressed
                char c = evt.getKeyChar();
        if(Character.isLetter(c)){
            //Can't able to enter in TextField if enter char is not number
           moyenne.setEditable(false);
            //Set error message
           moyenne.setBackground(red);
            
        }else{
            moyenne.setBackground(white);
            moyenne.setEditable(true);}       
    }//GEN-LAST:event_moyenneKeyPressed

    private void filiere_coorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filiere_coorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_filiere_coorActionPerformed

    private void module_coorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_module_coorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_module_coorActionPerformed
/*
    /**
     * @param args the command line arguments
     */
    /* public static void main(String args[]) throws InterruptedException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
      /*  try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger( Menue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger( Menue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger( Menue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger( Menue.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }*/
        //</editor-fold>
       /*  Menue sc = new Menue();
        /*Create and display the form */
    /*    java.awt.EventQueue.invokeLater(() -> {
            sc.setVisible(true);
            
        });
     }
*/
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Afficher_Etud;
    private javax.swing.JPanel Afficher_Etud4;
    private javax.swing.JPanel Afficher_Etud5;
    private javax.swing.JPanel Afficher_Etud6;
    private javax.swing.JPanel Afficher_Etud7;
    private static javax.swing.JCheckBox An;
    private static javax.swing.JCheckBox Ar;
    private static javax.swing.JCheckBox Es;
    private static javax.swing.JCheckBox Fr;
    private javax.swing.JPanel Liste_Abc1;
    private javax.swing.JPanel Liste_Abc2;
    private javax.swing.JPanel Liste_Retard;
    private javax.swing.JRadioButton Non;
    private javax.swing.JRadioButton Oui;
    private javax.swing.JPanel Semestre;
    private javax.swing.JButton Supprimer;
    private javax.swing.JButton Supprimer2;
    private static javax.swing.JCheckBox Ta;
    private static javax.swing.JTable Table_Abc;
    private javax.swing.JTable Table_Abc1;
    private static javax.swing.JTable Table_Abcense1;
    private static javax.swing.JTable Table_Element;
    private javax.swing.JTable Table_Et1;
    private javax.swing.JTable Table_Filiere;
    private static javax.swing.JTable Table_Module1;
    public static javax.swing.JTable Table_Option;
    private static javax.swing.JTable Table_Retard1;
    private javax.swing.JPanel abcensepanel;
    private javax.swing.JPanel abcensepanel2;
    static javax.swing.JTextField actuel_a;
    static javax.swing.JTextField adr1;
    static javax.swing.JTextField adr1_a;
    static javax.swing.JTextField adr2;
    static javax.swing.JTextField adr2_a;
    private static javax.swing.JTextField adr_actuel;
    private static javax.swing.JTextArea anterieure;
    private static javax.swing.JTextArea attelier;
    private javax.swing.JPanel bodyPanel1;
    private static javax.swing.JTextField bou_a;
    private javax.swing.JButton btn_inter;
    private javax.swing.JButton btnabcense;
    private javax.swing.JButton btncoor;
    private javax.swing.JButton btnfiliere;
    private javax.swing.JButton btnhome;
    private javax.swing.JButton btninscription;
    private javax.swing.JButton btnmodule;
    private javax.swing.JButton btnniveau;
    private javax.swing.JButton btnniveau1;
    private javax.swing.JButton btnniveau13;
    private javax.swing.JButton btnniveau14;
    private javax.swing.JButton btnniveau15;
    private javax.swing.JButton btnniveau16;
    private javax.swing.JButton btnniveau18;
    private javax.swing.JButton btnniveau19;
    private javax.swing.JButton btnniveau2;
    private javax.swing.JButton btnniveau20;
    private javax.swing.JButton btnniveau21;
    private javax.swing.JButton btnniveau22;
    private javax.swing.JButton btnniveau23;
    private javax.swing.JButton btnniveau24;
    private javax.swing.JButton btnniveau25;
    private javax.swing.JButton btnniveau26;
    private javax.swing.JButton btnniveau27;
    private javax.swing.JButton btnniveau28;
    private javax.swing.JButton btnniveau29;
    private javax.swing.JButton btnniveau3;
    private javax.swing.JButton btnniveau30;
    private javax.swing.JButton btnniveau31;
    private javax.swing.JButton btnniveau4;
    private javax.swing.JButton btnniveau5;
    private javax.swing.JButton btnniveau6;
    private javax.swing.JButton btnniveau7;
    private javax.swing.JButton btnnote;
    private javax.swing.JButton btnresultat;
    private javax.swing.JButton btnresultat1;
    private javax.swing.JButton btnresultat2;
    private javax.swing.JButton btnresultat3;
    private javax.swing.JButton btnresultat5;
    private javax.swing.JButton btnresultat6;
    private javax.swing.JButton btnresultat7;
    private javax.swing.JButton btnresultat8;
    private javax.swing.JButton btnresultat9;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JPanel choix_module;
    static javax.swing.JTextField cin;
    static javax.swing.JTextField cin_a;
    public static javax.swing.JTextField cin_coor;
    static javax.swing.JTextField cne_a;
    static javax.swing.JTextField cne_p;
    private javax.swing.JLabel cnee;
    private static javax.swing.JTextField code;
    private static javax.swing.JComboBox<String> comborech;
    private javax.swing.JPanel compethence;
    private javax.swing.JPanel coordinateurpanel;
    private static com.toedter.calendar.JDateChooser date_abc;
    private static javax.swing.JTextArea diplome;
    private static javax.swing.JComboBox<String> duree_abc;
    private static javax.swing.JComboBox<String> elem_abc;
    private static javax.swing.JTextField email1;
    private static javax.swing.JTextField email1_a;
    private static javax.swing.JTextField email2;
    private static javax.swing.JTextField email2_a;
    private static javax.swing.JTextField email_coor;
    private javax.swing.JPanel etudiant;
    private javax.swing.JLabel f;
    private javax.swing.JRadioButton femme;
    public static javax.swing.JComboBox<String> fi1;
    private static javax.swing.JComboBox<String> filiere;
    private static javax.swing.JTextField filiere_a;
    private static javax.swing.JComboBox<String> filiere_abc;
    private static javax.swing.JComboBox<String> filiere_coor;
    private static javax.swing.JComboBox<String> filiere_etud;
    private static javax.swing.JComboBox<String> filiere_etud1;
    private static javax.swing.JComboBox<String> filiere_etud2;
    private static javax.swing.JComboBox<String> filiere_info;
    private static javax.swing.JComboBox<String> filiere_mod;
    private static javax.swing.JComboBox<String> filiere_ret;
    public static javax.swing.JComboBox<String> filiere_s;
    private javax.swing.JPanel filierepanel;
    private static javax.swing.JComboBox<String> fonction_coor;
    private static javax.swing.JTextField grade_coor;
    private javax.swing.JPanel homePanel;
    private javax.swing.JRadioButton homme;
    private static javax.swing.JTextField horaire_elem;
    private static javax.swing.JComboBox<String> horaire_mod;
    private javax.swing.JPanel info_per2;
    private javax.swing.JPanel info_scolaire;
    private javax.swing.JLabel insc;
    private static javax.swing.JTextField insc_a;
    private static com.toedter.calendar.JDateChooser inscription;
    private javax.swing.JPanel inscription2panel;
    private javax.swing.JPanel inscription3panel;
    private javax.swing.JPanel inscription4panel;
    private javax.swing.JPanel inscriptionpanel;
    private static javax.swing.JComboBox<String> inter_elem;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton42;
    private javax.swing.JButton jButton43;
    private javax.swing.JButton jButton44;
    private javax.swing.JButton jButton45;
    private javax.swing.JButton jButton46;
    private javax.swing.JButton jButton47;
    private javax.swing.JButton jButton48;
    private javax.swing.JButton jButton49;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton50;
    private javax.swing.JButton jButton51;
    private javax.swing.JButton jButton52;
    private javax.swing.JButton jButton53;
    private javax.swing.JButton jButton54;
    private javax.swing.JButton jButton55;
    private javax.swing.JButton jButton56;
    private javax.swing.JButton jButton58;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton65;
    private javax.swing.JButton jButton66;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton73;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    public static javax.swing.JCheckBox jCheckBox1;
    public static javax.swing.JCheckBox jCheckBox2;
    public static javax.swing.JCheckBox jCheckBox3;
    public static javax.swing.JCheckBox jCheckBox4;
    private static javax.swing.JComboBox<String> jComboBox1;
    private static javax.swing.JComboBox<String> jComboBox2;
    private static javax.swing.JComboBox<String> jComboBox3;
    private static javax.swing.JComboBox<String> jComboBox4;
    private static javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JLabel jLabel132;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel134;
    private javax.swing.JLabel jLabel136;
    private javax.swing.JLabel jLabel137;
    private javax.swing.JLabel jLabel138;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel140;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JLabel jLabel145;
    private javax.swing.JLabel jLabel147;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel158;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JLabel jLabel165;
    private javax.swing.JLabel jLabel166;
    private javax.swing.JLabel jLabel167;
    private javax.swing.JLabel jLabel168;
    private javax.swing.JLabel jLabel169;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel170;
    private javax.swing.JLabel jLabel171;
    private javax.swing.JLabel jLabel172;
    private javax.swing.JLabel jLabel173;
    private javax.swing.JLabel jLabel174;
    private javax.swing.JLabel jLabel175;
    private javax.swing.JLabel jLabel176;
    private javax.swing.JLabel jLabel177;
    private javax.swing.JLabel jLabel178;
    private javax.swing.JLabel jLabel179;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel180;
    private javax.swing.JLabel jLabel181;
    private javax.swing.JLabel jLabel182;
    private javax.swing.JLabel jLabel186;
    private javax.swing.JLabel jLabel187;
    private javax.swing.JLabel jLabel191;
    private javax.swing.JLabel jLabel192;
    private javax.swing.JLabel jLabel194;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane24;
    private javax.swing.JScrollPane jScrollPane25;
    private javax.swing.JScrollPane jScrollPane27;
    private javax.swing.JScrollPane jScrollPane28;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private com.toedter.calendar.JYearChooser jYearChooser1;
    private static javax.swing.JComboBox<String> just_abc;
    private static javax.swing.JLabel label;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label_enf;
    private javax.swing.JLabel label_number;
    private static javax.swing.JLabel langue;
    static javax.swing.JTextField lieux;
    static javax.swing.JTextField lieux_a;
    private static javax.swing.JLabel logiciel;
    private static javax.swing.JTextField lycee;
    private static javax.swing.JTextField lycee_a;
    private javax.swing.JLabel m;
    private javax.swing.JPanel mainPanel;
    private static javax.swing.JTextField mention;
    private static javax.swing.JTextField mention_a;
    private javax.swing.JPanel menuPanel1;
    public static javax.swing.JComboBox<String> mo1;
    private static javax.swing.JComboBox<String> mod_elem;
    private static javax.swing.JComboBox<String> module_abc;
    private static javax.swing.JComboBox<String> module_coor;
    private static javax.swing.JComboBox<String> module_etud;
    private static javax.swing.JComboBox<String> module_etud1;
    private static javax.swing.JComboBox<String> module_ret;
    private javax.swing.JPanel module_retard1;
    private javax.swing.JPanel modulepanel;
    private javax.swing.JPanel modulepanel2;
    private javax.swing.JPanel modulepanel4;
    private javax.swing.JPanel moduleretard;
    private static javax.swing.JTextField moyenne;
    private static javax.swing.JTextField moyenne_a;
    static com.toedter.calendar.JDateChooser naissance;
    static javax.swing.JTextField naissance_a;
    private static javax.swing.JTextField nationalite;
    static javax.swing.JTextField nationalite_a;
    private static javax.swing.JTextField nbr_abc_a;
    private static javax.swing.JTextField nbr_elem;
    private static javax.swing.JTextField nbr_enfant;
    private static javax.swing.JTextField nbr_enfant_a;
    public static javax.swing.JComboBox<String> ni1;
    private static javax.swing.JTextField niveau_a;
    private static javax.swing.JComboBox<String> niveau_abc;
    private static javax.swing.JComboBox<String> niveau_etud;
    private static javax.swing.JComboBox<String> niveau_etud1;
    private static javax.swing.JComboBox<String> niveau_etud2;
    private static javax.swing.JComboBox<String> niveau_info;
    private static javax.swing.JComboBox<String> niveau_mod;
    private static javax.swing.JComboBox<String> niveau_ret;
    public static javax.swing.JComboBox<String> niveau_s;
    private javax.swing.JPanel niveaupanel;
    static javax.swing.JTextField nom;
    static javax.swing.JTextField nom_a;
    public static javax.swing.JTextField nom_coor;
    private static javax.swing.JTextField nom_elem;
    private static javax.swing.JComboBox<String> nom_filiere;
    private static javax.swing.JTextField nom_module;
    public static javax.swing.JTextField nom_option;
    public static javax.swing.JTextField nomfiliere;
    private javax.swing.JRadioButton non;
    private javax.swing.JPanel notepanel;
    private javax.swing.JPanel noter_abc;
    static javax.swing.JTextField num_a;
    private static javax.swing.JTextField num_compte;
    private static javax.swing.JTextField num_insc;
    private javax.swing.JLabel o;
    private static javax.swing.JTextField obtention;
    private static javax.swing.JTextField obtention_a;
    public static javax.swing.JComboBox<String> op1;
    private static javax.swing.JComboBox<String> option;
    private static javax.swing.JTextField option_a;
    private static javax.swing.JComboBox<String> option_abc;
    private static javax.swing.JComboBox<String> option_coor;
    private static javax.swing.JComboBox<String> option_etud;
    private static javax.swing.JComboBox<String> option_etud1;
    private static javax.swing.JComboBox<String> option_etud2;
    private static javax.swing.JComboBox<String> option_info;
    private static javax.swing.JComboBox<String> option_mod;
    private static javax.swing.JComboBox<String> option_ret;
    public static javax.swing.JComboBox<String> option_s;
    private javax.swing.JRadioButton oui;
    private javax.swing.JPanel pa1;
    private javax.swing.JPanel pa2;
    private javax.swing.JPanel pa3;
    private javax.swing.JPanel pa4;
    private javax.swing.JPanel pa5;
    private javax.swing.JButton parcourire;
    public static javax.swing.JLabel photo_a;
    static javax.swing.JTextField prenom;
    static javax.swing.JTextField prenom_a;
    private static javax.swing.JTextField prenom_coor;
    private static javax.swing.JTextField res_a;
    private javax.swing.JLabel res_label;
    private javax.swing.JPanel retardpanel;
    private javax.swing.JPanel scolaire2;
    private javax.swing.JPanel sessionrattrapage;
    private static javax.swing.JTextField sexe_a;
    private static javax.swing.JComboBox<String> situation;
    private static javax.swing.JTextField situation_a;
    private static javax.swing.JTable table_compethence;
    private static javax.swing.JTable table_compethence1;
    public static javax.swing.JTable table_coor;
    private javax.swing.JPanel table_mod;
    private static javax.swing.JTable table_per1;
    private static javax.swing.JTable table_per2;
    private static javax.swing.JTable table_scolaire;
    private javax.swing.JPanel tablenote;
    static javax.swing.JTextField tel1;
    static javax.swing.JTextField tel1_a;
    private static javax.swing.JTextField tel1_coor;
    static javax.swing.JTextField tel2;
    static javax.swing.JTextField tel2_a;
    private static javax.swing.JTextField tel2_coor;
    private static javax.swing.JTextField text_num;
    private static javax.swing.JTextField textrech;
    private static javax.swing.JComboBox<String> type;
    private static javax.swing.JComboBox<String> type_abc;
    private static javax.swing.JComboBox<String> type_coor;
    private javax.swing.JLabel url;
    private static javax.swing.JTextField whatsup;
    private static javax.swing.JTextField whatsup_a;
    // End of variables declaration//GEN-END:variables
 //La métdode Ajouter_Etudiant() permet d'ajouter les informations d'un étudiant à la base de données
    
public void Ajouter_Etudiant(){
      try{
              
             connection.ConnecteDb();
             Calendar calendar = Calendar.getInstance(); 
             int ann=calendar.get( Calendar.YEAR );
             //==Calendar.JANUARY ) System.out.println(ann);
             String requet;
            String lg=Langues_Et();
            String lo=Logiciels_Et();
              String date=Get_Date();
               if(nom.getText().length()!=0){
                requet="insert into Etudiant values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                String o=option.getSelectedItem().toString();
                //S4 contient année d'inscription+code d'option+numéro du concoure
                String s4= Get_Date() + Code_Option(o)+Id_Inscription() ;
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
                 ps.setInt(1,Id_Inscription());
                 ps.setString(2,s4); 
                  ps.setString(3,cne_p.getText()); 
                 ps.setString(4,cin.getText());
                 ps.setString(5,nom.getText());   
                 ps.setString(6,prenom.getText());
                 ps.setString(7,((JTextField)inscription.getDateEditor().getUiComponent()).getText());
                 ps.setString(8,sexe); 
                 ps.setString(9,((JTextField)naissance.getDateEditor().getUiComponent()).getText());
                 ps.setString(10,nationalite.getText());
                 ps.setString(11,situation.getSelectedItem().toString()); 
                 ps.setString(12,mention.getText());
                 ps.setString(13,obtention.getText());
                 ps.setString(14,adr1.getText());
                 ps.setString(15,url.getText());
                 ps.setString(16,boursiere);
                 ps.setString(17,email1.getText());
                  ps.setString(18,tel1.getText());
                 ps.setString(19,adr_actuel.getText());
                 ps.setString(20,filiere.getSelectedItem().toString());
                 ps.setString(21,option.getSelectedItem().toString());
                 ps.setString(22,"Semestre1");
                 ps.setString(23,lieux.getText()); 
                 ps.setString(24,adr2.getText());
                 ps.setString(25,tel2.getText());
                 ps.setString(26,whatsup.getText()); 
                 ps.setString(27,email2.getText());
                 ps.setString(28,enfant); 
                 ps.setString(29,nbr_enfant.getText()); 
                 ps.setString(30,moyenne.getText()); 
                 ps.setString(31,lycee.getText()); 
                 ps.setString(32,lg); 
                 ps.setString(33,lo); 
                 ps.setString(34,anterieure.getText()); 
                 ps.setString(35,attelier.getText()); 
                 ps.setString(36,diplome.getText());
                 ps.setString(37,"");
                 ps.setInt(38,ann);
               
                 ps.executeUpdate();
                 String a="Semestre1";
                //   connectiontoaccess.Ajouter_Et(cne_p.getText(),cin.getText(), nom.getText(),prenom.getText(),sexe,filiere.getSelectedItem().toString(),
                       //  option.getSelectedItem().toString(),a, tel1.getText(), url.getText());
                 JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
                }
                 
                else{
                    JOptionPane.showMessageDialog(null,"Veuillez remplir le champ CNE");
                }
              
      }catch(HeadlessException | SQLException e){
          JOptionPane.showMessageDialog(null,e.getMessage());
      }
  }
    
//Méthode qui permet d'ajouter des filières à la base de données
    
    public static void Ajouter_Filiere(){
        
    
       try{
            
        String k = "INSERT INTO Filiere_E(Nom_Filiere) VALUES('"+nomfiliere.getText()+"')";
        if(nomfiliere.getText().length()!=0){
            
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(k);
        ps.executeUpdate();
         JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
         /*Boite_Dialog b = new Boite_Dialog();
         b.setVisible(true);*/
         
        }
        else{
             JOptionPane.showMessageDialog(null,"Veuillez d'abord taper un nom pour la filière ! ");
        }
       }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
    }
    
    //*****************************************************************************
    public static void Supprimer_Filiere(){
        try{
             if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                        
//La requête qui permet de supprimer les données de bla base de données ______________________________________________________                    
              String  query="Delete from Filiere_E where Nom_Filiere = '"+nomfiliere.getText()+"'";
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
              JOptionPane.showMessageDialog(null,"Les informations sont supprimées !");}
           
            
        }catch(HeadlessException | SQLException e){
             JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }
    
    //******************************
     public void Deplacer_Filiere(int i){
    try{
        nomfiliere.setText(model.getValueAt(i,1).toString());
       
       
    }catch(Exception e){
        
    }
}
     
     //Afficher les filières existent
     
     public static void Afficher_Filiere(){
         model.setRowCount(0);
         
         
          String his="Select * From Filiere_E";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données ******************************************
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(his);
                   while(rs.next()){
                   model.addRow(new Object[]{rs.getString("Id_Filiere"),rs.getString("Nom_Filiere")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
     }
         //**********************************************
         public static void Afficher_Option(){
             dt.setRowCount(0);
             String h = "SELECT * FROM Option_E";
              try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(h);
                   while(rs.next()){
                  dt.addRow(new Object[]{rs.getString("Id_Option"),rs.getString("Nom_Option"),rs.getString("Nom_Filiere")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
      
       
       Table_Option.setModel(dt);
         
     }
         //************************************
          public void Deplacer_Option(int i){
    try{
        
        
        nom_option.setText(dt.getValueAt(i,1).toString());
        nom_filiere.setSelectedItem(dt.getValueAt(i,2).toString());
 
    }catch(Exception e){
        
    }

          }
          
 //Vérifier si l'id de la filiere existent ou non
             
    
   //Ajouter une option
          
     public static void Ajouter_Option(){
         try{
             
         String o = "INSERT INTO Option_E(Nom_Option,Nom_Filiere,Code_Option) VALUES('"+nom_option.getText()+"','"+nom_filiere.getSelectedItem().toString()+"','"+code.getText()+"')";
     
      if(nom_option.getText().length()!=0 ){
            
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
         JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
      }
        else{
             JOptionPane.showMessageDialog(null,"Veuillez d'abord taper un nom pour l'option ! ");
        }
       }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
     }
     
     //************ Supprimùer une option
     
      public static void Supprimer_Option(){
        try{
             if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                        
//La requête qui permet de supprimer les données de bla base de données ______________________________________________________                    
              String  query="Delete from Option_E where Nom_Option = '"+nom_option.getText()+"'";
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
              JOptionPane.showMessageDialog(null,"Les informations sont supprimées !");}
           
            
        }catch(HeadlessException | SQLException e){
             JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }
    
     
     public void remplirecomboboxFiliere(){
      
 //La requête qui permet de sélectionner les noms des fetes islamiques et les dates *************      
         String requet="Select * From Filiere_E";
      
        try{
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
            
              String nom_Filiere=rs.getString("Nom_Filiere");
              filiere.addItem(nom_Filiere);
              nom_filiere.addItem(nom_Filiere);
              filiere_coor.addItem(nom_Filiere);
              filiere_etud.addItem(nom_Filiere);
               filiere_etud2.addItem(nom_Filiere);
               filiere_mod.addItem(nom_Filiere);
               filiere_abc.addItem(nom_Filiere);
               filiere_ret.addItem(nom_Filiere);
               fi1.addItem(nom_Filiere);
               filiere_info.addItem(nom_Filiere);
               filiere_s.addItem(nom_Filiere);
              filiere_etud1.addItem(nom_Filiere);
               
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
  } 

      public void remplirecomboboxOption(){
      String s1 = filiere_mod.getSelectedItem().toString();
 //La requête qui permet de sélectionner les noms des fetes islamiques et les dates ************************************************      
         String requet="Select * From Option_E WHERE Nom_Filiere='"+s1+"'";
      
        try{
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(requet);
            rs=ps.executeQuery();
           
            while(rs.next()){
               //Format du date 
              
            
              String nomoption=rs.getString("Nom_Option");
                option_mod.addItem(nomoption);
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
  }

  public static void Ajouter_Coordinateur(){
        try{
             
         String o = "INSERT INTO Cors_Enseignant(CIN,Nom,Prenom,Grade,Email,Telephone1,Telephone2,Type,Fonction,Filiere_C,Option_C"
                 + ",Module_C,Numero_Compte) VALUES('"+cin_coor.getText()+"','"+nom_coor.getText()+"','"+prenom_coor.getText()+"',"
                 + "'"+grade_coor.getText()+"','"+email_coor.getText()+"','"+tel1_coor.getText()+"','"+tel2_coor.getText()+"',"
                 + "'"+type.getSelectedItem().toString()+"','"+fonction_coor.getSelectedItem().toString()+"',"
                 + "'"+filiere_coor.getSelectedItem().toString()+"','"+option_coor.getSelectedItem().toString()+"',"
                 + "'"+module_coor.getSelectedItem().toString()+"','"+num_compte.getText()+"') ";
     
      if(cin_coor.getText().length()!=0 ){
            
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
         JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
      }
        else{
             JOptionPane.showMessageDialog(null,"Veuillez d'abord taper un nom pour l'option ! ");
        }
       }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            
       }
     }
  
  //Afficher les informations d'un coordinateur
  
  public static void Afficher_Coordinateur(){
          md.setRowCount(0);
          String q = "Select * From Cors_Enseignant";
          
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données ******************************************
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(q);
                  while(rs.next()){
                   md.addRow(new Object[]{rs.getString("CIN"),rs.getString("Nom"),rs.getString("Prenom"),rs.getString("Grade"),rs.getString("Telephone1"),
                       rs.getString("Telephone2"),rs.getString("Email"),rs.getString("Numero_Compte"),rs.getString("Type"),
                   rs.getString("Fonction"),rs.getString("Module_C"),rs.getString("Filiere_C"),rs.getString("Option_C")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
    
       
       table_coor.setModel(md);
  }
  
//Déplacer les unformations d'un coordinatyeur
  
   public void Deplacer_Coordinateur(int i){
    try{
        cin_coor.setText(md.getValueAt(i,1).toString());
         nom_coor.setText(md.getValueAt(i,2).toString());
        tel1_coor.setText(md.getValueAt(i,3).toString());
        email_coor.setText(md.getValueAt(i,4).toString());
        filiere_coor.setSelectedItem(md.getValueAt(i,5).toString());
        option_coor.setSelectedItem(md.getValueAt(i,6).toString());
        
       
       
    }catch(Exception e){
        
    }
   }

   //Supprimer un coordinateur
   
   public static void Supprimer_Coordinateur(){
         try{
             if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                        
//La requête qui permet de supprimer les données de bla base de données ______________________________________________________                    
              String  query="Delete from Cors_Enseignant where CIN = '"+cin_coor.getText()+"'";
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
              JOptionPane.showMessageDialog(null,"Les informations sont supprimées !");}
           
            
        }catch(HeadlessException | SQLException e){
             JOptionPane.showMessageDialog(null,e.getMessage());
        }
   }
   
   //Supprimer les informations d'un étudiant
   
    public void Supprimer_Etudiant(){
         try{
            
          
           
                    if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                          
                        if(N_Inscription()){
//La requête qui permet de supprimer les données de bla base de données ______________________________________________________                    
              String  query="Delete from Etudiant where N_Inscription = '"+num_insc.getText()+"'";
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
              JOptionPane.showMessageDialog(null,"Les informations de cet étudiant sont bien supprimées !");
                    }else{
                            JOptionPane.showMessageDialog(null,"ce numéro d'inscription n'existe pas ! !");
                        }
                    }
           
            }catch(HeadlessException | SQLException e){
                JOptionPane.showMessageDialog(null,e.getMessage());   
               
            }        
    }
    //Ajouter un niveau
   
    
   
    //Afficher un niveau
    
    
   
    
   //Afficher Les informations d'un module
    
    public static void Afficher_Module(){
       
        mdl.setRowCount(0);
      String his="Select * FROM Module_E ";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données ******************************************
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(his);
                   while(rs.next()){
                   mdl.addRow(new Object[]{rs.getString("Code_Module"),rs.getString("Intitule_Module"),rs.getString("Nombre_Element"), rs.getString("Volume_Horaire"),rs.getString("Type_Module"),rs.getString("Filiere_Mod"), rs.getString("Option_Mod"),rs.getString("Niveau_Mod")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
    
       
       Table_Module1.setModel(mdl);
       
    }
 
    //Deplacer un module
    
     public static void Deplacer_Module(int i){
         try{
        nom_module.setText(mdl.getValueAt(i,1).toString());
         nbr_elem.setText(mdl.getValueAt(i,2).toString());
         horaire_mod.setSelectedItem(mdl.getValueAt(i,3).toString());
        filiere_mod.setSelectedItem(mdl.getValueAt(i,4).toString());
        option_mod.setSelectedItem(mdl.getValueAt(i,5).toString());
        niveau_mod.setSelectedItem(mdl.getValueAt(i,6).toString());
         
      
    }catch(Exception e){
        
    }
    }



       //Afficher_Module
       public static void Afficher_Element(){
           
           elem.setRowCount(0);
            String el="Select * From Element_Module";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données ******************************************
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(el);
                   while(rs.next()){
                   elem.addRow(new Object[]{rs.getString("Id_Element"),rs.getString("Nom_Element"),rs.getString("Volume_Horaire_E"),
                   rs.getString("Intervenant_Element"),rs.getString("Nom_Module")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
       Table_Element.setModel(elem);
       }
     //Deplacer_Module()
       public static void Deplacer_Element(int i){
             try{
        nom_elem.setText(elem.getValueAt(i,1).toString());
        horaire_elem.setText(elem.getValueAt(i,2).toString());
        inter_elem.setSelectedItem(elem.getValueAt(i,3).toString());
        mod_elem.setSelectedItem(elem.getValueAt(i,4).toString());
        
         
      
    }catch(Exception e){
       }
       }
       //Afficher Note
   /*  public void Afficher_Note(String num){
           
           note.setRowCount(0);
           String c1=jComboBox6.getSelectedItem().toString();
           String c2=jComboBox7.getSelectedItem().toString();
           String c3=jComboBox8.getSelectedItem().toString();
           String no="Select * From Note  where N_Inscription='"+num+"' AND Nom_Module= '"+jComboBox9.getSelectedItem().toString()+"' "
                   + "AND N_Filiere='"+c1+"' AND N_Option='"+c2+"' AND N_Niveau='"+c3+"' ";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données ******************************************
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(no);
                   while(rs.next()){
                   note.addRow(new Object[]{rs.getString("Id_Note"),rs.getString("Nom"),
                   rs.getString("Note_Ds"),rs.getString("Note_Examen"),rs.getString("Note_Session_Normale"),rs.getString("Note_Session_Rattrapage"),rs.getString("Etat")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
       Table_Note1.setModel(note);
       }*/
       //Deplacer note
     /*  public static void Deplacer_Note(int i){
               try{
        //nom_note.setText(note.getValueAt(i,1).toString());
        ds.setText(note.getValueAt(i,2).toString());
        examen.setText(note.getValueAt(i,3).toString());
         module_etud.setSelectedItem(note.getValueAt(i,4).toString());
        filiere_etud.setSelectedItem(note.getValueAt(i,5).toString());
       option_etud.setSelectedItem(note.getValueAt(i,6).toString());
        niveau_etud.setSelectedItem(note.getValueAt(i,7).toString());
        
         
      
    }catch(Exception e){
       }
       }*/
    
       //Ajouter les informations d'un intervenant
       
      
     
       
      
//Deplacer intervenant
       
      

    //Séléctionner un intervenant
   
     //**************************
      public static void ComboboxIntervenantElement(){
         
 
         String r="SELECT * From Intervenant WHERE Intitule_Module = '"+mod_elem.getSelectedItem().toString()+"'";
      
        try{
          
            PreparedStatement ps=connection.ConnecteDb().prepareStatement(r);
            rs=ps.executeQuery();
           
            while(rs.next()){
               //Format du date 
              
            
              String nom_inter=rs.getString("Nom_Intervenant");
              inter_elem.addItem(nom_inter);
              
            }
           
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
     }
      //Table Abcense
     public void Afficher_Abcense(){
           abc.setRowCount(0);
                String num="";
                
                String op=option_ret.getSelectedItem().toString();
                String Fi=filiere_ret.getSelectedItem().toString();
                String ni=niveau_ret.getSelectedItem().toString();
                String mo=module_ret.getSelectedItem().toString();
                String indice="";
                String t="Absence";
                String insc="";
                Calendar calendar = Calendar.getInstance(); 
                int ann=calendar.get( Calendar.YEAR );
                
                String j="Absence non justifiée";
       String a="Select DISTINCT N_Inscription,Nom_Etud,Date_Abcense  From Abcense Where Filiere_A='"+Fi+"' AND Option_A='"+op+"' AND Niveau_A='"+ni+"'"
               + "AND Nom_Module_A='"+mo+"' AND Justification='"+j+"' AND Type='"+t+"' AND Date_Abcense BETWEEN (DATE_FORMAT(Now(),'%Y-%m-01')) AND (DATE_FORMAT(Now(),'%Y-%m-20')) AND Année_Abs='"+ann+"' ";
             Table_Abcense1.setModel(abc);
      
           
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
                  // Component comp =(Component) Table_Abcense1.getCellEditor();
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(a);
                   while(rs.next()){
                       num=rs.getString("N_Inscription");
                         abc.addRow(new Object[]{" ",rs.getString("N_Inscription"),rs.getString("Nom_Etud"),rs.getString("Date_Abcense"),Nombre_Abs(num)} );
                         
                   }
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
     
      

      }
      //Déplacer Abcense
       public static void Deplacer_Abcense(int i){
/*            num.setText(abc.getValueAt(i,1).toString());
            nom_abc.setText(abc.getValueAt(i,2).toString());*/
            filiere_abc.setSelectedItem(abc.getValueAt(i,3).toString());
            option_abc.setSelectedItem(abc.getValueAt(i,4).toString());
            niveau_abc.setSelectedItem(abc.getValueAt(i,5).toString());
            module_abc.setSelectedItem(abc.getValueAt(i,6).toString());
            elem_abc.setSelectedItem(abc.getValueAt(i,7).toString());
            date_abc.setDateFormatString(abc.getValueAt(i,8).toString());
            /*Seance1.setText(abc.getValueAt(i,8).toString());
            Seance2.setText(abc.getValueAt(i,9).toString());
            Seance3.setText(abc.getValueAt(i,10).toString());
            Seance4.setText(abc.getValueAt(i,11).toString());*/
            just_abc.setSelectedItem(abc.getValueAt(i,13).toString());
  
       }
       
      public static void Supprimer_Abcense(String num){
         try{
             String ty=type_abc.getSelectedItem().toString();
             String m=module_abc.getSelectedItem().toString();
             if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                         String date_A=((JTextField)date_abc.getDateEditor().getUiComponent()).getText();
     //La requête qui permet de supprimer les données de bla base de données ______________________________________________________                    
              String  query="Delete from Abcense  WHERE N_Inscription='"+num+"' AND Date_Abcense='"+((JTextField)date_abc.getDateEditor().getUiComponent()).getText()+"' AND "
                    + "Nom_Module_A='"+m+"' AND Type='"+ty+"' AND Duree_Abcense='"+duree_abc.getSelectedItem().toString()+"' AND Justification='"+just_abc.getSelectedItem().toString()+"'";
              
              
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
            JOptionPane.showMessageDialog(null,"Les informations sont supprimées !");
            }
              
      
             }catch(HeadlessException | SQLException e){
             JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }
       
      //Noter une abcense
      // public static void Ajouter_Abcense(){
              /*  try{
                 //   String a=num.getText();
             int id=Id_Etudiant_FK(a);
             int t=Duree_A();
             String d=Selectionner_Duree_A();*/
             
      /*   String o = "INSERT INTO Abcense(Id_Etudiant,N_Inscription,Nom_Etud,Filiere_A,Option_A,Niveau_A,Nom_Module_A,Nom_Element_A,Date_Abcense,Duree_Abcense,Justification,Totale_Heure)"
                 + " VALUES('"+id+"','"+num.getText()+"','"+nom_abc.getText()+"',"
                 + "'"+filiere_abc.getSelectedItem().toString()+"','"+option_abc.getSelectedItem().toString()+"',"
                 + "'"+niveau_abc.getSelectedItem().toString()+"','"+module_abc.getSelectedItem().toString()+"',"
                 + "'"+elem_abc.getSelectedItem().toString()+"','"+((JTextField)date_abc.getDateEditor().getUiComponent()).getText()+"','"+d+"','"+just_abc.getSelectedItem().toString()+"','"+t+"')";
     
      if(nom_abc.getText().length() !=0){
            
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
         JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
         Afficher_Note();
      }
        else{
             JOptionPane.showMessageDialog(null,"Veuillez choisir un nom pour l'étudiant ! ");
        }
       }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
       }*/
       //****************************************
      
       //*********************************
      public void Afficher_Retard(){
           ret.setRowCount(0);
            
                String opt=op1.getSelectedItem().toString();
                String Fil=fi1.getSelectedItem().toString();
                String niv=ni1.getSelectedItem().toString();
                String mod=mo1.getSelectedItem().toString();
                String t="Retard";
                String ju="Retard non justifié";
                 Calendar calendar = Calendar.getInstance(); 
                int ane=calendar.get( Calendar.YEAR );
                String re="SELECT * FROM Abcense WHERE Filiere_A='"+Fil+"' AND Option_A='"+opt+"' "
        + "AND Niveau_A='"+niv+"' AND Justification='"+ju+"' AND Nom_Module_A='"+mod+"' AND Type='"+t+"' AND Date_Abcense BETWEEN (DATE_FORMAT(Now(),'%Y-%m-01')) AND (DATE_FORMAT(Now(),'%Y-%m-20')) AND Année_Abs='"+ane+"'";
      
    
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(re);
                   while(rs.next()){
                   ret.addRow(new Object[]{rs.getString("N_Inscription"),rs.getString("Nom_Etud"),rs.getString("Date_Abcense")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       Table_Retard1.setModel(ret);
     
       }
       //*********************
    /*   public static void Ajouter_Retard(){
              try{
                  String r=num_ret.getText();
                  int id=Id_Etudiant_FK(r);
             int t=Duree_A();
             String d=Selectionner_Duree_R();
             
         String o = "INSERT INTO Retard_E(Id_Etudiant,Totale_Heure,N_Inscription,Nom_Etudiant,Filiere_R,Option_R,Niveau_R,Nom_Module_R,Nom_Element_R,Date_Retard,Duree_Retard,Justification_Retard)"
                 + " VALUES('"+id+"','"+t+"','"+num_ret.getText()+"','"+nom_ret.getText()+"',"
                 + "'"+filiere_ret.getSelectedItem().toString()+"','"+option_ret.getSelectedItem().toString()+"',"
                 + "'"+niveau_ret.getSelectedItem().toString()+"','"+module_ret.getSelectedItem().toString()+"',"
                 + "'"+elem_ret.getSelectedItem().toString()+"','"+((JTextField)date_ret.getDateEditor().getUiComponent()).getText()+"','"+d+"','"+just_ret.getSelectedItem().toString()+"')";
     
      if(nom_ret.getText().length() !=0){
            
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
         JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
         Afficher_Note();
      }
        else{
             JOptionPane.showMessageDialog(null,"Veuillez entrer un numéro d'inscription valide! ");
        }
       }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
       }*/
       //***********
     /*  public static void Supprimer_Retard(){
         try{
             if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                     String date_R=((JTextField)date_ret.getDateEditor().getUiComponent()).getText();
//La requête qui permet de supprimer les données de la base de données ______________________________________________________                    
              String  query="Delete from Retard_E where Date_Retard= '"+date_R+"' AND Nom_Etudiant='"+nom_ret.getText()+"' ";
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
              JOptionPane.showMessageDialog(null,"Les informations sont supprimées !");
             }
              
              
        }catch(HeadlessException | SQLException e){
             JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }*/
       //******************************
      /*  public static String  Selectionner_Duree_A(){
         String d="";
  if (Seance1.isSelected()) {
  d += Seance1.getText() + "  ";
  
  }
  if (Seance2.isSelected()) {
  d += Seance2.getText() + "  ";
   
  }
   if (Seance3.isSelected()) {
  d += Seance3.getText() + "  ";
   
  }
    if (Seance4.isSelected()) {
  d += Seance4.getText() + "  ";
   
  }
       return d;
        }*/
      /*      public static int Duree_A(){
         int t=0;
  if (Seance1.isSelected()) {
  
  t +=2;
  
  }
  if (Seance2.isSelected()) {
 
    t +=2;
  }
   if (Seance3.isSelected()) {
 
    t +=2;
  }
    if (Seance4.isSelected()) {
  t+=2;
   
  }
    return t;
        }*/
 
  //************************
  

    //Extraire le code d'option
   public static String Code_Option(String c){
          String r="Select * From Option_E where Nom_Option='"+c+"'";
          String nomoption="";
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(r);
                   if(rs.next()){
                    nomoption=rs.getString("Code_Option");
                    return nomoption;
                   }
                   
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
        return nomoption;
   }
    //Extraire le numéro d'inscription
    public static int Id_Inscription(){
          String i="Select * From Etudiant ";
          int comp=0,id=0;
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(i);
                    while(rs.next()){
                  id=rs.getInt("Id_Etudiant");
                  
    }
             
        return id+1;
                   
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
        return comp;
   }
    //***************************
   /* public static void Nom_Etudiant(){
        
          String r="Select * From Etudiant where N_Inscription='"+num.getText()+"'";
            
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(r);
                   if(rs.next()){
                   String Nom=rs.getString("Nom");
                   String prenom=rs.getString("Prenom");
                   // nom_abc.setText(Nom+" "+prenom);
                     
                   }
                   
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
        
   }*/
     public static int Id_Etudiant_FK(String s1){
         
        
          String r="Select * From Etudiant where N_Inscription='"+s1+"'";
            int id;
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(r);
                   if(rs.next()){
                   int N=rs.getInt("Id_Etudiant");
                    return N;
                   }
                   
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
      return 0;  
   }
     //liste des abcenses
     /* public static void Etudiant_Abcense(){
        String j="Abcense non justifiée";
          String r="Select * From Abcense where Justification='"+j+"' AND Totale_Heure>=6 AND N_Inscription='"+num.getText()+"'";
            int id;
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
                DefaultListModel m = new   DefaultListModel();
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(r);
                   while(rs.next()){
                   String N=rs.getString("Nom_Etud");
                   m.addElement(N);
                    jList1.setModel(m);
                   
                   }
                   
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
    
   }*/
      
       //********************
       
      /* public static void A(String s1){
            DefaultListModel m = new   DefaultListModel();
             String j="Abcense non justifiée";
             String q="SELECT * FROM Abcense WHERE Nom_Etud='"+s1+"' AND Nom_Module_A='"+abc_module.getSelectedItem().toString()+"' AND Justification='"+j+"'";
                     int som=0;
                     int id;
                       try{
                
                   st=connection.ConnecteDb().createStatement();
                   rs1=st.executeQuery(q);
                   while(rs1.next()){
                      id=rs1.getInt("Totale_Heure");
                           som=som+id;
                     
                   }
                    if(som >= 6){
                          m.addElement(s1);
                   // jList1.setModel(m);
                     }
                   
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
                     
                                      
       }*/
    /*   public static void Afficher_Etud_Abc(){
             String r="Select * From Abcense ";
             DefaultListModel m = new   DefaultListModel();
             String j="Abcense non justifiée";
           
                     int som=0;
                     int id;
            String nom="";
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
                 
             
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(r);
                   while(rs.next()){
                      nom=rs.getString("Nom_Etud");
                      String q="SELECT * FROM Abcense WHERE Nom_Etud='"+nom+"' AND Nom_Module_A="
                              + "'"+abc_module.getSelectedItem().toString()+"' AND Justification='"+j+"'";
                       st1=connection.ConnecteDb().createStatement();
                   rs1=st1.executeQuery(q);
                   while(rs1.next()){
                      id=rs1.getInt("Totale_Heure");
                           som=som+id;
                     
                   }
                    if(som >= 6){
                         if(!m.contains(nom)){
                          
                          m.addElement(nom);
                         // jList1.setModel(m);}
                     }
                    som=0;
                   }
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
       }*/
       //**************************
         
   /*  public static void Afficher_Etud_Ret(){
            
             DefaultListModel l = new   DefaultListModel();
             String j="Retard non justifié";
           
            String nom="";
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
            
             
                      String q="SELECT * FROM Retard_E WHERE Nom_Module_R="
                              + "'"+ret_module.getSelectedItem().toString()+"' AND Justification_Retard='"+j+"'";
                       st1=connection.ConnecteDb().createStatement();
                   rs1=st1.executeQuery(q);
                  
                       while(rs1.next()){
                           nom=rs1.getString("Nom_Etudiant");
                       }
                         if(!l.contains(nom)){
                             
                          l.addElement(nom);
                          liste_ret.setModel(l);}
                     
            
                   
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
         
       }*/
         /*  public static String  Selectionner_Duree_R(){
         String d="";
  if (Seance_1.isSelected()) {
  d += Seance_1.getText() + "  ";
  
  }
  if (Seance_2.isSelected()) {
  d += Seance_2.getText() + "  ";
   
  }
   if (Seance_3.isSelected()) {
  d += Seance_3.getText() + "  ";
   
  }
    if (Seance_4.isSelected()) {
  d += Seance_4.getText() + "  ";
   
  }
      
}*/
            //*************
            public  static String combo(){
                switch(comborech.getSelectedIndex()){
                    case 0 :return "N_Inscription";
                    case 1:return "Nom";
                    
                }
                return "";
            }
            //**************
             public  void Rechercher_Etudiant() throws ClassNotFoundException{
                String op=option_info.getSelectedItem().toString();
                String Fi=filiere_info.getSelectedItem().toString();
                String ni=niveau_info.getSelectedItem().toString();
                int ann= jYearChooser1.getYear();
               
               String r="SELECT * FROM Etudiant WHERE Filiere_E='"+filiere_info.getSelectedItem().toString()+"' AND "
                        + " Option_E='"+option_info.getSelectedItem().toString()+"' AND Niveau_E='"+niveau_info.getSelectedItem().toString()+"'   AND  "+combo()+"= '"+textrech.getText()+"' AND Année='"+ann+"' ";
                
                       
                      try{
                           st=connection.ConnecteDb().createStatement();
                           rs=st.executeQuery(r);
                     String cne="";
                      if(rs.next()){
                           
                          String nu=rs.getString("N_Inscription");
                           text_num.setText(nu);
                               cne=rs.getString("CNE");     
                           cne_a.setText(cne);
                               String ci=rs.getString("CIN");
                           cin_a.setText(ci);
                                String no=rs.getString("NOM");
                           nom_a.setText(no);
                                 String pre=rs.getString("Prenom");
                           prenom_a.setText(pre);
                                 String sex=rs.getString("Sexe");
                          sexe_a.setText(sex);
                                 String d_nai=rs.getString("Date_Naissance");
                           naissance_a.setText(d_nai);
                                   String l=rs.getString("Lieux_Naissance");
                           lieux_a.setText(l);
                                    String ad1=rs.getString("Adresse1");
                           adr1_a.setText(ad1);
                                     String ad2=rs.getString("Adresse2");
                           adr2_a.setText(ad2);
                                       String tele1=rs.getString("N_Telephone1");
                           tel1_a.setText(tele1);
                                         String tele2=rs.getString("N_Telephone2");
                           tel2_a.setText(tele2);
                                          String nas=rs.getString("Nationalite");
                           nationalite_a.setText(nas);
                                            String ac=rs.getString("Adresse_Actuel");
                           actuel_a.setText(ac);
                                            String si=rs.getString("Situation_Famille");
                           situation_a.setText(si);
                                          String w=rs.getString("Num_WhatsApp");
                           whatsup_a.setText(w);
                                          String em1=rs.getString("Email1");
                           email1_a.setText(em1);
                                            String em2=rs.getString("Email2");
                           email2_a.setText(em2);
                                            String ne=rs.getString("Nombre_Enfants");
                           nbr_enfant_a.setText(ne);
                            String numi=rs.getString("N_Inscription");
                           num_a.setText(numi);
                            String insc=rs.getString("Date_Inscription");
                           insc_a.setText(insc);
                            String b=rs.getString("Boursiere");
                           bou_a.setText(b);
                            String ob=rs.getString("Annee_Obtention_Bac");
                           obtention_a.setText(ob);
                            String m=rs.getString("Mention_Bac");
                           mention_a.setText(m);
                            String mo=rs.getString("Moyenne_Bac");
                           moyenne_a.setText(mo);
                            String ly=rs.getString("Lycee");
                           lycee_a.setText(ly);
                            String fi=rs.getString("Filiere_E");
                           filiere_a.setText(fi);
                            String opt=rs.getString("Option_E");
                           option_a.setText(opt);
                            String niv=rs.getString("Niveau_E");
                           niveau_a.setText(niv);
                           
                            String la=rs.getString("Langues_Maitrises");
                          
                           String lo=rs.getString("Logiciels_Maitrises");
                          
                           String an=rs.getString("Formation_Anterieure");
                           
                           String at=rs.getString("Formation_Attelier");
                         
                           String di=rs.getString("Diplomes");
                            v.addRow(new Object[]{no,la,lo,an,at,di} );
                          
                             int a=Nombre_Abcense_Et();
                             nbr_abc_a.setText(Integer.toString(a));
                              //Livres_Emprunter(cne);
                            Res_Sem(numi);
                           table_compethence1.setModel(v);
                          
                          
                       }else{
                          JOptionPane.showMessageDialog(null,"Les informations introuvable !");
                      }
                      
                      }catch(SQLException e){
                          JOptionPane.showMessageDialog(null,e.getMessage());
                      }
            }
      public void Deplacer_Et(int i){
    try{
        cin_a.setText(model.getValueAt(i,1).toString());
        cne_a.setText(model.getValueAt(i,0).toString());
        nom_a.setText(model.getValueAt(i,2).toString());
        prenom_a.setText(model.getValueAt(i,3).toString());
       naissance_a.setText(model.getValueAt(i,5).toString());
       lieux_a.setText(model.getValueAt(i,6).toString());
        sexe_a.setText(model.getValueAt(i,4).toString());
        adr1_a.setText(model.getValueAt(i,7).toString());
         adr2_a.setText(model.getValueAt(i,8).toString());
       
    }catch(Exception e){
        
    }
      }
      //*********************
      public static void Actualiser(){
          cne_a.setText("");
          cin_a.setText("");
          nom_a.setText("");
          prenom_a.setText("");
          sexe_a.setText("");
          adr1_a.setText("");
          adr2_a.setText("");
          lieux_a.setText("");
          naissance_a.setText("");
          
      }
      //***************
      public void Afficher_Info(){
       
               p2.setRowCount(0);
                String opp=option_info.getSelectedItem().toString();
                String Fii=filiere_info.getSelectedItem().toString();
                String nii=niveau_info.getSelectedItem().toString();
                 int ani= jYearChooser1.getYear();
                  String af="SELECT * FROM Etudiant WHERE Filiere_E='"+Fii+"' AND Option_E='"+opp+"' AND Niveau_E='"+nii+"'  AND Année='"+ani+"'";
      
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(af);
                   while(rs.next()){
                   
                    p2.addRow(new Object[]{rs.getString("Nom"),rs.getString("N_Telephone1"),rs.getString("N_Telephone2"),rs.getString("Nationalite"), rs.getString("Adresse_Actuel"),rs.getString("Situation_Famille"),rs.getString("Num_WhatsApp"),
                   rs.getString("Email1"),rs.getString("Email2"),rs.getString("Nombre_Enfants")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
    
       
       
       table_per2.setModel(p2); 
    
           
      }
       public  void Afficher_Info_Scolaire(){
       
               sc.setRowCount(0);
                String op=option_info.getSelectedItem().toString();
                String Fi=filiere_info.getSelectedItem().toString();
                String ni=niveau_info.getSelectedItem().toString();
                 int ann= jYearChooser1.getYear();
                String af="SELECT * FROM Etudiant WHERE Filiere_E='"+Fi+"' AND Option_E='"+op+"' AND Niveau_E='"+ni+"' AND Année='"+ann+"' ";
      
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(af);
                   while(rs.next()){
                   
                    sc.addRow(new Object[]{rs.getString("N_Inscription"),rs.getString("Date_Inscription"),rs.getString("Boursiere"),rs.getString("Annee_Obtention_Bac"), rs.getString("Mention_Bac"),rs.getString("Moyenne_Bac"),rs.getString("Lycee"),
                   rs.getString("Filiere_E"),rs.getString("Option_E"),rs.getString("Niveau_E")} );
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
      
       //Cette fonction permet de déplacer permet de déplacer les enregistrements de la table *****************************************
    
       
       
       table_scolaire.setModel(sc); 
    
           
      }
       //******************************
       public void Afficher_Compethence(){
                 
                  co.setRowCount(0);
                  String op3=option_info.getSelectedItem().toString();
                String Fi3=filiere_info.getSelectedItem().toString();
                String ni3=niveau_info.getSelectedItem().toString();
            int ann= jYearChooser1.getYear();
            String af="SELECT * FROM Etudiant WHERE Filiere_E='"+Fi3+"' AND Option_E='"+op3+"' AND Niveau_E='"+ni3+"'  AND Année='"+ann+"'";
      
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(af);
                   while(rs.next()){
                   co.addRow(new Object[]{rs.getString("Nom"),rs.getString("Langues_Maitrises"), rs.getString("Logiciels_Maitrises"),rs.getString("Formation_Anterieure"),
                   rs.getString("Formation_Attelier"),rs.getString("Diplomes")} );
                   
                    
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
       table_compethence.setModel(co);
       }
       
       //Modifier Module
       public  void Modifier_Module(){
                try {
           
      String sql="UPDATE Module_E SET  Nombre_Element='"+nbr_elem.getText()+"', Volume_Horaire='"+horaire_mod.getSelectedItem().toString()+"',Type_Module='"+type.getSelectedItem().toString()+"', Filiere_Mod='"+filiere_mod.getSelectedItem().toString()+"',Option_Mod='"+option_mod.getSelectedItem().toString()+"',Niveau_Mod='"+niveau_mod.getSelectedItem().toString()+"' WHERE Intitule_Module='"+nom_module.getText()+"'";
      if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
               String s1=num_insc.getText();
       
        PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);
           
            pst.executeUpdate();
                
             JOptionPane.showMessageDialog(null,"modification effectué");}
      
           
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
       }
       }
       //*************************
        public  void Modifier_Element(){
                try {
           
      String sql="UPDATE Element_Module SET Nom_Module='"+mod_elem.getSelectedItem().toString()+"', Nom_Element='"+nom_elem.getText()+"',Intervenant_Element='"+inter_elem.getSelectedItem().toString()+"',Volume_Horaire_E='"+horaire_elem.getText()+"' WHERE Nom_Element='"+nom_elem.getText()+"' ";
      if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
               String s1=num_insc.getText() ;
       
        PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);
           
            pst.executeUpdate();
                
             JOptionPane.showMessageDialog(null,"modification effectué");}
      
           
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
       }
       }
        //******************
         
         //*****************
          public void Modifier_Option(){
                try {
           
      String sql="UPDATE Option_E SET Code_Option='"+code.getText()+"',Nom_Filiere='"+nom_filiere.getSelectedItem().toString()+"' WHERE Nom_Option='"+nom_option.getText()+"' ";
      if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
               String s1=num_insc.getText() ;
       
        PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);
           
            pst.executeUpdate();
                
             JOptionPane.showMessageDialog(null,"modification effectué");}
      
           
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
       }
       }
          //******
          public static void Afficher_F_Intervenant(){
              String s1="Intervenant";
              String c=mod_elem.getSelectedItem().toString();
                String af="SELECT * FROM Cors_Enseignant WHERE Fonction='"+s1+"' AND Module_C='"+c+"'";
      
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(af);
                   while(rs.next()){
                  String f=rs.getString("Nom");
                   String p=rs.getString("Prenom");
                   inter_elem.addItem(f +" " + p);
                    
                   }
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
          }
          public static Double Calculer_Note(Double ds,Double exam){
               
             Double r1= 0.25 * ds;
             Double r2=exam * 0.75;
             Double res=r1+r2;
              return  (double) Math.round(res * 100) / 100;
              
          }
          public static String Etat(Double ds,Double exam,String num){
              Double c=Calculer_Note(ds,exam);
              if((c>=10) && (Nombre_Abcense(num)==false)){
                  return "Validé par acquisition";
              }
                  return "Rattrapage";
             
          }
          
          
       /*   public void Calculer_Note_S(){
            
             DefaultListModel l = new   DefaultListModel();
       
          
            
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
               se.setRowCount(0);
                      Double res = 0.0,som;
                      Double nbr=Nombre_Module();
                      String q="Select * from Note Where N_Inscription='"+num_s.getText()+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                              + "N_Option='"+option_s.getSelectedItem().toString()+"' ";
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                  
                      while(rs.next()){
                           String nomE=rs.getString("Nom");
                           nom1.setText(nomE);
                           String num_i=rs.getString("N_Inscription");
                           num_insc1.setText(num_i);
                           String f=rs.getString("N_Filiere");
                           filiere1.setText(f);
                           String o=rs.getString("N_Option");
                           option1.setText(o);
                           String mo=rs.getString("Nom_Module");
                           se.addRow(new Object[]{rs.getString("Nom_Module"),rs.getString("Note_Generale"),rs.getString("Etat")} );
                           Double note_G =rs.getDouble("Note_Generale");
                           res=res+note_G;
                       }
                      if(nbr!=0){
                          som=res/nbr;
                          Double f=(double) Math.round(som * 100) / 100;
                         note_generale.setText(f+"/20");
                           if(som>=10.0){
                               if(Note_Module()){
                                   etat.setText("Validé avec acquisition");
                               }
                      }else{
                          etat.setText("Non valide");
                      }
                       
                      table_sem.setModel(se);       
                      }
                    
                     
                         
                     
            
                   
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
          }*/
          
          //****************************
              public static boolean Nombre_Abcense(String num){
             
            
             String j="Absence non justifiée";
           
                     int som=0,id;
                    
                     
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
            
                        Calendar calendar = Calendar.getInstance(); 
                int ann=calendar.get( Calendar.YEAR );
                      String q="SELECT * FROM Abcense WHERE N_Inscription='"+num+"' AND Nom_Module_A="
                              + "'"+module_ret.getSelectedItem().toString()+"' AND Justification='"+j+"' AND Année_Abs='"+ann+"'";
                   st1=connection.ConnecteDb().createStatement();
                   rs1=st1.executeQuery(q);
                   while(rs1.next()){
                      id=rs1.getInt("Totale_Heure");
                           som=som+id;
                     
                   }
                    if(som >= 6){
                          
                           return true;
                     }
                  
                   return false;
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
       return false;
       }
                public static int Nombre_Abs(String num){
             
            
             String j="Absence non justifiée";
           
                     int som=0,id;
                    
                     
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
              Calendar calendar = Calendar.getInstance(); 
             int ann=calendar.get( Calendar.YEAR );
           
                      String q="SELECT * FROM Abcense WHERE N_Inscription='"+num+"' AND Nom_Module_A="
                              + "'"+module_ret.getSelectedItem().toString()+"' AND Justification='"+j+"' AND Année_Abs='"+ann+"'";
                   st1=connection.ConnecteDb().createStatement();
                   rs1=st1.executeQuery(q);
                   while(rs1.next()){
                      id=rs1.getInt("Totale_Heure");
                           som=som+id;
                     
                   }
                  return som;
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
       return 0;
       }
             public Double Nombre_Module(){
                 Double count=0.0;
                    Calendar calendar = Calendar.getInstance(); 
                int ane=calendar.get( Calendar.YEAR );
                 String q="SELECT * FROM Module_E WHERE "
                         + "Filiere_Mod='"+filiere_s.getSelectedItem().toString()+"'AND "
                              + "Option_Mod='"+option_s.getSelectedItem().toString()+"' AND Niveau_Mod='"+niveau_s.getSelectedItem().toString()+"' AND Année='"+ane+"'";
                 
                try{
                    st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(q);
                   while(rs.next()){
                        
                       count=count+1;
                   }
                   return count;
                 
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(null,e.getMessage());
                }
                 return 0.0; 
             }
         //********************
             public static int Id_Module(){
                  String r="Select * From Module_E ";
            int N=0;
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(r);
                   while(rs.next()){
                    N=rs.getInt("Id_Module");
                   
                   }
                    return N;
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
      return 0;  
             }
             public static void Afficher_Image(){
                   String r="SELECT * FROM Etudiant WHERE "+combo()+"= '"+textrech.getText()+"' ";
                
                       
                      try{
                           st=connection.ConnecteDb().createStatement();
                           rs=st.executeQuery(r);
                  
                      if(rs.next()){
                          /*String img =rs.getString("Photo");
                          photo_a.setIcon( new ImageIcon( img ));*/
                          
                        
                           String img =rs.getString("Photo");
                           ImageIcon image=new ImageIcon(img);
                           Image  im= image.getImage();
                           Image myimg=im.getScaledInstance(photo_a.getWidth(),photo_a.getHeight(),Image.SCALE_SMOOTH);
                           ImageIcon imgg=new ImageIcon(myimg);
                           //JOptionPane.showMessageDialog(null,"edsds"+imgg);
                           photo_a.setIcon(imgg);
                      }
                      
             }catch(Exception e){
                  JOptionPane.showMessageDialog(null,e.getMessage());
             }
             }
             //****************************
          /*   public void Calculer_Note_A(){
            
            
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
               se.setRowCount(0);
                      Double res = 0.0,som;
                      Double nbr=Nombre_Module();
                      String q="Select * from Note Where N_Inscription='"+num_s.getText()+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                              + "N_Option='"+option_s.getSelectedItem().toString()+"' ";
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                  
                      while(rs.next()){
                           String nomE=rs.getString("Nom");
                           nom1.setText(nomE);
                           String num_i=rs.getString("N_Inscription");
                           num_insc1.setText(num_i);
                           String f=rs.getString("N_Filiere");
                           filiere1.setText(f);
                           String o=rs.getString("N_Option");
                           option1.setText(o);
                           
                           String mo=rs.getString("Nom_Module");
                           String et=rs.getString("Etat");
                          
                           se.addRow(new Object[]{rs.getString("Nom_Module"),rs.getString("Note_Generale"),rs.getString("Etat")} );
                           
                       }
                     //Resultat();
                      
                       
                      table_sem1.setModel(se);       
                      
       }catch(Exception e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
             }*/
             //************************
             public static void Ajouter_Note_S(String s1, String nom,String f,String op,String n,Double note,String Etat,String cne){
                 try{
                      Calendar calendar = Calendar.getInstance(); 
                        int an=calendar.get( Calendar.YEAR );
                    String o="Insert into Note_Semestre (N_Inscription,Nom,Filiere_S,Option_S,Niveau,Note_S_Normale,Etat,Annee_Universitaire,CNE) "
           + "values('"+s1+"','"+nom+"','"+f+"','"+op+"','"+n+"','"+note+"','"+Etat+"' ,'"+an+"','"+cne+"') ";
                  
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
         //JOptionPane.showMessageDialog(null,"Calculation éfféctuées  ");
         
                 }catch(Exception e){
                     JOptionPane.showMessageDialog(null,e.getMessage());
                 }
             }
             //****************
           /*  public static void Resultat(){
                 try{
                    double som=0,res;
                     String q="Select * from Note Where N_Inscription='"+num_s.getText()+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                              + "N_Option='"+option_s.getSelectedItem().toString()+"' ";
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                  
                      while(rs.next()){
                           double n=rs.getDouble("Note");
                           som=som+n;
                      }
                      res=som/6;
                      if(res>=10){
                          etat1.setText("Validé avec acquisition");
                      }else{
                          etat1.setText("Non valide");
                      }
                 }catch(Exception e){
                         JOptionPane.showMessageDialog(null,e.getMessage());
                         }
             }*/
          //Extraire le numéro d'inscription
             public boolean N_Inscription(){
                  String i="Select * From Etudiant Where N_Inscription='"+num_insc.getText()+"'";
        
                  try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(i);
                    if(rs.next()){
                    return true;
                  
               }else{
                    return false;
                    }
             
        
                   
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
               return false;      
             }
      //*******************************
              public  void Image_Etudiant(){
                   String r="SELECT * FROM Etudiant WHERE N_Inscription='"+num_insc.getText()+"' ";
                
                       
                      try{
                           st=connection.ConnecteDb().createStatement();
                           rs=st.executeQuery(r);
                  
                      if(rs.next()){
                          /*String img =rs.getString("Photo");
                          photo_a.setIcon( new ImageIcon( img ));*/
                          
                        
                           String img =rs.getString("Photo");
                           ImageIcon image=new ImageIcon(img);
                           Image  im= image.getImage();
                           Image myimg=im.getScaledInstance(label.getWidth(),label.getHeight(),Image.SCALE_SMOOTH);
                           ImageIcon imgg=new ImageIcon(myimg);
                           //JOptionPane.showMessageDialog(null,"edsds"+imgg);
                           label.setIcon(imgg);
                      }
                      
             }catch(Exception e){
                  JOptionPane.showMessageDialog(null,e.getMessage());
             }
             }
              //Les langues mitrîsées
            public String Langues_Et(){
         String l ="";
  if (Ar.isSelected()) {
  
   l += Ar.getText() + "  "+jComboBox1.getSelectedItem().toString()+"\n";
  
  }
  if (An.isSelected()) {
 
    l += An.getText() + "  "+jComboBox2.getSelectedItem().toString()+"\n";
  }
   if (Ta.isSelected()) {
 
    l += Ta.getText() + "  "+jComboBox5.getSelectedItem().toString()+"\n";
  }
    if (Es.isSelected()) {
 l += Es.getText() + "  "+jComboBox3.getSelectedItem().toString()+"\n";
   
  }
     if (Fr.isSelected()) {
  l += Fr.getText() + "  "+jComboBox4.getSelectedItem().toString()+"\n";
   
  }
    return l;
}
             //****************************************
               public  String Logiciels_Et(){
         String lo ="  ";
  if (jCheckBox1.isSelected()) {
  
   lo += jCheckBox1.getText() + "\n";
  
  }
  if (jCheckBox2.isSelected()) {
 
    lo += jCheckBox2.getText() + " \n";
  }
   if (jCheckBox3.isSelected()) {
 
    lo += jCheckBox3.getText() + " \n";
  }
    if (jCheckBox4.isSelected()) {
 lo += jCheckBox4.getText() + " \n";
   
  }
    
    return lo;
}
               //Afficher les informations d'un étudiants
               public void Afficher_Info_Et(){
                      Calendar calendar = Calendar.getInstance(); 
                int ane=calendar.get( Calendar.YEAR );
                    try{
            String r="SELECT * FROM Etudiant where N_Inscription='"+num_insc.getText()+"' AND Année='"+ane+"'";
            Image_Etudiant();

            st=connection.ConnecteDb().createStatement();
            rs=st.executeQuery(r);

            if(rs.next()){
               
                String cne=rs.getString("CNE");
                cne_p.setText(cne);
                String ci=rs.getString("CIN");
                cin.setText(ci);
                String no=rs.getString("NOM");
                nom.setText(no);
                String pre=rs.getString("Prenom");
                prenom.setText(pre);
                String sex=rs.getString("Sexe");
                if(sex.equals("Femme")){
                    femme.setSelected(true);
                }else{
                    homme.setSelected(true);
                }

                String l=rs.getString("Lieux_Naissance");
                lieux.setText(l);
                String ad1=rs.getString("Adresse1");
                adr1.setText(ad1);
                String ad2=rs.getString("Adresse2");
                adr2.setText(ad2);
                String tele1=rs.getString("N_Telephone1");
                tel1.setText(tele1);
                String tele2=rs.getString("N_Telephone2");
                tel2.setText(tele2);
                String nas=rs.getString("Nationalite");
                nationalite.setText(nas);
                String ac=rs.getString("Adresse_Actuel");
                adr_actuel.setText(ac);
                String si=rs.getString("Situation_Famille");
                situation.setSelectedItem(si);
                String w=rs.getString("Num_WhatsApp");
                whatsup.setText(w);
                String em1=rs.getString("Email1");
                email1.setText(em1);
                String em2=rs.getString("Email2");
                email2.setText(em2);
                String ne=rs.getString("Nombre_Enfants");
                nbr_enfant.setText(ne);
                /*String numi=rs.getString("N_Inscription");
                num.setText(numi);*/
                String b=rs.getString("Boursiere");
              /*  if( b.equals("oui")){
                    oui.setSelected(true);
                }else{
                    non.setSelected(true);
                }*/
                String ob=rs.getString("Annee_Obtention_Bac");
                obtention.setText(ob);
                String m=rs.getString("Mention_Bac");
                mention.setText(m);
                String mo=rs.getString("Moyenne_Bac");
                moyenne.setText(mo);
                String ly=rs.getString("Lycee");
                lycee.setText(ly);
                String fi=rs.getString("Filiere_E");
                filiere.setSelectedItem(fi);
                String opt=rs.getString("Option_E");
                option.setSelectedItem(opt);
                Date d=rs.getDate("Date_Naissance");
                naissance.setDate(d);
                Date in=rs.getDate("Date_Inscription");
                inscription.setDate(in);
                String la=rs.getString("Langues_Maitrises");
              
                String lo=rs.getString("Logiciels_Maitrises");
                
                String an=rs.getString("Formation_Anterieure");
                anterieure.setText(an);
                String at=rs.getString("Formation_Attelier");
                attelier.setText(at);
                String di=rs.getString("Diplomes");
                diplome.setText(di);
                String av=rs.getString("Avez_Vous_Enfant");
              /*  if(av.equals("Oui")){
                    Oui.setSelected(true);
                }else{
                     Non.setSelected(true);
               }*/
                 
            }
        }catch(SQLException e){
               JOptionPane.showMessageDialog(null,e.getMessage());
        }
               }
               
               //Fonction qui retourne l'année
                public static String Get_Date(){
                 String date=((JTextField)inscription.getDateEditor().getUiComponent()).getText();
         
                       if(date.length()!=0){
                         //Frmat de la date (Année)
                         DateFormat year=new SimpleDateFormat("yyyy");
                         String s1=year.format(inscription.getDate());
                          //Si il ya une date retourne l'année de cette dérnière
                                  return s1;
                                             }
                           //Sinon retourne null
                                  return null;
                                                }
                
                
                
                
                //Cette méthode permet d'extraire les informations d'un étudiant selon des conditions
                public static void Afficher_Et(){
                   ab=(DefaultTableModel) Table_Abc.getModel();
                    ab.setRowCount(0);
                String op=option_abc.getSelectedItem().toString();
                String Fi=filiere_abc.getSelectedItem().toString();
                String ni=niveau_abc.getSelectedItem().toString();
                Calendar calendar = Calendar.getInstance(); 
                int ann=calendar.get( Calendar.YEAR );
                String af="SELECT * FROM Etudiant WHERE Filiere_E='"+Fi+"' AND Option_E='"+op+"' AND Niveau_E='"+ni+"'  AND Année='"+ann+"'";
                try{
                      st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(af);
                     while(rs.next()){
                   ab.addRow(new Object[]{rs.getString("N_Inscription"),rs.getString("Nom"),rs.getString("Prenom"),false} );
                   }
                    Table_Abc.setModel(ab);
                }catch(Exception e){
                  JOptionPane.showMessageDialog(null,e.getMessage());
                
                }
                }
                public static void Ajouter_Abcense(String num,String nom){
               try{
            
             int id=Id_Etudiant_FK(num);
             int t=2;
           Calendar calendar = Calendar.getInstance(); 
             int ann=calendar.get( Calendar.YEAR );
             
         String o = "INSERT INTO Abcense(Id_Etudiant,N_Inscription,Nom_Etud,Filiere_A,Option_A,Niveau_A,Nom_Module_A,Nom_Element_A,Date_Abcense,Duree_Abcense,Justification,Totale_Heure,Type,Année_Abs)"
                 + " VALUES('"+id+"','"+num+"','"+nom+"',"
                 + "'"+filiere_abc.getSelectedItem().toString()+"','"+option_abc.getSelectedItem().toString()+"',"
                 + "'"+niveau_abc.getSelectedItem().toString()+"','"+module_abc.getSelectedItem().toString()+"',"
                 + "'"+elem_abc.getSelectedItem().toString()+"','"+((JTextField)date_abc.getDateEditor().getUiComponent()).getText()+"','"+duree_abc.getSelectedItem().toString()+"','"+just_abc.getSelectedItem().toString()+"','"+t+"','"+type_abc.getSelectedItem().toString()+"','"+ann+"' )";
     
     
            
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
       
       }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
                }
               //****************************
               public void Ajouter_Abc(){
                   for(int i=0;i<Table_Abc.getRowCount();i++){
                       Boolean checked=Boolean.valueOf(Table_Abc.getValueAt(i,3).toString());
                       String num=Table_Abc.getValueAt(i,0).toString();
                       String nom=Table_Abc.getValueAt(i,1).toString();
                       if(checked){
                          Ajouter_Abcense(num,nom);
                          
                   }
               }
                    JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
               
}
         //***************************************
                 public static void Ajouter_Retard(String num,String nom){
              try{
                  
                  int id=Id_Etudiant_FK(num);
                
             
         String o = "INSERT INTO Retard_E(Id_Etudiant,N_Inscription,Nom_Etudiant,Filiere_R,Option_R,Niveau_R,Nom_Module_R,Nom_Element_R,Date_Retard,Duree_Retard,Justification_Retard)"
                 + " VALUES('"+id+"','"+num+"','"+nom+"',"
                 + "'"+filiere_abc.getSelectedItem().toString()+"','"+option_abc.getSelectedItem().toString()+"',"
                 + "'"+niveau_abc.getSelectedItem().toString()+"','"+module_abc.getSelectedItem().toString()+"',"
                 + "'"+elem_abc.getSelectedItem().toString()+"','"+((JTextField)date_abc.getDateEditor().getUiComponent()).getText()+"','"+duree_abc.getSelectedItem().toString()+"','"+just_abc.getSelectedItem().toString()+"')";
     
      
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
        
      
       }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
       }
                  public void Ajouter_Ret(){
                   for(int i=0;i<Table_Abc.getRowCount();i++){
                       Boolean checked=Boolean.valueOf(Table_Abc.getValueAt(i,3).toString());
                       String num=Table_Abc.getValueAt(i,0).toString();
                       String nom=Table_Abc.getValueAt(i,1).toString();
                       if(checked){
                          Ajouter_Retard(num,nom);
                           JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
                   }
               }
               
}
                  //Récupérer la liste des étudiants qui sont abcentes
                  
                  
                  
                  public void Liste_Abc(){
                      String r="SELECT * FROM Abcense WHERE Date_Abcense ";
                                                                                 
                       
                      try{
                           st=connection.ConnecteDb().createStatement();
                           rs=st.executeQuery(r);
                  
                      while(rs.next()){
                         Date d=rs.getDate("Date_Abcense");
                           JOptionPane.showMessageDialog(null,d);
                          
                      }
                      
             }catch(Exception e){
                  JOptionPane.showMessageDialog(null,e.getMessage());
             }
                  }
                      //Retourner le nombre d'abcense
                      public static int Nombre_Abcense_Et(){
             
            
                      String j="Abcense non justifiée";
           
                     int som=0,id;
                    
                     
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
            
                         Calendar calendar = Calendar.getInstance(); 
                        int ane=calendar.get( Calendar.YEAR );
                      String q="SELECT * FROM Abcense WHERE N_Inscription='"+text_num.getText()+"'  AND Année_Abs='"+ane+"'";
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(q);
                   while(rs.next()){
                      id=rs.getInt("Totale_Heure");
                           som=som+id;
                     
                   }
                    return som;
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
       return som;
       }
                //********************************
                      public void Supprimer_Abc(){
                          
                      
                   for(int i=0;i<Table_Abc.getRowCount();i++){
                       Boolean checked=Boolean.valueOf(Table_Abc.getValueAt(i,3).toString());
                       String num=Table_Abc.getValueAt(i,0).toString();
                       String nom=Table_Abc.getValueAt(i,1).toString();
                       if(checked){
                         Supprimer_Abcense(num);
                           //JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
                   }
               }
                      }
               //Modifier un abcense
                      public void Modifier_Abcense(String num){
                          try {
            int t=2;
                String oo=option_abc.getSelectedItem().toString();
                String ff=filiere_abc.getSelectedItem().toString();
                String ii=niveau_abc.getSelectedItem().toString();
                String mod=module_abc.getSelectedItem().toString();
                String ty=type_abc.getSelectedItem().toString();
            if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){

            String sql="update Abcense set Filiere_A='"+ff+"',Totale_Heure='"+t+"',Option_A='"+oo+"', Niveau_A='"+ii+"',Justification='"+just_abc.getSelectedItem().toString()+"' "
         + "WHERE N_Inscription='"+num+"' AND Date_Abcense='"+((JTextField)date_abc.getDateEditor().getUiComponent()).getText()+"'AND Type='"+ty+"'AND Nom_Module_A='"+mod+"'  AND Duree_Abcense='"+duree_abc.getSelectedItem().toString()+"' ";

            PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);

            pst.executeUpdate();
           
            JOptionPane.showMessageDialog(null,"modification effectué");
            Afficher_Abcense();
        }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
                      }
      //**********************************************
                       public void Modifier_Abc(){
                          
                      
                   for(int i=0;i<Table_Abc.getRowCount();i++){
                       Boolean checked=Boolean.valueOf(Table_Abc.getValueAt(i,3).toString());
                       String num=Table_Abc.getValueAt(i,0).toString();
                       String nom=Table_Abc.getValueAt(i,1).toString();
                       if(checked){
                         Modifier_Abcense(num);
                         //JOptionPane.showMessageDialog(null,"Modification éfféctuée ");
                   }
               }
                      }
            /*      public  Double Calculer_Note_R(){
               
             Double r1= 0.25 * Note_Ds();
             Double r2=(Double.parseDouble(ds1.getText())) * 0.75;
             Double res=r1+r2;
              return  (double) Math.round(res * 100) / 100;
              
          }
          public String Etat_R(){
              Double c=Calculer_Note_R();
              if((c>=10) && (Nombre_Abcense(num_note1.getText())==false)){
                  return "Validé après rattrapage";
              }
                  return "Non valide";
             
          }
          
         public Double Note_Ds(){
               try{
                  Double notee_d=0.0;
           
                      String q="SELECT * FROM Note WHERE N_Inscription='"+num_note1.getText()+"'AND Nom_MODULE='"+module_etud1+"'";
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(q);
                   while(rs.next()){
                      notee_d=rs.getDouble("Note_Ds");
                     
                   }
                    return notee_d;
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
               return 0.0;
          }*/
          public Double Max_N(Double a,Double b){
              if(a>b){
                  return a;
              }else{
                  return b;
              }
          }
          public void Modifier_Note(Double n,String num,String mo){
                   
                   try{
                      String   o="Update Note SET Note_Generale='"+n+"' where N_Inscription='"+num+"' AND Nom_Module='"+mo+"'";
                  
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
                   }catch(Exception e){
                        JOptionPane.showMessageDialog(null,e.getMessage());
                   }
               }
               public void Note_Generale(String nu,String mo){
                
                     Double nor,rat,max = null;
                     String qe="SELECT * FROM Note where N_Inscription='"+nu+"' AND Nom_Module='"+mo+"'";
                     try{
                         
                     
                   st1=connection.ConnecteDb().createStatement();
                   rs1=st1.executeQuery(qe);
                     while(rs1.next()){
                         
                     nor=rs1.getDouble("Note_Session_Normale");
                     rat=rs1.getDouble("Note_Session_Rattrapage");
                     //JOptionPane.showMessageDialog(null,nor);
                     //JOptionPane.showMessageDialog(null,rat);
                     max=Math.max(nor,rat);
                     Modifier_Note(max,nu,mo);
                     }
                     }catch(Exception e){
                         JOptionPane.showMessageDialog(null,e.getMessage());
                     }
               }
               
              public boolean Note_Module(String num){
         
          int y=0,x=0;
          boolean a=false;
       try{ 
                         Calendar calendar = Calendar.getInstance(); 
                        int ane=calendar.get( Calendar.YEAR );
                      String q="Select  * from Note where N_Inscription='"+num+"'  AND Année='"+ane+"'";
                        st1=connection.ConnecteDb().createStatement();
                        rs1=st1.executeQuery(q);
                        
                     while(rs1.next()){ 
                       double    mo=rs1.getDouble("Note_Generale");
                       String mod=rs1.getString("Nom_MODULE");
                    if(mo>=10 && Nombre_Abcense(num,mod)==false){
                        y=1;
                    }else{
                        x=1;
                    }
                     }
                    if(y==1 && x==0){
                        a=true;
                    }else{
                        a=false;
                    }
                     
                 return a;
       }catch(SQLException e){
          JOptionPane.showMessageDialog(null,e.getMessage());
   }
         return  a;
                 }
             /*   public void Res_Semestre(){
            
             DefaultListModel l = new   DefaultListModel();
       
          
            
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
               se.setRowCount(0);
                      Double res = 0.0,som,f;
                      Double nbr=Nombre_Module();
                      String e="";
                      String q="Select * from Note Where N_Inscription='"+num_s.getText()+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                              + "N_Option='"+option_s.getSelectedItem().toString()+"' AND N_Niveau='"+niveau_s.getSelectedItem().toString()+"' ";
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                  
                      if(rs.next()){
                          Double note_G =rs.getDouble("Note_Generale");
                           res=res+note_G;
                       }
                      if(nbr!=0){
                          som=res/nbr;
                           f=(double) Math.round(som * 100) / 100;
                           
                           if(som>=10.0){
                               if(Note_Module()){
                                   e="Validé avec acquisition";
                               }
                      }else{
                          e="Non valide";
                      }
                         // Ajouter_Note_S(Double.toString(f),e);
                           
                      }
                    
                     
                         
                     
            
                   
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
          }*/
                
                
                public void Etudiants_Rattrapage(){
                   for(int i=0;i<Table_Abc.getRowCount();i++){
                       Boolean checked=Boolean.valueOf(Table_Abc.getValueAt(i,3).toString());
                       String num=Table_Abc.getValueAt(i,0).toString();
                       String nom=Table_Abc.getValueAt(i,1).toString();
                       if(checked){
                          Ajouter_Abcense(num,nom);
                           JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
                   }
               }
               
}
                public  void Afficher_Etud_Ratt(){
                   //  t=(DefaultTableModel) Table_Abc1.getModel();
                     t.setRowCount(0);
           
                String op=option_etud1.getSelectedItem().toString();
                String Fi=filiere_etud1.getSelectedItem().toString();
                String ni=niveau_etud1.getSelectedItem().toString();
                String mo=module_etud1.getSelectedItem().toString();
                String s1="Rattrapage";
                 Calendar calendar = Calendar.getInstance(); 
                 int ann=calendar.get( Calendar.YEAR );
             
                String a="Select * From Note Where N_Filiere='"+Fi+"' AND N_Option='"+op+"' AND N_Niveau='"+ni+"'"
               + "AND Nom_Module='"+mo+"' AND Etat='"+s1+"' AND Année='"+ann+"'";
       
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
           
                   st=connection.ConnecteDb().createStatement();
                   rs=st.executeQuery(a);
                   while(rs.next()){
                   t.addRow(new Object[]{rs.getString("N_Inscription"),rs.getString("Nom")} );
                   }
                    Table_Abc1.setModel(t);
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }
     
      
      }
             
                   //*******************
               /*    public void Note_Rattrapage(){
                         try {
            String f=filiere_etud1.getSelectedItem().toString();
            String o=option_etud1.getSelectedItem().toString();
            String n=niveau_etud1.getSelectedItem().toString();
            Double no=Calculer_Note_R();
            String e=Etat_R();
            String nu=num_note1.getText();
            String mo=module_etud1.getSelectedItem().toString();

            // if(ds1.getText().length()!=0){
                String sql="UPDATE Note SET  Note_Examen='"+ds1.getText()+"', Note_Session_Rattrapage='"+no+"', Etat='"+e+"'  WHERE N_Inscription='"+num_note1.getText()+"' AND "
                + "Nom_Module='"+module_etud1.getSelectedItem().toString()+"' AND N_Filiere='"+f+"' AND N_Option='"+o+"' AND N_Niveau='"+n+"'";
                if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                    ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){

                PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);

                pst.executeUpdate();

                JOptionPane.showMessageDialog(null,"modification effectué");
                Note_Generale(nu,mo);
            }

            /* }else{
            JOptionPane.showMessageDialog(null,"Veuillez remplire les champs !");
        }*/
       /* } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
                   }*/
                             //****************************
              public static boolean Nombre_Abc(String num){
             
            
             String j="Absence non justifiée";
           
                     int som=0,id;
                    
                     
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
            
                    Calendar calendar = Calendar.getInstance(); 
                     int ane=calendar.get( Calendar.YEAR );
                      String q="SELECT * FROM Abcense WHERE N_Inscription='"+num+"' AND Nom_Module_A="
                              + "'"+module_ret.getSelectedItem().toString()+"' AND Justification='"+j+"' AND Année_Abs='"+ane+"'";
                   st1=connection.ConnecteDb().createStatement();
                   rs1=st1.executeQuery(q);
                   while(rs1.next()){
                      id=rs1.getInt("Totale_Heure");
                           som=som+id;
                     
                   }
                    if(som >= 6){
                          
                           return true;
                     }
                  
                return false;
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
        return false;
       
              }
            
            /*public void suprimerLingnesDoublon(){
		 ArrayList<String> list = new ArrayList(); 
		int rows = Table_Abcense1.getRowCount(); 
		for (int i=rows-1; i>=0; --i){ 
 
		String data = Table_Abcense1.getValueAt(i,0).toString(); 
		if (list.contains(data)) { 
 
			model.removeRow(i);
                        model.removeRow(Table_Abcense1.getRowCount()-1);
 
		} 
		else{ 
		list.add(data); 
		} 
	}
	}*/
                 
    /*      public void Calculer_Note_Ratt(){
         
       try{
               se.setRowCount(0);
                      Double res = 0.0,som;
                      Double nbr=Nombre_Module();
                      String q="Select * from Note Where N_Inscription='"+num_s.getText()+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                              + "N_Option='"+option_s.getSelectedItem().toString()+"' ";
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                  
                      while(rs.next()){
                          
                           Double note_G =rs.getDouble("Note_Generale");
                           res=res+note_G;
                       }
                      if(nbr!=0){
                          som=res/nbr;
                          Double f=(double) Math.round(som * 100) / 100;
                         note_generale.setText(f+"/20");
                           if(som>=10.0){
                               if(Note_Module()){
                                   etat.setText("Validé avec acquisition");
                               }
                      }else{
                          etat.setText("Non valide");
                      }
                     
                      }
       }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }    
          }   */
         //Calculer la note du semestre pour tous les étudiants
              //1.Culer le nombre of module existe dans un niveau
          public int Count_Module(){
             int count=0;
              String q="SELECT DISTINCT Id_Module FROM Module_E   where Filiere_Mod='"+filiere_s.getSelectedItem().toString()+"'AND "
                           + "Option_Mod='"+option_s.getSelectedItem().toString()+"' AND Niveau_Mod='"+niveau_s.getSelectedItem().toString()+"'";
              try{
                   st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                  while(rs.next()){
                      count=count+1;
                  }
                  return count;
              }catch(Exception e){
                  JOptionPane.showMessageDialog(null,e.getMessage());
              }
                  return count;
          }
          //2.Calculation
           public void Calculer_Session_Normale(){
                       String s1="",mod="",nom_e="";
                     
                      int nbr=Count_Module();
                      int a=1,b=1;
                      
               
       try{
            Calendar calendar = Calendar.getInstance(); 
             int annee=calendar.get( Calendar.YEAR );
                       String q="SELECT N_Inscription,Nom,CNE  FROM Etudiant where Filiere_E='"+filiere_s.getSelectedItem().toString()+"'AND "
                 + "Option_E='"+option_s.getSelectedItem().toString()+"' AND Niveau_E='"+niveau_s.getSelectedItem().toString()+"' AND Année='"+annee+"'";

                       
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                 
                       while(rs.next()){
                       String numinsc=rs.getString("N_Inscription");
                      String cne=rs.getString("CNE");
                       nom_e=rs.getString("Nom");
                        System.out.println(numinsc);
                          double som=note_g(numinsc)/nbr;
                           System.out.println(som);
                           Double f=(double) Math.round(som * 100) / 100;
                           System.out.println(f);
                           boolean resb=Note_Module(numinsc);
                     
                         if(som>=10 && resb==true){
                              s1="Validé par acquisition";
                              Ajouter_Note_S(numinsc,nom_e, filiere_s.getSelectedItem().toString(),option_s.getSelectedItem().toString(),
                                   niveau_s.getSelectedItem().toString(),f,s1,cne);
                        
                           }
                             else {
                               
                                s1="Non valide";
                                 Ajouter_Note_S(numinsc,nom_e, filiere_s.getSelectedItem().toString(),option_s.getSelectedItem().toString(),
                                  niveau_s.getSelectedItem().toString(),f,s1,cne);
                        
                              
                           }
                      
                       }
            
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }    
       }
           //***********************
           public void Suite_Calcule(){
               try{
                   String numinsc="",nom_e;
                    String s1="";
                    String cne="";
//                       String q="SELECT N_Inscription,Nom  FROM Etudiant where Filiere_E='"+filiere_s.getSelectedItem().toString()+"'AND "
//                 + "Option_E='"+option_s.getSelectedItem().toString()+"' AND Niveau_E='"+niveau_s.getSelectedItem().toString()+"' ";
             String q="SELECT N_Inscription,Nom,CNE  FROM Note_Semestre where Filiere_S='"+filiere_s.getSelectedItem().toString()+"'AND "
               + "Option_S='"+option_s.getSelectedItem().toString()+"' AND Niveau='"+niveau_s.getSelectedItem().toString()+"' AND Etat like 'Non%' ";

                       
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                     
                       while(rs.next()){
                       numinsc=rs.getString("N_Inscription");
                       nom_e=rs.getString("Nom");
                       cne=rs.getString("CNE");
                       int nbr=Count_Module();
                     double  som=note_g(numinsc)/nbr;
                      Double f=(double) Math.round(som * 100) / 100;
                        
                        
                           if(Module_Stage(numinsc) && Module_Majeur(numinsc) && Module_Complementaire(numinsc)){
                              s1="Validé par compensation";
                            }
                              else {
                                  s1="Non valide";
                              
                            }
                           Update_Note_S(numinsc, filiere_s.getSelectedItem().toString(),option_s.getSelectedItem().toString(),niveau_s.getSelectedItem().toString(),s1);
                          
                       }
                     
            
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
       }   
             
           }
           
           
           //.********************
            public String Type(String mod){
              String t="";
              String q="SELECT Type_Module FROM Module_E Where Intitule_Module='"+mod+"'";
              try{
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                  while(rs.next()){
                      t=rs.getString("Type_Module");
                  }
                  return t;
              }catch(Exception e){
                  JOptionPane.showMessageDialog(null,e.getMessage());
              }
                  return t;
            }
            //Récupérer les types des modules selon des conditions
            public boolean Module_Majeur(String num){
                
                boolean m=false;
              int x=0,y=0;
                Double note;
                String mod;
               String ty;
               Calendar calendar = Calendar.getInstance(); 
                        int an=calendar.get( Calendar.YEAR );
                try{
                String qeury="Select * from Note Where N_Inscription='"+num+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                           + "N_Option='"+option_s.getSelectedItem().toString()+"' AND N_Niveau='"+niveau_s.getSelectedItem().toString()+"' AND Année='"+an+"'";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();
                           rs1=st1.executeQuery(qeury);
                       while(rs1.next()){
                             Double note_G =rs1.getDouble("Note_Generale");
                               mod=rs1.getString("Nom_MODULE");
                               ty=Type(mod);
                       
                     if(ty.equals("Majeur")){
                            if(note_G>=8){
                               x=1;
                            }
                                y=2;
                      }
                     }
                     if(x==1 && y==0){
                         m=true;
                     } else{
                         m=false;
                     } 
                    return m;
                }catch(Exception e){
                 JOptionPane.showMessageDialog(null,e.getMessage());

            }
                return false;
}
            //Module_Complémentaire
              public boolean Module_Complementaire(String num){
                
                boolean c=false;
               int x=0,y=0;
                Double note;
                String mod;
               String ty;
               Calendar calendar = Calendar.getInstance(); 
                        int a=calendar.get( Calendar.YEAR );
                try{
                String qeury="Select * from Note Where N_Inscription='"+num+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                           + "N_Option='"+option_s.getSelectedItem().toString()+"' AND N_Niveau='"+niveau_s.getSelectedItem().toString()+"' AND Année='"+a+"'";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();
                           rs1=st1.executeQuery(qeury);
                       while(rs1.next()){
                             Double note_G =rs1.getDouble("Note_Generale");
                               mod=rs1.getString("Nom_MODULE");
                               ty=Type(mod);
                       
                     if(ty.equals("Complémentaire")){
                            if(note_G>=5){
                               x=1;
                            }
                                y=2;
                      }
                     }
                     if(x==1 && y==0){
                         c=true;
                     } else{
                         c=false;
                     } 
                    return c;
                }catch(Exception e){
                 JOptionPane.showMessageDialog(null,e.getMessage());

            }
                return false;
}
              public boolean Module_Stage(String num){
                
                boolean b=false;
              
                Double note;
                String mod;
               String ty;  
               int x=0,y=0;
               Calendar calendar = Calendar.getInstance(); 
                        int ane=calendar.get( Calendar.YEAR );
                 if(verifier_type_module("Stage")==true){
                try{
                String qeury="Select * from Note Where N_Inscription='"+num+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                           + "N_Option='"+option_s.getSelectedItem().toString()+"' AND N_Niveau='"+niveau_s.getSelectedItem().toString()+"' AND Année='"+ane+"'";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();
                           rs1=st1.executeQuery(qeury);
                       while(rs1.next()){
                             Double note_G =rs1.getDouble("Note_Generale");
                             mod=rs1.getString("Nom_MODULE");
                             ty=Type(mod);
                      if(ty.equals("Stage")){
                            if(note_G>=10){
                               x=1;
                            }
                                y=2;
                      }
                     }
                     if(x==1 && y==0){
                         b=true;
                     } else{
                         b=false;
                     } 
                    return b;
                
                
                }catch(Exception e){
                 JOptionPane.showMessageDialog(null,e.getMessage());

            }
                 }else{
                     b=true;
                    
                 }
            return b;   
}
              //************
               //2.Calculation
        /*   public void Calculer_Session_Rattrapage(){
         
       try{
                       String s1="";
                       String s2="";
                      String numinsc;
                      String t="";
                      Double res = 0.0,som;
                      int nbr=3;
                     String q="SELECT DISTINCT N_Inscription FROM Note";
                     String et="Validé par acquisition";
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                      
                      while(rs.next()){
                           numinsc=rs.getString("N_Inscription");
                           String qeury="Select * from Note Where N_Inscription='"+numinsc+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                           + "N_Option='"+option_s.getSelectedItem().toString()+"' AND N_Niveau='"+niveau_s.getSelectedItem().toString()+"' AND Etat='"+et+"' ";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();
                           rs1=st1.executeQuery(qeury);
                         while(rs1.next()){
                             Double note_G =rs1.getDouble("Note_Generale");
                             String mod=rs.getString("Nom_MODULE");
                              t=Type(mod);
                              res=res+note_G;
                              JOptionPane.showMessageDialog(null,note_G);
                               
                         }
                           som=res/nbr;
                           Double f=(double) Math.round(som * 100) / 100;
                           //   if(nbr!=0){
    
                           //JOptionPane.showMessageDialog(null,som);
                           if(som>=10.0 && Module_Majeur(numinsc) && Module_Complementaire(numinsc) && Module_Stage(numinsc)){
                               
                           s1="Validé par compensation";
                               
         Ajouter_Note_Ratt(numinsc, filiere_s.getSelectedItem().toString(),option_s.getSelectedItem().toString(),niveau_s.getSelectedItem().toString(),f,s1);
                               
                               }else{
                                s2="Non valide";
                                 
        Ajouter_Note_Ratt(numinsc, filiere_s.getSelectedItem().toString(),option_s.getSelectedItem().toString(),niveau_s.getSelectedItem().toString(),f,s2);
                      }
                           
                       
                     
                     
                      }
       }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }    
          }*/
           //Ajouter note du semestre aprés rattrapage
            public static void Ajouter_Note_Ratt(String s1, String f,String op,String n,Double note,String Etat){
                 try{
                    String o="Insert into Note_Semestre (N_Inscription,Filiere_S,Option_S,Niveau,Note_S_Normale,Etat) "
           + "values('"+s1+"','"+f+"','"+op+"','"+n+"','"+note+"','"+Etat+"' ) ";
                  
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
         JOptionPane.showMessageDialog(null,"Calculation éfféctuées  ");
         
                 }catch(Exception e){
                     JOptionPane.showMessageDialog(null,e.getMessage());
                 }
             }
            
          
            //Sélectionner tous les étudiants qui existent dans la base de données conférmément à certain conditions
            public void Afficher_Etudiants(String Fi,String op,String ni){
                Calendar calendar = Calendar.getInstance(); 
                        int an=calendar.get( Calendar.YEAR );
                 String af="SELECT * FROM Etudiant WHERE Filiere_E='"+Fi+"' AND Option_E='"+op+"' AND Niveau_E='"+ni+"' AND Année='"+an+"'";
                try{
                      st=connection.ConnecteDb().createStatement();
                        rs=st.executeQuery(af);
                     while(rs.next()){
                   et.addRow(new Object[]{rs.getString("N_Inscription"),rs.getString("Nom"),rs.getString("Prenom"),false} );
                   }
                    
                }catch(Exception e){
                  JOptionPane.showMessageDialog(null,e.getMessage());
                
                }
            }
             public void Afficher_Etud(String Fi,String op,String ni){
                  et=(DefaultTableModel) Table_Et1.getModel();
                    et.setRowCount(0);
            Double a=null;
            Double b=null;
              Calendar calendar = Calendar.getInstance(); 
             int ann=calendar.get( Calendar.YEAR );
                 String numinsc;
                 String af="SELECT * FROM Etudiant WHERE Filiere_E='"+Fi+"' AND Option_E='"+op+"' AND Niveau_E='"+ni+"' AND Année='"+ann+"'";
                try{
                      st=connection.ConnecteDb().createStatement();
                        rs=st.executeQuery(af);
                     while(rs.next()){
                     //  numinsc=rs.getString("N_Inscription");
                     //  if(Tester(numinsc)==false){
                   et.addRow(new Object[]{rs.getString("N_Inscription"),rs.getString("Nom"),a,b} );
                        }
                   
                    Table_Et1.setModel(et);
                }catch(SQLException e){
                  JOptionPane.showMessageDialog(null,e.getMessage());
                
                }
            }
             //Méthode d'ajout des notes
             public void Ajouter_Note(Double ds,Double exame,String nom,String num){
               try{
                 
                  double ng=Calculer_Note(ds,exame);
                  int id=Id_Etudiant_FK(num);
                  String e=Etat(ds,exame,num);
                  String mo=module_etud.getSelectedItem().toString();
                 Calendar calendar = Calendar.getInstance(); 
             int ann=calendar.get( Calendar.YEAR );
         String o = "INSERT INTO Note(Id_Etudiant,N_Inscription,Nom,Nom_Module,Note_Ds,"
                 + "Note_Examen_N,N_Filiere,N_Option,N_Niveau,Note_Session_Normale,Etat,Année) VALUES('"+id+"',"
                 + "'"+num+"','"+nom+"','"+module_etud.getSelectedItem().toString()+"','"+ds+"','"+exame+"',"
                 + "'"+filiere_etud.getSelectedItem().toString()+"','"+option_etud.getSelectedItem().toString()+"','"
                 + ""+niveau_etud.getSelectedItem().toString()+"','"+ng+"','"+e+"','"+ann+"')";
     
      
            
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
         //JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
         Note_Generale(num,mo);
        
                 
       }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
             }
             //Sauvegarder les notes
             public void Sauvegarder(){
                 
                 
                  try{
                 for(int i=0;i<Table_Et1.getRowCount();i++){
                     String numinscri=Table_Et1.getValueAt(i,0).toString();
                     String nom=Table_Et1.getValueAt(i,1).toString();
                     Double ds=Double.parseDouble(Table_Et1.getValueAt(i,2).toString());
                     Double exame=Double.parseDouble(Table_Et1.getValueAt(i,3).toString());
                     Ajouter_Note(ds,exame,nom,numinscri);
                 }
                 
                 
                 JOptionPane.showMessageDialog(null,"Les informations sont bien ajoutées ");
             }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
}
           //Afficher la note du semestr
          /*     public void Résultat_Semestre(){
            
          
            
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
               se.setRowCount(0);
                      Double res = 0.0,som;
                      Double nbr=Nombre_Module();
                      String q="Select * from Note Where N_Inscription='"+numinsc.getText()+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                              + "N_Option='"+option_s.getSelectedItem().toString()+"' ";
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                  
                      while(rs.next()){
                           String nomE=rs.getString("Nom");
                            nom1.setText(nomE);
                           String num_i=rs.getString("N_Inscription");
                            num_insc1.setText(num_i);
                           String f=rs.getString("N_Filiere");
                            filiere1.setText(f);
                           String o=rs.getString("N_Option");
                            option1.setText(o);
                           String nv=rs.getString("N_Niveau");
                            niveau1.setText(nv);
                           String mo=rs.getString("Nom_Module");
                            se.addRow(new Object[]{rs.getString("Nom_Module"),rs.getString("Note_Generale"),rs.getString("Etat")} );
                          
                       }
                     Res_Semestre(numinsc.getText());
                       
                      table_sem.setModel(se);       
                      
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
          }*/
               //Résultat du semestre
             
               //Création d'une méthode qui permet de séléctionner les étudiants quit validés certains modules
               public boolean Tester(String num){
                   boolean b=false;
                    String q="Select * from Note Where N_Inscription='"+num+"' AND N_Filiere='"+filiere_etud.getSelectedItem().toString()+"'AND "
                              + "N_Option='"+option_etud.getSelectedItem().toString()+"' AND N_Niveau='"+niveau_etud.getSelectedItem().toString()+"' AND Etat like 'Validé%' AND "
                            + "Nom_MODULE='"+module_etud.getSelectedItem().toString()+"'";
                    try{
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                       if(rs.next()){
                          b=true;
                       }else{
                           b=false;
                       }
                     
                       return b;
                    }catch(SQLException e){
                        //JOptionPane.showMessageDialog(null,e.getMessage());
                       
                    }
                    return b;
               }
               //Résultat
              /*    public  void Resultat(){
                 try{
                    double som=0,res;
                     String q="Select * from Note Where N_Inscription='"+numinsc.getText()+"' AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                              + "N_Option='"+option_s.getSelectedItem().toString()+"' ";
                       st=connection.ConnecteDb().createStatement();
                       rs=st.executeQuery(q);
                  
                      while(rs.next()){
                           double n=rs.getDouble("Note");
                           som=som+n;
                      }
                      res=som/6;
                      if(res>=10){
                          etat1.setText("Validé avec acquisition");
                          
                      }else{
                          etat1.setText("Non valide");
                      }
                 }catch(Exception e){
                         JOptionPane.showMessageDialog(null,e.getMessage());
                         }
             }*/
                  /*    try {
                 String nu=num_note.getText();
                  String mo=module_etud.getSelectedItem().toString();
                  double ng=Calculer_Note(nu,examen.getText());
          
      String sql="UPDATE Note SET  Note_Ds='"+ds.getText()+"',Note_Examen_N='"+examen.getText()+"',Note_Session_Normale='"+ng+"' WHERE N_Inscription='"+num_note.getText()+"' AND "
              + "Nom_Module='"+module_etud.getSelectedItem().toString()+"'";
      if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
               String s1=num_insc.getText() ;
       
        PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);
           
            pst.executeUpdate();
                
             JOptionPane.showMessageDialog(null,"modification effectué");
              Note_Generale(nu,mo);
      }
             Note_Generale(nu,mo);
           
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
       }*/
                  
                  /*
                    try{
             if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                             ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                        
//La requête qui permet de supprimer les données de bla base de données ______________________________________________________                    
              String  query="Delete from Note where N_Inscription = '"+num_note.getText()+"' AND Nom_Module='"+module_etud.getSelectedItem().toString()+"'";
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
              JOptionPane.showMessageDialog(null,"Les informations sont supprimées !");}
             
            
        }catch(HeadlessException | SQLException e){
             JOptionPane.showMessageDialog(null,e.getMessage());
        }
                  */
                 public double Moyenne_Niveau2(String num){
                 
     Double count=0.0,note;
                 try{
                        
                         Calendar calendar = Calendar.getInstance(); 
                        int an=calendar.get( Calendar.YEAR );
                String qeury="Select * from Note_Semestre Where  N_Inscription='"+num+"' AND Filiere_S='"+filiere_etud2.getSelectedItem().toString()+"'AND Option_S='"+option_etud2.getSelectedItem().toString()+"' AND Etat like 'Validé par %'  AND Annee_Universitaire='"+an+"'";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();
                           rs1=st1.executeQuery(qeury);
                           while(rs1.next()){
                               num=rs1.getString("Niveau");
                               note=rs1.getDouble("Note_S_Normale");
                               if(num.equals("Semestre1")){
                                   count=count+note;
                               }
                               if(num.equals("Semestre2")){
                                   count=count+note;
                               }
                               
                           }
                          
                    return count/2;
                }catch(SQLException e){
                 JOptionPane.showMessageDialog(null,e.getMessage());

            }
                 return count;
            }
           public double Moyenne_Niveau4(String num){
                 
     Double count=0.0,note;
                 try{
                        
                         Calendar calendar = Calendar.getInstance(); 
                        int an=calendar.get( Calendar.YEAR );
                String qeury="Select * from Note_Semestre Where  N_Inscription='"+num+"' AND Filiere_S='"+filiere_etud2.getSelectedItem().toString()+"'AND Option_S='"+option_etud2.getSelectedItem().toString()+"' AND Etat like 'Validé par %' AND Annee_Universitaire='"+an+"' ";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();
                           rs1=st1.executeQuery(qeury);
                           while(rs1.next()){
                               num=rs1.getString("Niveau");
                               note=rs1.getDouble("Note_S_Normale");
                               if(num.equals("Semestre3")){
                                   count=count+note;
                               }
                               if(num.equals("Semestre4")){
                                   count=count+note;
                               }
                               
                           }
                          
                    return count/2;
                }catch(SQLException e){
                 JOptionPane.showMessageDialog(null,e.getMessage());

            }
                 return count;
            }
            public double Moyenne_Niveau5(String num){
                 
     Double count=0.0,note;
                 try{
                        
                           Calendar calendar = Calendar.getInstance(); 
                        int an=calendar.get( Calendar.YEAR );
                String qeury="Select * from Note_Semestre Where  N_Inscription='"+num+"' AND Filiere_S='"+filiere_etud2.getSelectedItem().toString()+"'AND Option_S='"+option_etud2.getSelectedItem().toString()+"' AND Etat like 'Validé par %' AND Annee_Universitaire='"+an+"' ";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();
                           rs1=st1.executeQuery(qeury);
                           while(rs1.next()){
                               num=rs1.getString("Niveau");
                               note=rs1.getDouble("Note_S_Normale");
                              count=count+note;
                           }
                          
                    return count/5;
                }catch(SQLException e){
                 JOptionPane.showMessageDialog(null,e.getMessage());

            }
                 return count;
            }
public void Afficher_Etud_Ruissis(){
                 try{
                          Calendar calendar = Calendar.getInstance(); 
                        int an=calendar.get( Calendar.YEAR );
                String qeury="Select  N_Inscription,CNE from Note_Semestre Where  Filiere_S='"+filiere_etud2.getSelectedItem().toString()+"'AND Option_S='"+option_etud2.getSelectedItem().toString()+"' AND Niveau='"+niveau_etud2.getSelectedItem().toString()+"' AND Annee_Universitaire='"+an+"'";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();   //AND Etat like 'Validé par %' 
                           rs1=st1.executeQuery(qeury);
                           String num="";
                           String cne="";
                           while(rs1.next()){
                               num=rs1.getString("N_Inscription");
                              cne=rs1.getString("CNE");
                       if(niveau_etud2.getSelectedItem().toString().equals("Semestre1")){
                           Supprimer_Abcense_E(num);
                           Modifier_Nv_Et("Semestre2",num);
                    // connectiontoaccess.Modifier_Niveau(cne,"Semestre2");
                       }
                       if(niveau_etud2.getSelectedItem().toString().equals("Semestre2")){
                             //vérifier
                           if(Moyenne_Niveau2(num)>=10){
                                Supprimer_Abcense_E(num);
                                Modifier_Nv_Et("Semestre3",num);
                          //  connectiontoaccess.Modifier_Niveau(cne,"Semestre3");
                           }else{
                               Supprimer_Abcense_E(num);
                               Modifier_Etat_Et(num,"Semestre2");
                       //  connectiontoaccess.Modifier_Niveau(cne,"Semestre2");
                           }
                       }
                       
                        if(niveau_etud2.getSelectedItem().toString().equals("Semestre3")){
                             Supprimer_Abcense_E(num);
                           Modifier_Nv_Et("Semestre4",num);
                    //  connectiontoaccess.Modifier_Niveau(cne,"Semestre4");
                       }
                        if(niveau_etud2.getSelectedItem().toString().equals("Semestre4")){
                               //vérifier 3et 4
                          if(Moyenne_Niveau4(num)>=10){
                               Supprimer_Abcense_E(num);
                               Modifier_Nv_Et("Semestre5",num); 
                        //  connectiontoaccess.Modifier_Niveau(cne,"Semestre5");
                          }else{
                              Supprimer_Abcense_E(num);
                               Modifier_Nv_Et("Semestre4",num);
                      // connectiontoaccess.Modifier_Niveau(cne,"Semestre4");
                          }
                       }
                        if(niveau_etud2.getSelectedItem().toString().equals("Semestre5")){
                            //vérifier tous
                                Supprimer_Abcense_E(num);
                               Modifier_Nv_Et("Semestre6",num); 
                          //connectiontoaccess.Modifier_Niveau(cne,"Semestre6");
                          
                       }
                       
                       
                           }
                           JOptionPane.showMessageDialog(null,"modification effectué");
                }catch(SQLException e){
                 JOptionPane.showMessageDialog(null,e.getMessage());

            }
            }
//Modifier le niveau d'éducation d'un étudiant
                 public void Modifier_Nv_Et(String nv,String num){
                try {
            Calendar calendar = Calendar.getInstance(); 
             int an=calendar.get( Calendar.YEAR );
      String sql="UPDATE Etudiant SET Niveau_E='"+nv+"' WHERE N_Inscription='"+num+"' AND Filiere_E='"+filiere_etud2.getSelectedItem().toString()+"' AND Option_E='"+option_etud2.getSelectedItem().toString()+"' AND Année='"+an+"'";
   //   if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                           //  ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
              
        PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);
           
            pst.executeUpdate();
                
            // JOptionPane.showMessageDialog(null,"modification effectué");}
            // }
      
           
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
       }
       
                }
                 //Supprimer les abcenses d'un étudiant qui valide le semestre
                  public static void Supprimer_Abcense_E(String num){
         try{
             String f=filiere_etud2.getSelectedItem().toString();
             String o=option_etud2.getSelectedItem().toString();
             String n=niveau_etud2.getSelectedItem().toString();
               Calendar calendar = Calendar.getInstance(); 
                        int an=calendar.get( Calendar.YEAR );
           //  if(JOptionPane.showConfirmDialog(null,"Confirmer la suppression","Supprimer"
                           //  ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
                        
     //La requête qui permet de supprimer les données de bla base de données ______________________________________________________                    
              String  query="Delete from Abcense  WHERE N_Inscription='"+num+"' AND Filiere_A='"+f+"' AND Option_A='"+o+"' AND Niveau_A='"+n+"' AND Année_Abs='"+an+"'";
              
              
              PreparedStatement ps=connection.ConnecteDb().prepareStatement(query);
               ps.executeUpdate();
         // JOptionPane.showMessageDialog(null,"Les informations sont supprimées !");
          
             }catch(HeadlessException | SQLException e){
             JOptionPane.showMessageDialog(null,e.getMessage());
     //   }
    }
                  }
                    public void Modifier_Etat_Et(String num,String nv){
                try {
           String etat="Réinscrit";
             Calendar calendar = Calendar.getInstance(); 
                        int an=calendar.get( Calendar.YEAR );
      String sql="UPDATE Etudiant SET Etat='"+etat+"' WHERE N_Inscription='"+num+"' AND Niveau_E='"+nv+"' AND Filiere_E='"+filiere_etud2.getSelectedItem().toString()+"' AND Option_E='"+option_etud2.getSelectedItem().toString()+"' AND Année='"+an+"' ";
     // if(JOptionPane.showConfirmDialog(null,"Confirmer la modification","Modification"
                           //  ,JOptionPane.YES_NO_OPTION)==JOptionPane.OK_OPTION){
              
        PreparedStatement     pst=connection.ConnecteDb().prepareStatement(sql);
           
            pst.executeUpdate();
          
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,ex.getMessage());
       }
       
                }
                    //Extraire les noms des livres
                    
                     public void  Livres_Emprunter(String s1) throws ClassNotFoundException{
                  
                     DefaultListModel livre=new DefaultListModel ();
                     String fi=filiere_info.getSelectedItem().toString();
                     String op=option_info.getSelectedItem().toString();
                     String v=niveau_info.getSelectedItem().toString();
                     String qe="SELECT  DISTINCT Nom_livre FROM  Info_etu_livr  where   CNE='"+s1+"' ";
                     try{
                         
                     
                   st1=connectiontoaccess.ConnecteDb().createStatement();
                   rs1=st1.executeQuery(qe);
                     while(rs1.next()){
                       String N=rs1.getString("Nom_livre");
                       livre.addElement(N+"\n");
                      //livre_a.setModel(livre);
                     
                     }
                     }catch(SQLException e){
                         JOptionPane.showMessageDialog(null,e.getMessage());
                     }
               }
                    public  void Res_Sem(String num){
                        int an=jYearChooser1.getYear();
                          Calendar calendar = Calendar.getInstance(); 
                        int ane=calendar.get( Calendar.YEAR );
                           String qe="SELECT  DISTINCT Note_S_Normale FROM  Note_Semestre  where   N_Inscription='"+num+"'  AND Niveau='"+niveau_info.getSelectedItem().toString()+"'AND Filiere_S='"+filiere_info.getSelectedItem().toString()+"' AND Option_S='"+option_info.getSelectedItem().toString()+"' AND Annee_Universitaire='"+ane+"'";
                     try{
                         
                     
                   st1=connection.ConnecteDb().createStatement();
                   rs1=st1.executeQuery(qe);
                     while(rs1.next()){
                       Double N=rs1.getDouble("Note_S_Normale");
                    res_a.setText(Double.toString(N));
                     
                     }
                     }catch(SQLException e){
                         JOptionPane.showMessageDialog(null,e.getMessage());
                     }
                    }
                    public double note_g(String num){
                        double res=0.0;
                        try{
                              Calendar calendar = Calendar.getInstance(); 
                              int an=calendar.get( Calendar.YEAR );
                              String qeury="Select * from Note Where N_Inscription='"+num+"'  AND N_Filiere='"+filiere_s.getSelectedItem().toString()+"' AND N_Option='"+option_s.getSelectedItem().toString()+"' AND N_Niveau='"+niveau_s.getSelectedItem().toString()+"'AND Année='"+an+"'";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();
                           rs1=st1.executeQuery(qeury);
                       while(rs1.next()){
                             Double note_G =rs1.getDouble("Note_Generale");
                               res=res+note_G;
                             //  JOptionPane.showMessageDialog(null,note_G);
                               
                         }
                       
                        return res;
                        }catch(SQLException e){
                            JOptionPane.showMessageDialog(null,e.getMessage());
                        }
                        return res;
                    }
                    public boolean  verifier_type_module(String typ){
                        int comp=0; boolean b=false;
                        Calendar calendar = Calendar.getInstance(); 
                              int an=calendar.get( Calendar.YEAR );
                          try{
                String qeury="Select * from Note where N_Filiere='"+filiere_s.getSelectedItem().toString()+"'AND "
                           + "N_Option='"+option_s.getSelectedItem().toString()+"' AND N_Niveau='"+niveau_s.getSelectedItem().toString()+"'  AND Année='"+an+"'";
                           //Récupérer la note de chaque module
                           st1=connection.ConnecteDb().createStatement();
                           rs1=st1.executeQuery(qeury);
                       while(rs1.next()){
                           String mod=rs1.getString("Nom_MODULE");
                           String type=Type(mod);
                           if(type.equals(typ)){
                           comp++;
                           }
                           comp=0;
                       }
                       if(comp==0){
                          b=false;
                       }else{
                           b=true;
                       }
                    return b;
                }catch(Exception e){
                 JOptionPane.showMessageDialog(null,e.getMessage());

            }
                          return b;
                    }
                    public int nbr_note(String insc){
                        int res=10;
                         if(Note_Module(insc)==true){
                             res=1;
                         }else{
                            res=0;
                         }
                         return res;
                    }
                    
                    
                       public static void Update_Note_S(String s1, String f,String op,String n,String Etat){
                 try{
           String o="update Note_Semestre set Etat='"+Etat+"'   where N_Inscription='"+s1+"' and Niveau='"+n+"' and Option_S='"+op+"' and Filiere_S='"+f+"' ";
                  
        PreparedStatement ps=connection.ConnecteDb().prepareStatement(o);
        ps.executeUpdate();
         //JOptionPane.showMessageDialog(null,"Calculation éfféctuées  ");
         
                 }catch(Exception e){
                     JOptionPane.showMessageDialog(null,e.getMessage());
                 }
             }
                       //**********
                        public static boolean Nombre_Abcense(String num,String mod){
             
            
             String j="Absence non justifiée";
           
                     int som=0,id;
                    boolean k=false;
                     
       //Remplir les noms des colonnes à partir des noms qui existe dans la base de données 
       try{
            
                        Calendar calendar = Calendar.getInstance(); 
                         int an=calendar.get( Calendar.YEAR );
                      String q="SELECT * FROM Abcense WHERE N_Inscription='"+num+"' AND Nom_Module_A="
                              + "'"+mod+"' AND Justification='"+j+"'  AND Année_Abs='"+an+"'";
                   st1=connection.ConnecteDb().createStatement();
                   rs1=st1.executeQuery(q);
                   while(rs1.next()){
                      id=rs1.getInt("Totale_Heure");
                           som=som+id;
                     
                   }
                    if(som >= 6){
                          
                           k= true;
                     }
                  
                 return k;
                  
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null,e.getMessage());
   }
       return k;
       }
//                      public boolean verification(String num){
//                     int comp=0;
//                     try{
//                            String q="SELECT * FROM Note_Semestre where N_Inscription='"+num+"'AND Filiere_S='"+filiere_s.getSelectedItem().toString()+"'AND "
//                 + "Option_S='"+option_s.getSelectedItem().toString()+"' AND Niveau='"+niveau_s.getSelectedItem().toString()+"' ";
//
//                       
//                       st=connection.ConnecteDb().createStatement();
//                       rs=st.executeQuery(q);
//                 
//                       while(rs.next()){
//                       comp++;
//                      }
//                       if(comp >=1){
//                           return true;
//                       }else{
//                           return false;
//                       }
//                      
//                      }catch(Exception e){
//    JOptionPane.showMessageDialog(null,e.getMessage());
//}
//                     return false;
//                      }
                        
                         public void Actualiser_Et(){
                             cne_p.setText("");  nationalite.setText("");
                             cin.setText(""); adr_actuel.setText("");
                             nom.setText("");  nbr_enfant.setText("");
                             prenom.setText(""); moyenne.setText("");
                             tel1.setText("");  mention.setText("");
                             tel2.setText(""); lycee.setText("");
                             adr1.setText("");
                             adr2.setText("");langue.setText("");
                             whatsup.setText("");diplome.setText("");
                             email1.setText("");attelier.setText("");
                             email2.setText("");anterieure.setText("");
                         }
}



        

